import pygame
from menu import Menu


def setup_screen():
    """
    Configura a tela do jogo.
    """
    screen = pygame.display.set_mode((720, 720))
    pygame.display.set_caption("Menu Principal do Jogo")
    return screen


def main():
    """
    Função principal que inicializa o jogo, define a tela e chama o menu principal.
    """
    pygame.init()
    screen = setup_screen()
    menu = Menu(screen)

    try:
        menu.run()
    finally:
        pygame.quit()


if __name__ == "__main__":
    main()


