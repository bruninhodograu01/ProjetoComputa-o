# utils.py
import pygame



class Colors:
    DARK_RED = (138, 0, 0)  # Dark red for buttons
    DEEP_BLACK = (19, 20, 20)  # Almost black for background
    GREY = (59, 60, 60)  # Dark grey for alternate buttons
    WHITE = (254, 255, 255)  # White for readable text
    GLOWING_LIGHT_RED = (239, 128, 128)  # Light red for brighter text
    BLUE = (0, 0, 255)
    GREEN = (34, 139, 34)
    YELLOW = (255, 255, 0)
    RED = (150, 0, 24)
    CUTE_PURPLE = (128, 0, 128)
    GREENISH = (182, 215, 168)

class Settings:
    RESOLUTION = (720, 720)  # Screen resolution (width, height)
    WIDTH, HEIGHT = RESOLUTION
    FPS = 60  # Frames per second setting
    ENEMY_SPAWN_RATE = 5
    ENEMY_LIMIT = 10
    MIDDLE_TOP = HEIGHT // 2 - 50
    MIDDLE_BOTTOM = HEIGHT // 2 + 50
    SCREEN = pygame.display.set_mode(RESOLUTION)
class Sizes:
    PLAYER_SIZE = (50, 100)
    ENEMY_SIZE = (40, 40)
    BULLET_SIZE = 10




class Button:
    def __init__(self, text, rect, color, action=None, hover_color=None):
        self.text = text
        self.rect = rect
        self.color = color
        self.hover_color = hover_color or color  # Cor quando o mouse passa sobre o botão
        self.action = action

    def draw(self, screen):
        """Desenha o botão na tela, com feedback visual de hover."""
        mouse_pos = pygame.mouse.get_pos()
        if self.rect.collidepoint(mouse_pos):
            pygame.draw.rect(screen, self.hover_color, self.rect)
        else:
            pygame.draw.rect(screen, self.color, self.rect)

        font = pygame.font.SysFont('Corbel', 50)
        text_surface = font.render(self.text, True, Colors.WHITE)
        text_rect = text_surface.get_rect(center=self.rect.center)
        screen.blit(text_surface, text_rect)

    def is_clicked(self, mouse_pos):
        """Verifica se o botão foi clicado."""
        return self.rect.collidepoint(mouse_pos)

    def click(self):
        """Executa a ação associada ao botão, se houver uma."""
        if self.action:
            self.action()

def draw_health_bar(screen, x, y, health, max_health):
    """Desenha a barra de saúde do jogador."""
    bar_width = 200  # Tamanho da barra de saúde
    bar_height = 20

    # Calcula o preenchimento da barra com base na saúde atual
    fill_width = int((health / max_health) * bar_width)

    # Desenha a barra de fundo
    pygame.draw.rect(screen, Colors.RED, (x, y, bar_width, bar_height))
    # Desenha a barra preenchida
    pygame.draw.rect(screen, Colors.GREEN, (x, y, fill_width, bar_height))

    # Renderiza o texto da saúde
    font = pygame.font.Font(None, 24)
    health_text = f"{health} / {max_health}"
    text_surface = font.render(health_text, True, Colors.WHITE)
    text_rect = text_surface.get_rect(center=(x + bar_width // 2, y + bar_height // 2))
    screen.blit(text_surface, text_rect)




#ultils
def check_bullet_collisions(bullet_group, enemies):
    """
    Verifica colisões entre balas e inimigos e aplica o dano correspondente.
    Remove a bala após a colisão.
    """
    for bullet in bullet_group:
        for enemy in enemies:
            # Ignora balas disparadas pelo próprio inimigo
            if bullet.origin == enemy:
                continue  # Se a bala foi disparada pelo inimigo, pula a colisão

            if bullet.rect.colliderect(enemy.rect):  # Verifica colisão com o inimigo
                apply_damage_to_enemy(bullet, enemy)
                bullet.kill()

def apply_damage_to_enemy(bullet, enemy):
    """
    Aplica o dano a um inimigo e remove-o se a saúde for 0 ou menor.
    """
    enemy.health -= bullet.damage
    if enemy.health <= 0:
        enemy.kill()  # Remove o inimigo se a saúde for 0 ou menos
        print(f"Inimigo derrotado! Saúde do inimigo: {enemy.health}")



def draw_exp_bar(screen, player, x=70, y=41):
    """Desenha a barra de experiência, mostrando o progresso do jogador até o próximo nível."""
    bar_width = 200  # Tamanho da barra de experiência
    bar_height = 20

    # Calcula o preenchimento da barra com base na experiência atual
    fill_width = int((player.exp / player.exp_to_next_level) * bar_width)



    # Desenha a barra de fundo
    pygame.draw.rect(screen, Colors.GREY, (x, y, bar_width, bar_height))
    # Desenha a barra preenchida com a cor azul
    pygame.draw.rect(screen, (0, 0, 255), (x, y, fill_width, bar_height))  # Azul

    # Renderiza o texto da experiência e do nível
    font = pygame.font.Font(None, 24)
    exp_text = f" Nível: {player.level} | Exp: {player.exp} / {player.exp_to_next_level}"
    text_surface = font.render(exp_text, True, Colors.WHITE)
    text_rect = text_surface.get_rect(center=(x + bar_width // 2, y + bar_height // 2))
    screen.blit(text_surface, text_rect)







def draw_money(screen, player):
    """Desenha a quantidade de dinheiro do jogador na tela."""
    font = pygame.font.Font(None, 36)  # Fonte para o texto
    money_text = f"Dinheiro: ${player.money}"

    # Renderiza o texto de dinheiro
    money_surface = font.render(money_text, True, (255, 255, 255))  # Cor branca

    # Posicionamento do texto na tela
    screen.blit(money_surface, (10, 120))

