#bullet.py


import pygame
import math


class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y, direction, damage, speed, origin):
        super().__init__()
        from utils import Colors
        self.direction = direction
        self.speed = speed  # Velocidade configurável
        self.damage = damage  # Dano configurável
        self.radius = 5
        self.color = Colors.WHITE
        self.origin = origin  # Identifica quem disparou (jogador, inimigo, etc.)

        # Cria uma superfície para a bala
        self.image = pygame.Surface((self.radius * 2, self.radius * 2), pygame.SRCALPHA)
        pygame.draw.circle(self.image, self.color, (self.radius, self.radius), self.radius)

        # Define o rect da bala
        self.rect = self.image.get_rect(center=(x, y))

    def update(self):
        from utils import Settings
        # Move a bala de acordo com sua direção e velocidade
        self.rect.x += int(self.speed * math.cos(self.direction))
        self.rect.y += int(self.speed * math.sin(self.direction))


        # Remove a bala se sair da tela
        if (self.rect.x < 0 or self.rect.x > Settings.WIDTH or
            self.rect.y < 0 or self.rect.y > Settings.HEIGHT):
            self.kill()




