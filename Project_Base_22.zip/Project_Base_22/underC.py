import pygame
from utils import *

class Underc:

    def __init__(self, screen, player):
        self.screen = screen
        self.resolution = Settings.RESOLUTION
        self.deep_black = Colors.DEEP_BLACK
        self.white = Colors.WHITE
        self.dark_red = Colors.DARK_RED
        self.player = player  # Recebe o jogador, que deve ter um atributo 'money' para o dinheiro disponível

        # Definindo os preços das armas
        self.weapon_prices = {
            "Shotgun": 100,
            "Rifle": 150,
            "Staff": 200
        }

    def draw_button(self, text, position, size=(200, 60), font_size=30, color=(0, 128, 255), text_color=(255, 255, 255)):
        """
        Desenha um botão na tela e exibe o texto.
        """
        x, y = position
        button_rect = pygame.Rect(x, y, size[0], size[1])
        pygame.draw.rect(self.screen, color, button_rect)
        font = pygame.font.SysFont('Arial', font_size)
        text_surface = font.render(text, True, text_color)
        text_rect = text_surface.get_rect(center=button_rect.center)
        self.screen.blit(text_surface, text_rect)
        return button_rect

    def display_message(self, message, position=(400, 300), font_size=50, color=(255, 255, 255)):
        """
        Exibe uma mensagem na tela.
        """
        font = pygame.font.SysFont('Arial', font_size)
        text = font.render(message, True, color)
        text_rect = text.get_rect(center=position)
        self.screen.blit(text, text_rect)

    def handle_interface_events(self, buttons):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            for button_text, button_rect in buttons.items():
                if self.is_button_clicked(button_rect, event):
                    if button_text == "Back":
                        return "back"
                    elif button_text in self.weapon_prices:
                        return button_text  # Retorna o nome da arma comprada
        return None

    @staticmethod
    def is_button_clicked(button_rect, event):
        """
        Verifica se um botão foi clicado.
        """
        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse_x, mouse_y = event.pos
            if button_rect.collidepoint(mouse_x, mouse_y):
                return True
        return False

    def under_construction(self, player):
        running = True
        while running:
            self.screen.fill(self.deep_black)

            # Botões de compra para as armas (incluindo preços e verificação de dinheiro)
            espingarda_text = f"Espingarda ({self.weapon_prices['Shotgun']})"
            rifle_text = f"Rifle ({self.weapon_prices['Rifle']})"
            cajado_text = f"Cajado ({self.weapon_prices['Staff']})"

            espingarda_button_rect = self.draw_button(espingarda_text, (300, 250))
            rifle_button_rect = self.draw_button(rifle_text, (300, 350))
            cajado_button_rect = self.draw_button(cajado_text, (300, 450))

            # Botão de voltar
            back_rect = self.draw_button("Back", (450, 600), size=(140, 60), color=self.dark_red)

            action = self.handle_interface_events({
                espingarda_text: espingarda_button_rect,
                rifle_text: rifle_button_rect,
                cajado_text: cajado_button_rect,
                "Back": back_rect
            })

            # Verifica eventos de clique e se o jogador tem dinheiro suficiente
            if action == espingarda_text:
                if player.money >= self.weapon_prices["Shotgun"]:
                    player.unlock_weapon("Espingarda")
                    print("compraste Espingarda")
                else:
                    self.display_message("Dinheiro insuficiente!", (self.resolution[0] // 2, 550))
            elif action == rifle_text:
                if player.money >= self.weapon_prices["Rifle"]:
                    player.unlock_weapon("Rifle")
                    print("compraste Rifle")
                else:
                    self.display_message("Dinheiro insuficiente!", (self.resolution[0] // 2, 550))
            elif action == cajado_text:
                if player.money >= self.weapon_prices["Staff"]:
                    player.unlock_weapon("Cajado")
                    print("compraste Cajado")
                else:
                    self.display_message("Dinheiro insuficiente!", (self.resolution[0] // 2, 550))
            elif action == "back":
                running = False

            player.render_money(self.screen)

            pygame.display.update()



