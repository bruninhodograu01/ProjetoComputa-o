#game.py


import pygame
from utils import Settings
from player import Player
from game.game_states.mainstate import MainGameState
from game.game_states.shedstate import ShedState
from game.game_states.upperstate import UpperState

class Game:
    def __init__(self):
        self.screen = pygame.display.set_mode((Settings.WIDTH, Settings.HEIGHT))  # Criação da tela
        self.player = Player(self)  # Passando a instância de Game para o jogador
        self.spawn_rate = 1.0  # A taxa inicial de spawn de inimigos
        self.bullets = pygame.sprite.Group()
        self.enemies = pygame.sprite.Group()
        self.powerups = pygame.sprite.Group()
        self.chests = pygame.sprite.Group()
        self.state = None  # Estado atual do jogo
        self._player_entry_position = (0, 0)

    def set_player_entry_position(self, position):
        self._player_entry_position = position

    def get_player_entry_position(self):
        return self._player_entry_position
    def change_state(self, state):
        """Muda o estado atual para o novo estado."""
        self.state = state



def game_loop():
    pygame.display.set_caption("Wilderness Explorer")
    clock = pygame.time.Clock()

    # Inicializa o jogo com a classe Game
    game = Game()  # Agora é uma instância de Game, não um dicionário
    states = {
        "main": MainGameState,
        "shed": ShedState,
        "upper": UpperState,
    }

    current_state_name = "main"
    current_state = states[current_state_name](game)  # Instancia o primeiro estado
    game.change_state(current_state)  # Define o estado atual no objeto Game

    while current_state:
        next_state_name = current_state.run()  # Executa o estado atual

        if next_state_name:
            # Troca para o próximo estado
            if next_state_name in states:
                next_state = states[next_state_name](game)
                game.change_state(next_state)  # Atualiza o estado no objeto Game
                current_state = next_state
            else:
                print(f"Estado desconhecido: {next_state_name}")
                break
        else:
            break  # Sai do loop se não houver próximo estado

        clock.tick(Settings.FPS)

    pygame.quit()



