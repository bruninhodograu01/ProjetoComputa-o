import math
from utils import Settings, draw_health_bar, draw_exp_bar, draw_money
from powerups import *
from bullet import Bullet
from enemy import Zombie, Boss
from player import Player
from chest import Chest

# Inicialização da tela e da instância de Utils
screen = pygame.display.set_mode((720, 720))
pygame.display.set_caption("Game State")
middle_top = Settings.HEIGHT // 2 - 50
middle_bottom = Settings.HEIGHT // 2 + 50

class MainGameState:
    def __init__(self, game, spawn_rate=0.5, enemy_limit=1, powerup_chances=None):
        self.game = game
        self.next_state = None
        self.bullets = pygame.sprite.Group()
        self.enemies = pygame.sprite.Group()
        self.powerups = pygame.sprite.Group()
        self.chests = pygame.sprite.Group()  # Grupo para os baús
        self.screen = screen
        self.spawn_rate = spawn_rate
        self.enemy_limit = enemy_limit
        self.zombies_generated = 0  # Número total de zombies gerados
        self.enemy_cooldown = Settings.FPS * self.spawn_rate
        self.enemy_counter = 0
        self.player = Player(game)
        self.boss_spawned = False  # Indica se o Boss já foi gerado
        self.active_powerup = None  # Variável para controlar o power-up ativo

        # Probabilidades de spawn dos power-ups
        if powerup_chances is None:
            powerup_chances = {
                "InvincibilityPU": 0.2,  # 20% de chance de gerar
                "DespawnerPU": 0.1,  # 10% de chance de gerar
                "RegenBoostPU": 0.3,  # 30% de chance de gerar
                "HealthRegenPU": 0.3,  # 30% de chance de gerar
                "DamageBoostPU": 0.1,  # 10% de chance de gerar
            }
        self.powerup_chances = powerup_chances

    def spawn_powerup(self):
        """Gera um power-up aleatoriamente com base nas probabilidades."""
        if self.active_powerup is None:  # Só gera se não houver power-up ativo
            rand_value = random.random()  # Gera um número aleatório entre 0 e 1
            cumulative_probability = 0.0

            for powerup_class_name, chance in self.powerup_chances.items():
                cumulative_probability += chance
                if rand_value <= cumulative_probability:
                    # Determina a posição aleatória na tela para o power-up
                    x = random.randint(0, Settings.WIDTH)
                    y = random.randint(0, Settings.HEIGHT)
                    # Instancia o power-up de acordo com a classe
                    powerup_class = globals()[powerup_class_name]
                    powerup = powerup_class(x, y, duration=300)  # A duração pode ser configurada
                    self.powerups.add(powerup)
                    self.active_powerup = powerup  # Marca o power-up como ativo
                    print(f"Power-up {powerup_class_name} gerado!")
                    return

    def handle_collisions(self):
        """Verifica colisões entre balas e inimigos ou jogador e aplica dano se houver colisão."""
        for bullet in self.bullets:
            # Verificar colisões entre a bala e inimigos
            for enemy in pygame.sprite.spritecollide(bullet, self.enemies, False):
                enemy.take_damage(bullet.damage, self.player)

                if bullet.origin != enemy:  # Evitar que balas de inimigos colidam com outros inimigos
                    enemy.take_damage(bullet.damage, self.player)  # Chama o método take_damage
                    bullet.kill()

        self.check_player_powerup_collision()

    def check_player_powerup_collision(self):
        for powerup in self.powerups:
            if isinstance(powerup, PowerUp):  # Verifica se é um power-up
                if powerup.rect.colliderect(self.player.rect):
                    powerup.affect_player(self.player)

    def spawn_enemy(self):
        """Cria e adiciona novos zombies até atingir o limite definido."""
        if self.zombies_generated < self.enemy_limit:
            # Atributos do zombie
            health = 100
            damage = 10
            speed = 2
            exp_reward = 50
            money_reward = random.randint(5, 15)

            # Gerar posição aleatória
            x = random.randint(0, Settings.WIDTH)
            y = random.randint(0, Settings.HEIGHT)

            # Criar e adicionar zombie
            zombie = Zombie(x, y, health, damage, speed, exp_reward, money_reward)
            self.enemies.add(zombie)
            self.zombies_generated += 1  # Incrementar o contador de zombies gerados
            print(f"Zombie gerado! ({self.zombies_generated}/{self.enemy_limit})")

    def spawn_boss(self):
        """Gera o Boss no centro da tela."""
        if not self.boss_spawned:
            health = 500
            damage = 30
            speed = 1
            exp_reward = 300
            money_reward = random.randint(30, 60)
            boss = Boss(Settings.WIDTH // 2, Settings.HEIGHT // 2, health, damage, speed, exp_reward, money_reward)
            self.enemies.add(boss)
            self.boss_spawned = True

            print("Boss gerado no centro da tela!")

    def check_victory(self):
        """Verifica se todos os zombies e o boss foram derrotados."""
        if len(self.enemies) == 0:
            print("Todos os inimigos derrotados! Transição para o próximo estado.")
            self.next_state = "next_state"
            return True
        return False

    def check_all_enemies_defeated(self):
        """Verifica se todos os inimigos (zombies) foram derrotados e faz a transição de estado."""
        if len(self.enemies) == 0:  # Se não houverem mais zombies nem boss
            print("Todos os inimigos derrotados! Transitando para o estado 'next_state'.")
            self.next_state = "next_state"  # Nome do próximo estado
            return True
        return False

    def check_boss_defeated(self):
        """Verifica se o Boss foi derrotado e gera um baú com chance."""
        if self.boss_spawned and len([enemy for enemy in self.enemies if isinstance(enemy, Boss)]) == 0:
            # Chance de 10% de gerar o baú
            if random.random() < 0.1:  # Aqui pode ajustar a probabilidade
                chest = Chest(self.player.rect.x, self.player.rect.y, self.player)  # Coloca o baú perto do jogador
                self.chests.add(chest)  # Adiciona o baú ao grupo de baús
            return True
        return False

    def check_player_chest_collision(self):
        """Abre automaticamente o baú quando o jogador passar por cima."""
        for chest in self.chests:
            if chest.rect.colliderect(self.player.rect) and not chest.opened:
                chest.open()

    def run(self):
        """Metodo principal do estado atual do jogo, onde verificamos as condições de transição."""
        clock = pygame.time.Clock()
        background = pygame.image.load("images/most_perfect_thing.jpeg")
        background = pygame.transform.scale(background, Settings.RESOLUTION)

        player = self.game.player
        player_group = pygame.sprite.Group(player)

        running = True
        while running:
            clock.tick(Settings.FPS)
            self.screen.blit(background, (0, 0))

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    exit()

                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    self.shoot(player, pygame.mouse.get_pos())

                if event.type == pygame.KEYDOWN:
                    if event.key in (pygame.K_1, pygame.K_2, pygame.K_3):
                        player.select_weapon(event.key - pygame.K_1)

                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    for chest in self.chests:
                        chosen_powerup = chest.check_click(event.pos)
                        if chosen_powerup:
                            chest.improve_powerup(chosen_powerup)
                            self.chests.remove(chest)  # Remove o baú após escolher


            self.bullets.update()
            self.spawn_enemy()
            self.check_player_powerup_collision()
            self.check_player_chest_collision()  # Abre baús automaticamente
            self.powerups.update()
            self.chests.update()  # Atualiza os baús
            player_group.update()  # Atualiza os estados dos sprites
            for sprite in player_group:
                sprite.render(screen)  # Desenha os sprites

            self.chests.draw(self.screen)
            for chest in self.chests:
                if chest.opened:
                    chest.display_options(self.screen)

            # Gerar o boss somente se todos os zombies foram derrotados
            if len([enemy for enemy in self.enemies if isinstance(enemy, Zombie)]) == 0:
                if self.zombies_generated >= self.enemy_limit and not self.boss_spawned:
                    self.spawn_boss()

            # Gerar power-ups com base nas probabilidades
            if random.random() < 0.1 and self.active_powerup is None:  # Garante que apenas um power-up será gerado de cada vez
                self.spawn_powerup()

            for enemy in self.enemies:
                enemy.update(player, self.bullets, self.enemies)

            self.handle_collisions()

            draw_health_bar(self.screen, 70, 20, player.health, player.max_health)
            draw_exp_bar(self.screen, self.player, x=70, y=41)
            draw_money(screen, player)


            player_group.draw(self.screen)
            self.enemies.draw(self.screen)
            self.bullets.draw(self.screen)
            self.powerups.draw(self.screen)  # Desenha os power-ups

            pygame.display.flip()

            if player.weapon_cooldown > 0:
                player.weapon_cooldown -= 1

            if self.check_boss_defeated():
                if player.rect.right >= Settings.WIDTH and middle_top <= player.rect.centery <= middle_bottom:
                    print("Jogador derrotou o Boss e saiu para o próximo estado.")  # Debug
                    self.game.set_player_entry_position((0, player.rect.y))
                    self.next_state = "shed"  # Define o próximo estado
                    running = False


        return self.next_state

    def handle_bau_interaction(self, event, chest):
        """Verifica se o jogador clicou em uma das opções do baú."""
        if event.type == pygame.MOUSEBUTTONDOWN:
            if chest.rect.collidepoint(event.pos):  # Verifica se o clique foi dentro do baú
                chest.display_options(self.screen)
                mouse_x, mouse_y = pygame.mouse.get_pos()
                if chest.rect.collidepoint(mouse_x, mouse_y):
                    # Aqui você pode verificar em qual opção o jogador clicou
                    if mouse_y in range(chest.y + 40, chest.y + 80):  # Verifica a área da opção 1
                        chest.improve_powerup(chest.options[0])
                    elif mouse_y in range(chest.y + 80, chest.y + 120):  # Opção 2
                        chest.improve_powerup(chest.options[1])
                    elif mouse_y in range(chest.y + 120, chest.y + 160):  # Opção 3
                        chest.improve_powerup(chest.options[2])

    def shoot(self, player, mouse_pos):
        """Gerencia o disparo de balas do jogador."""
        if player.weapon_cooldown <= 0:
            angle = math.atan2(mouse_pos[1] - player.rect.centery, mouse_pos[0] - player.rect.centerx)
            weapon = player.get_current_weapon()
            bullet_pattern = weapon["pattern"]
            if bullet_pattern == "single":
                self.add_bullet(player, angle, weapon)
            elif bullet_pattern == "spread":
                for offset in [-weapon.get("spread", 15), 0, weapon.get("spread", 15)]:
                    self.add_bullet(player, angle + math.radians(offset), weapon)
            player.weapon_cooldown = weapon["cooldown"]

    def add_bullet(self, player, angle, weapon):
        """Cria uma bala e a adiciona ao grupo de balas."""
        bullet = Bullet(player.rect.centerx, player.rect.centery, angle, weapon["damage"], weapon["speed"], player)
        self.bullets.add(bullet)





