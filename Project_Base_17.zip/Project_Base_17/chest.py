
from powerups import *  # Certifique-se de que você tenha essas classes de power-ups no seu projeto
from utils import Settings


class Chest(pygame.sprite.Sprite):
    def __init__(self, x, y, player):
        super().__init__()
        self.x = x
        self.y = y
        self.image = pygame.image.load("images/mowed_grass.jpg")
        self.image = pygame.transform.scale(self.image, (50, 50))
        self.rect = self.image.get_rect(topleft=(self.x, self.y))
        self.player = player
        self.opened = False
        self.options = []  # Armazena as opções fixas após abrir

        # Todas as opções de power-ups possíveis
        all_options = ["DamageBoostPU", "HealthRegenPU", "RegenBoostPU", "InvincibilityPU", "DespawnerPU"]

        # Selecionar 3 opções aleatórias a partir das disponíveis
        self.options = random.sample(all_options, 3)

        self.chosen_options = []  # Armazena as opções geradas

        # Blocos interativos
        self.option_rects = [
            pygame.Rect(Settings.WIDTH // 2 - 100, Settings.HEIGHT // 2 - 60, 200, 40),
            pygame.Rect(Settings.WIDTH // 2 - 100, Settings.HEIGHT // 2, 200, 40),
            pygame.Rect(Settings.WIDTH // 2 - 100, Settings.HEIGHT // 2 + 60, 200, 40),
        ]

    def open(self):
        """Gera 3 opções de power-ups aleatórios."""
        if not self.opened:
            self.chosen_options = random.sample(self.options, 3)
            self.opened = True

    def display_options(self, screen):
        """Renderiza as opções de escolha."""
        if self.opened:
            font = pygame.font.Font(None, 36)
            for i, option in enumerate(self.chosen_options):
                text = font.render(option, True, (255, 255, 255))
                pygame.draw.rect(screen, (0, 0, 0), self.option_rects[i])  # Fundo do bloco
                pygame.draw.rect(screen, (255, 255, 255), self.option_rects[i], 2)  # Borda
                screen.blit(text, (self.option_rects[i].x + 10, self.option_rects[i].y + 5))

    def check_click(self, pos):
        """Verifica se o jogador clicou numa opção."""
        if self.opened:
            for i, rect in enumerate(self.option_rects):
                if rect.collidepoint(pos):
                    return self.options[i]
        return None

    def improve_powerup(self, powerup_type):
        """Melhora o Power-up escolhido."""
        if powerup_type == 'DamageBoostPU':
            self.upgrade_damage_boost()
        elif powerup_type == 'HealthRegenPU':
            self.upgrade_health_regen()
        elif powerup_type == 'RegenBoostPU':
            self.upgrade_regen_boost()
        elif powerup_type == 'InvincibilityPU':
            self.upgrade_invincibility()
        elif powerup_type == 'DespawnerPU':
            self.upgrade_despawner()

    def upgrade_damage_boost(self):
        """Melhora o dano do Power-up DamageBoost."""
        if hasattr(self.player, 'damage_boost'):
            self.player.damage_boost += 5  # Exemplo de melhorar o efeito

    def upgrade_health_regen(self):
        """Melhora a regeneração de saúde do Power-up HealthRegen."""
        if hasattr(self.player, 'health_regen_rate'):
            self.player.health_regen_rate += 1  # Exemplo de melhorar o efeito

    def upgrade_regen_boost(self):
        """Melhora a regeneração do boost do Power-up RegenBoost."""
        if hasattr(self.player, 'regen_boost_rate'):
            self.player.regen_boost_rate += 1  # Exemplo de melhorar o efeito

    def upgrade_invincibility(self):
        """Melhora a invencibilidade do Power-up Invincibility."""
        if hasattr(self.player, 'invincibility_duration'):
            self.player.invincibility_duration += 2  # Aumenta a duração da invencibilidade

    def upgrade_despawner(self):
        """Melhora o Power-up Despawner."""
        if hasattr(self.player, 'despawner_cooldown'):
            self.player.despawner_cooldown -= 1  # Reduz o cooldown do despawn (exemplo)




