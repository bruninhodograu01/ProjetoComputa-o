import pygame
import math
import random
from utils import Settings, draw_health_bar, draw_exp_bar
from bullet import Bullet
from enemy import Enemy
from powerups import InvincibilityPU, DespawnerPU, RegenBoostPU, HealthRegenPU, DamageBoostPU

# Inicialização da tela e da instância de Utils
screen = pygame.display.set_mode((720, 720))
pygame.display.set_caption("Game State")

class MainGameState:
    def __init__(self, game, spawn_rate=Settings.ENEMY_SPAWN_RATE, enemy_limit=Settings.ENEMY_LIMIT):
        self.game = game
        self.next_state = None
        self.bullets = pygame.sprite.Group()
        self.enemies = pygame.sprite.Group()
        self.powerups = pygame.sprite.Group()  # Grupo de power-ups
        self.screen = screen  # Referência ao objeto de tela global
        self.spawn_rate = spawn_rate
        self.enemy_limit = enemy_limit
        self.enemy_cooldown = Settings.FPS * self.spawn_rate
        self.enemy_counter = 0

    def spawn_enemy(self):
        """Cria e adiciona um novo inimigo à lista de inimigos, se o limite não for atingido."""
        if self.enemy_counter < self.enemy_limit:
            enemy = Enemy()
            self.enemies.add(enemy)
            self.enemy_counter += 1
            print(f"Novo inimigo gerado {self.enemy_counter}!")

    def handle_collisions(self):
        """Verifica colisões entre balas e inimigos e aplica dano se houver colisão."""
        for bullet in self.bullets:
            for enemy in pygame.sprite.spritecollide(bullet, self.enemies, False):
                enemy.health -= bullet.damage
                bullet.kill()
                if enemy.health <= 0:
                    enemy.kill()
                    print("Inimigo derrotado!")

        # Verifica colisões entre o jogador e os power-ups
        self.check_player_powerup_collision(self.game["player"])

    def spawn_powerup(self):
        """Spawn um Power-up aleatoriamente com uma certa probabilidade."""
        if random.random() < 0.1:  # 10% de chance de aparecer um Power-up
            powerup_type = random.choice([
                InvincibilityPU, DespawnerPU,
                RegenBoostPU, HealthRegenPU, DamageBoostPU
            ])
            x = random.randint(0, Settings.WIDTH)
            y = random.randint(0, Settings.HEIGHT)
            duration = random.randint(200, 500)  # Duração aleatória
            powerup = powerup_type(x, y, duration)
            self.powerups.add(powerup)
            print("Power-up gerado!")

    def check_player_powerup_collision(self, player):
        """Verifica se o jogador pegou um Power-up."""
        for powerup in self.powerups:
            if player.rect.colliderect(pygame.Rect(powerup.x, powerup.y, 32, 32)):  # Supondo que o Power-up tenha 32x32
                powerup.affect_player(player)
                powerup.is_active = True  # Ativa o efeito do Power-up
                powerup.affect_game(self.game)  # Aplica o efeito no jogo
                powerup.kill()  # Remove o Power-up da tela
                print(f"Power-up {powerup.__class__.__name__} pego!")

    def run(self):
        clock = pygame.time.Clock()
        background = pygame.image.load("images/most_perfect_thing.jpeg")
        background = pygame.transform.scale(background, Settings.RESOLUTION)

        player = self.game["player"]
        player_group = pygame.sprite.Group(player)

        running = True
        while running:
            clock.tick(Settings.FPS)
            self.screen.blit(background, (0, 0))

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    exit()

                # Verifica clique para atirar
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    self.shoot(player, pygame.mouse.get_pos())

                # Verifica teclas para trocar de arma
                if event.type == pygame.KEYDOWN:
                    if event.key in (pygame.K_1, pygame.K_2, pygame.K_3):
                        player.select_weapon(event.key - pygame.K_1)

            player_group.update()
            self.bullets.update()

            # Verifica colisões entre balas e inimigos
            self.handle_collisions()

            # Verifica colisões de power-ups com o jogador
            self.spawn_powerup()

            for enemy in self.enemies:
                enemy.update(player, self.bullets, self.enemies)

            # Verifica se todos os inimigos foram derrotados antes de permitir a transição
            if not self.enemies:
                if player.rect.right >= Settings.WIDTH and middle_top <= player.rect.centery <= middle_bottom:
                    print("Jogador saiu para o estado 'shed'")
                    self.game["player_entry_position"] = (0, player.rect.y)
                    self.next_state = "shed"
                    return self.next_state

            # Adiciona inimigos com base no cooldown
            if self.enemy_cooldown <= 0:
                self.spawn_enemy()
                self.enemy_cooldown = Settings.FPS * self.spawn_rate
            self.enemy_cooldown -= 1

            draw_health_bar(self.screen, 70, 20, player.health, player.max_health)
            draw_exp_bar(self.screen, 70, 50, player.exp, player.exp_to_next_level, player.level)

            player_group.draw(self.screen)
            self.enemies.draw(self.screen)
            self.powerups.draw(self.screen)  # Desenha os power-ups na tela
            for bullet in self.bullets:
                bullet.draw(self.screen)

            pygame.display.flip()

    def shoot(self, player, mouse_pos):
        """Gerencia o disparo de balas do jogador com base na arma selecionada."""
        if player.weapon_cooldown <= 0:
            angle = math.atan2(mouse_pos[1] - player.rect.centery, mouse_pos[0] - player.rect.centerx)
            weapon = player.get_current_weapon()
            bullet_pattern = weapon["pattern"]
            if bullet_pattern == "single":
                self.add_bullet(player, angle, weapon)
            elif bullet_pattern == "spread":
                for offset in [-weapon.get("spread", 15), 0, weapon.get("spread", 15)]:
                    self.add_bullet(player, angle + math.radians(offset), weapon)

            player.weapon_cooldown = weapon["cooldown"]

    def add_bullet(self, player, angle, weapon):
        """Cria uma bala e a adiciona ao grupo de balas."""
        bullet = Bullet(player.rect.centerx, player.rect.centery, angle, weapon["damage"], weapon["speed"], player)
        self.bullets.add(bullet)



