#player

import pygame
import math
from utils import Settings

class Player(pygame.sprite.Sprite):
    def __init__(self, game):
        super().__init__()
        self.game = game
        self.powerups = pygame.sprite.Group()
        self.original_image = pygame.image.load("images/player_with_gun.png").convert_alpha()
        self.image = self.original_image
        self.rect = self.image.get_rect()
        self.rect.center = (Settings.WIDTH // 2, Settings.HEIGHT // 2)
        self.is_invincible = False
        self.color = (255, 255, 255)
        self.direction = 0
        self.alive = True
        self.aura_color = None
        self.aura_duration = 0

        # Atributos do jogador
        self.speed = 3
        self.health_regen_multiplier = 1
        self.damage_multiplier = 1
        self.damage = 10
        self.health = 100
        self.max_health = 100

        # exp and money
        self.money = 0
        self.level = 1
        self.exp = 0
        self.exp_to_next_level = 100

        # regen
        self.regen_rate = 1
        self.regen_cooldown = 120  # 2 segundos
        self.regen_timer = 0

        # weapons
        self.weapon_cooldown = 0  # d da arma
        self.weapons = [
            {"name": "Pistola", "damage": 10, "speed": 7, "pattern": "single", "cooldown": 10},
            {"name": "Espingarda", "damage": 15, "speed": 5, "pattern": "spread", "spread": 20, "cooldown": 30},
            {"name": "Rifle", "damage": 20, "speed": 10, "pattern": "single", "cooldown": 5},
        ]
        self.current_weapon_index = 0
        self.cooldown = self.weapons[self.current_weapon_index]["cooldown"]



    def get_current_weapon(self):
        return self.weapons[self.current_weapon_index]

    def select_weapon(self, index):
        if 0 <= index < len(self.weapons):
            self.current_weapon_index = index
            self.cooldown = self.weapons[self.current_weapon_index]["cooldown"]
            print(f"Arma selecionada: {self.weapons[index]['name']}")

    def gain_money(self, amount):
        """Método para o jogador ganhar dinheiro ao derrotar inimigos."""
        if amount is not None:
            self.money += amount
        else:
            print("Erro: amount é None")



    def render_money(self, screen):
        """Método para renderizar a quantidade de dinheiro na tela."""
        font = pygame.font.Font(None, 36)  # Escolhe a fonte e o tamanho
        money_text = font.render(f"Dinheiro: ${self.money}", True, (255, 255, 255))  # Cor do texto
        screen.blit(money_text, (10, 10))

    def level_up(self):
        self.level += 1
        self.exp_to_next_level = int(self.exp_to_next_level * 1.5)
        self.max_health += 10
        self.health = self.max_health
        print(f"Subiu de nível! Nível atual: {self.level}")

    def gain_exp(self, amount):
        self.exp += amount
        while self.exp >= self.exp_to_next_level:
            self.exp -= self.exp_to_next_level
            self.level_up()

    def update(self):
        # Atualiza o estado do jogador (sem desenhar no ecrã)
        self.damage = 10 * self.damage_multiplier

        if self.aura_duration > 0:
            self.aura_duration -= 1
        else:
            self.aura_color = None

        self.handle_movement()
        self.update_direction()
        self.handle_regeneration()
        self.check_player_powerup_collision()

    def render(self, screen):
        # Desenha o jogador e elementos visuais
        if self.aura_color:
            pygame.draw.circle(
                screen,
                self.aura_color,
                self.rect.center,
                self.rect.width // 2 + 10,  # Tamanho da aura
                4  # Largura da borda
            )
        screen.blit(self.image, self.rect)

    def handle_movement(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_w] and self.rect.top > 0:
            self.rect.y -= self.speed
        if keys[pygame.K_s] and self.rect.bottom < Settings.HEIGHT:
            self.rect.y += self.speed
        if keys[pygame.K_a] and self.rect.left > 0:
            self.rect.x -= self.speed
        if keys[pygame.K_d] and self.rect.right < Settings.WIDTH:
            self.rect.x += self.speed

    def handle_regeneration(self):
        self.regen_timer += 1
        if self.regen_timer >= self.regen_cooldown and self.health < self.max_health:
            self.health += self.regen_rate
            self.health = min(self.health, self.max_health)
            self.regen_timer = 0

    def update_direction(self):
        mouse_x, mouse_y = pygame.mouse.get_pos()
        rel_x = mouse_x - self.rect.centerx
        rel_y = mouse_y - self.rect.centery
        angle = math.degrees(math.atan2(rel_y, rel_x))
        self.direction = angle
        self.image = pygame.transform.rotate(self.original_image, -self.direction)
        self.rect = self.image.get_rect(center=self.rect.center)

    def check_player_powerup_collision(self):
        for powerup in self.powerups:
            if self.rect.colliderect(powerup.rect):  # Usar powerup.rect diretamente
                powerup.affect_player(self)  # Aplica o efeito no jogador
                powerup.is_active = True  # Marca o power-up como ativo (se necessário)
                powerup.affect_game(self.game)  # Aplica o efeito no jogo (se necessário)
                powerup.kill()  # Remove o power-up do jogo
                print("Power-up apanhado!")  # Para depuração

    def die(self):
        """Método chamado quando o jogador morre."""
        print("O jogador morreu!")
        # Aqui pode adicionar lógica para o fim do jogo ou reiniciar
        self.alive = False  # Marque o jogador como morto
        self.kill()  # Remove o sprite do jogador (se necessário)

    def take_damage(self, amount):
        """Método para reduzir a saúde do jogador quando ele é atingido."""
        self.health -= amount
        if self.health <= 0:
            self.health = 0
            self.die()  # Lógica de morte do jogador, se necessário









