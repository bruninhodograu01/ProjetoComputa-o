
from powerups import *  # Certifique-se de que você tenha essas classes de power-ups no seu projeto

class Chest(pygame.sprite.Sprite):
    def __init__(self, x, y, player):
        super().__init__()
        self.x = x
        self.y = y
        self.image = pygame.image.load("images/mowed_grass.jpg")  # Imagem do baú
        self.image = pygame.transform.scale(self.image, (50, 50))  # Reduz a imagem do baú para 50x50 pixels
        self.rect = self.image.get_rect(topleft=(self.x, self.y))

        # As opções de power-up e os pesos associados a cada um
        self.options = ["InvincibilityPU", "DespawnerPU", "HealthRegenPU", "RegenBoostPU", "DamageBoostPU"]
        self.weights = [1, 1, 3, 3, 2]  # Pesos (quanto maior o número, mais provável o power-up)

        self.player = player  # Referência ao jogador

    def get_random_powerups(self):
        """Escolhe 3 power-ups aleatórios com base nos pesos."""
        return random.choices(self.options, weights=self.weights, k=3)

    def display_options(self, screen):
        """Exibe as 3 opções de Power-up para o jogador escolher."""
        font = pygame.font.Font(None, 36)
        chosen_options = random.sample(self.options, 3)  # Escolhe 3 opções aleatórias
        text1 = font.render(f"1. {chosen_options[0]}", True, (255, 255, 255))
        text2 = font.render(f"2. {chosen_options[1]}", True, (255, 255, 255))
        text3 = font.render(f"3. {chosen_options[2]}", True, (255, 255, 255))

        screen.blit(text1, (self.x, self.y + 40))
        screen.blit(text2, (self.x, self.y + 80))
        screen.blit(text3, (self.x, self.y + 120))

    def improve_powerup(self, powerup_type):
        """Melhora o Power-up escolhido."""
        if powerup_type == 'DamageBoostPU':
            self.upgrade_damage_boost()
        elif powerup_type == 'HealthRegenPU':
            self.upgrade_health_regen()
        elif powerup_type == 'RegenBoostPU':
            self.upgrade_regen_boost()
        elif powerup_type == 'InvincibilityPU':
            self.upgrade_invincibility()
        elif powerup_type == 'DespawnerPU':
            self.upgrade_despawner()

    def upgrade_damage_boost(self):
        """Melhora o dano do Power-up DamageBoost."""
        if hasattr(self.player, 'damage_boost'):
            self.player.damage_boost += 5  # Exemplo de melhorar o efeito

    def upgrade_health_regen(self):
        """Melhora a regeneração de saúde do Power-up HealthRegen."""
        if hasattr(self.player, 'health_regen_rate'):
            self.player.health_regen_rate += 1  # Exemplo de melhorar o efeito

    def upgrade_regen_boost(self):
        """Melhora a regeneração do boost do Power-up RegenBoost."""
        if hasattr(self.player, 'regen_boost_rate'):
            self.player.regen_boost_rate += 1  # Exemplo de melhorar o efeito

    def upgrade_invincibility(self):
        """Melhora a invencibilidade do Power-up Invincibility."""
        if hasattr(self.player, 'invincibility_duration'):
            self.player.invincibility_duration += 2  # Aumenta a duração da invencibilidade

    def upgrade_despawner(self):
        """Melhora o Power-up Despawner."""
        if hasattr(self.player, 'despawner_cooldown'):
            self.player.despawner_cooldown -= 1  # Reduz o cooldown do despawn (exemplo)

    def open_chest(self):
        """Abre o baú e gera as opções de power-up para o jogador escolher."""
        chosen_options = self.get_random_powerups()
        # O jogador escolhe uma das opções e a melhora
        for option in chosen_options:
            self.improve_powerup(option)


