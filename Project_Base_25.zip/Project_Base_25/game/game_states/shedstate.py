import pygame
from utils import Settings, draw_health_bar, draw_exp_bar, draw_money
from underC import Underc


# Inicialize a tela e a instância de Utils fora das classes

pygame.display.set_caption("Game State")


class ShedState:
    def __init__(self, game):
        self.game = game
        self.screen = Settings.SCREEN
        self.player = self.game.player  # Use a instância de player já carregada
        self.underC = Underc(pygame.display.get_surface(), self.player)  # Passa o player também
        # Referência à instância de Utils
        self.next_state = None  # Define o atributo aqui
        self.player.load_player_progress()

    def save_game(self):
        """Salva o estado atual do jogo, incluindo o progresso do jogador."""
        self.player.save_player_progress()
        print("Jogo salvo!")

    def load_game(self):
        """Carrega o progresso salvo do jogador."""
        self.player.load_player_progress()
        print("Jogo carregado!")

    def run(self):
        screen = pygame.display.get_surface()
        clock = pygame.time.Clock()
        background = pygame.image.load("images/farm.png")
        background = pygame.transform.scale(background, Settings.RESOLUTION)

        player = self.game.player  # Certifique-se de usar a instância correta de player
        player_group = pygame.sprite.Group()
        player_group.add(player)

        special_area = pygame.Rect(530, 30, 140, 140)

        # Alterado aqui para acessar a posição corretamente
        entry_position = self.game.get_player_entry_position()

        if entry_position:
            entry_x, entry_y = entry_position
            player.rect.topleft = (entry_x, entry_y)

        running = True
        while running:
            clock.tick(Settings.FPS)
            screen.blit(background, (0, 0))

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    exit()

                if event.type == pygame.KEYDOWN:  # Verifica se é um evento de pressionamento de tecla
                    if event.key == pygame.K_9:  # Salva o jogo
                        self.save_game()

            player_group.update()

            # Verifique se o jogador entrou na área especial (a casa)
            if special_area.colliderect(player.rect):
                print("Jogador entrou na área especial (a casa).")
                # Dentro do método run() da classe ShedState
                self.underC.under_construction(self.game.player)  # Passa o player corretamente

            if player.rect.left <= 0 and Settings.MIDDLE_TOP <= player.rect.centery <= Settings.MIDDLE_BOTTOM:
                print("Jogador saiu para o estado 'main'")
                self.save_game()
                player.rect.left = Settings.WIDTH - player.rect.width
                self.next_state = "main"
                return self.next_state

            if player.rect.top <= 0 and Settings.MIDDLE_TOP <= player.rect.centerx <= Settings.MIDDLE_BOTTOM:
                print("Jogador subiu para o estado 'upper'")
                self.save_game()
                self.game.set_player_entry_position((player.rect.x, Settings.HEIGHT - player.rect.height))
                self.next_state = "level1"
                return self.next_state

            player_group.draw(screen)
            draw_health_bar(self.screen, 70, 20, player.health, player.max_health)
            draw_exp_bar(self.screen, self.player, x=70, y=41)
            draw_money(self.screen, player)

            pygame.display.flip()


