import pygame
from utils import *

class Underc:
    def __init__(self, screen, player):
        self.screen = screen
        self.resolution = Settings.RESOLUTION
        self.deep_black = Colors.DEEP_BLACK
        self.white = Colors.WHITE
        self.dark_red = Colors.DARK_RED
        self.player = player

        # Preços das armas
        self.weapon_prices = {
            "Espingarda": 100,
            "Rifle": 150,
            "Cajado": 200
        }

    def draw_button(self, text, position, size=(200, 60), font_size=30, color=(0, 128, 255), text_color=(255, 255, 255)):
        x, y = position
        button_rect = pygame.Rect(x, y, size[0], size[1])
        pygame.draw.rect(self.screen, color, button_rect)
        font = pygame.font.SysFont('Arial', font_size)
        text_surface = font.render(text, True, text_color)
        text_rect = text_surface.get_rect(center=button_rect.center)
        self.screen.blit(text_surface, text_rect)
        return button_rect

    def display_message(self, message, position=(400, 300), font_size=50, color=(255, 255, 255)):
        font = pygame.font.SysFont('Arial', font_size)
        text = font.render(message, True, color)
        text_rect = text.get_rect(center=position)
        self.screen.blit(text, text_rect)

    def handle_interface_events(self, buttons):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            for button_text, button_rect in buttons.items():
                if self.is_button_clicked(button_rect, event):
                    return button_text
        return None

    @staticmethod
    def is_button_clicked(button_rect, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse_x, mouse_y = event.pos
            if button_rect.collidepoint(mouse_x, mouse_y):
                return True
        return False

    def under_construction(self, player):
        running = True
        while running:
            self.screen.fill(self.deep_black)

            espingarda_text = "Espingarda"
            rifle_text = "Rifle"
            cajado_text = "Cajado"

            espingarda_button_rect = self.draw_button(
                f"{espingarda_text} ({self.weapon_prices['Espingarda']})" if not player.is_weapon_unlocked(
                    espingarda_text) else espingarda_text,
                (300, 250)
            )
            rifle_button_rect = self.draw_button(
                f"{rifle_text} ({self.weapon_prices['Rifle']})" if not player.is_weapon_unlocked(
                    rifle_text) else rifle_text,
                (300, 350)
            )
            cajado_button_rect = self.draw_button(
                f"{cajado_text} ({self.weapon_prices['Cajado']})" if not player.is_weapon_unlocked(
                    cajado_text) else cajado_text,
                (300, 450)
            )

            back_rect = self.draw_button("Back", (450, 600), size=(140, 60), color=self.dark_red)

            action = self.handle_interface_events({
                "Espingarda": espingarda_button_rect,
                "Rifle": rifle_button_rect,
                "Cajado": cajado_button_rect,
                "Back": back_rect
            })

            if action == "Espingarda" and not player.is_weapon_unlocked("Espingarda"):
                if player.money >= self.weapon_prices["Espingarda"]:
                    player.money -= self.weapon_prices["Espingarda"]
                    player.unlock_weapon("Espingarda")
                    self.display_message("Espingarda comprada!", (self.resolution[0] // 2, 550))
                else:
                    self.display_message("Dinheiro insuficiente!", (self.resolution[0] // 2, 550))
            elif action == "Rifle" and not player.is_weapon_unlocked("Rifle"):
                if player.money >= self.weapon_prices["Rifle"]:
                    player.money -= self.weapon_prices["Rifle"]
                    player.unlock_weapon("Rifle")
                    self.display_message("Rifle comprada!", (self.resolution[0] // 2, 550))
                else:
                    self.display_message("Dinheiro insuficiente!", (self.resolution[0] // 2, 550))
            elif action == "Cajado" and not player.is_weapon_unlocked("Cajado"):
                if player.money >= self.weapon_prices["Cajado"]:
                    player.money -= self.weapon_prices["Cajado"]
                    player.unlock_weapon("Cajado")
                    self.display_message("Cajado comprado!", (self.resolution[0] // 2, 550))
                else:
                    self.display_message("Dinheiro insuficiente!", (self.resolution[0] // 2, 550))
            elif action == "Back":
                running = False

            player.render_money(self.screen)
            pygame.display.update()





