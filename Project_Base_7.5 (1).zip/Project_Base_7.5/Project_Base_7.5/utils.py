# utils.py
import pygame



class Colors:
    DARK_RED = (138, 0, 0)  # Dark red for buttons
    DEEP_BLACK = (19, 20, 20)  # Almost black for background
    GREY = (59, 60, 60)  # Dark grey for alternate buttons
    WHITE = (254, 255, 255)  # White for readable text
    GLOWING_LIGHT_RED = (239, 128, 128)  # Light red for brighter text
    BLUE = (0, 0, 255)
    GREEN = (34, 139, 34)
    YELLOW = (255, 255, 0)
    RED = (150, 0, 24)
    CUTE_PURPLE = (128, 0, 128)
    GREENISH = (182, 215, 168)

class Settings:
    RESOLUTION = (720, 720)  # Screen resolution (width, height)
    WIDTH, HEIGHT = RESOLUTION
    FPS = 60  # Frames per second setting
    ENEMY_SPAWN_RATE = 5
    ENEMY_LIMIT = 10

class Sizes:
    PLAYER_SIZE = (50, 100)
    ENEMY_SIZE = (40, 40)
    BULLET_SIZE = 10


class Button:
    def __init__(self, text, rect, color, action=None):
        self.text = text
        self.rect = rect
        self.color = color
        self.action = action

    def draw(self, screen):
        """
        Desenha o botão na tela.
        """
        pygame.draw.rect(screen, self.color, self.rect)
        font = pygame.font.SysFont('Corbel', 50)
        text_surface = font.render(self.text, True, Colors.WHITE)
        text_rect = text_surface.get_rect(center=self.rect.center)
        screen.blit(text_surface, text_rect)

    def is_clicked(self, mouse_pos):
        """
        Verifica se o botão foi clicado.
        """
        return self.rect.collidepoint(mouse_pos)

    def click(self):
        """
        Executa a ação associada ao botão, se houver uma.
        """
        if self.action:
            self.action()


def draw_health_bar(screen, x, y, current_health, max_health):
    # Define o tamanho da barra
    bar_width = 200
    bar_height = 20

    # Calcula o preenchimento da barra com base na saúde atual
    fill_width = int((current_health / max_health) * bar_width)

    # Desenha a barra de fundo (vermelha)
    pygame.draw.rect(screen, (255, 0, 0), (x, y, bar_width, bar_height))

    # Desenha a barra preenchida (verde)
    pygame.draw.rect(screen, (0, 255, 0), (x, y, fill_width, bar_height))

    # Renderiza o texto da saúde atual e máxima
    font = pygame.font.Font(None, 24)  # Define o tipo e tamanho da fonte
    health_text = f"{current_health} / {max_health}"
    text_surface = font.render(health_text, True, (255, 255, 255))  # Cor branca
    text_rect = text_surface.get_rect(center=(x + bar_width // 2, y + bar_height // 2))

    # Desenha o texto sobre a barra
    screen.blit(text_surface, text_rect)

def check_bullet_collisions(bullet_group, enemies):
    for bullet in bullet_group:
        for enemy in enemies:
            if bullet.rect.colliderect(enemy.rect) and bullet.origin != enemy:
                enemy.health -= bullet.damage  # Aplica o dano ao inimigo
                if enemy.health <= 0:
                    enemy.kill()  # Remove o inimigo se a saúde for 0 ou menos
                bullet.kill()  # Remove a bala após causar dano


