#menu.py

import pygame
from utils import Colors, Button
from game import game

deep_black = Colors.DEEP_BLACK
white = Colors.WHITE
grey = Colors.GREY
dark_red = Colors.DARK_RED
glowing_light_red = Colors.GLOWING_LIGHT_RED



class Menu:
    def __init__(self, screen):
        self.mini_engine = None
        self.screen = screen
        self.buttons = self._initialize_buttons()

    def run(self):
        """
        Executa o loop do menu.
        """
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                self.handle_event(event)

            self.draw()
            pygame.display.update()

        pygame.quit()
    def _initialize_buttons(self):
        """
        Inicializa os botões do menu e os retorna em uma lista.
        """
        buttons = [
            Button("Wilderness Explorer", pygame.Rect(90, 240, 540, 60), dark_red, self.wilderness_explorer),
            Button("Rules", pygame.Rect(90, 480, 140, 60), grey, self.rules),
            Button("Options", pygame.Rect(90, 600, 140, 60), grey, self.options),
            Button("Quit", pygame.Rect(450, 600, 140, 60), grey, self.quit),
            Button("Credits", pygame.Rect(450, 480, 140, 60), grey, self.credits),
            Button("Mini-engine", pygame.Rect(300, 350, 100, 60), grey, self.mini_engine)

        ]
        return buttons

    def draw(self):
        """
        Desenha todos os botões na tela.
        """
        self.screen.fill(deep_black)
        for button in self.buttons:
            button.draw(self.screen)

        # Adiciona o título do projeto
        font = pygame.font.SysFont('Comic Sans MS', 50)
        title_text = font.render("Computation III - Project", True, glowing_light_red)
        self.screen.blit(title_text, (55, 0))

    def handle_event(self, event):
        """
        Trata eventos de clique nos botões.
        """
        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse_pos = event.pos
            for button in self.buttons:
                if button.is_clicked(mouse_pos):
                    button.click()



    def wilderness_explorer(self):
        game.game_loop()
        print("Iniciando o jogo...")  # Substitua com a lógica do jogo

    def rules(self):
        """
        Função para exibir as regras.
        """
        print("Exibindo regras...")  # Substitua com a lógica das regras

    def options(self):
        """
        Função para exibir as opções.
        """
        print("Exibindo opções...")  # Substitua com a lógica das opções

    def quit(self):
        """
        Função para sair do jogo.
        """
        pygame.quit()

    def credits(self):
        """
        Função para exibir os créditos.
        """
        print("Exibindo créditos...")  # Substitua com a lógica dos créditos
