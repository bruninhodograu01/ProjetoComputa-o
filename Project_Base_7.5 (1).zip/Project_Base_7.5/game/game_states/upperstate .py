# upperstate.py
import pygame
from game.game_states.ShedState import ShedState
from utils import Settings, draw_health_bar

class upperstate:
    def __init__(self, screen, game):
        self.screen = screen
        self.game = game  # Adiciona o jogo para acessar o jogador e outras informações
        self.shed = ShedState(game)  # Instancia o objeto ShedState com a referência ao jogo
        self.font = pygame.font.Font(None, 36)
        self.text = "Este é o estado sobre o Shed"

    def run(self):
        clock = pygame.time.Clock()
        background = pygame.image.load("images/farm.png")
        background = pygame.transform.scale(background, Settings.RESOLUTION)

        player = self.game["player"]
        player_group = pygame.sprite.Group()
        player_group.add(player)

        running = True
        while running:
            clock.tick(Settings.FPS)
            self.screen.blit(background, (0, 0))

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    exit()
                self.handle_event(event)  # Trate eventos de teclado e outros, se necessário

            player_group.update()
            draw_health_bar(self.screen, 70, 20, player.health, player.max_health)

            # Desenha o estado do Shed
            self.shed.draw(self.screen)

            # Exibe o texto informativo
            text_surface = self.font.render(self.text, True, (255, 255, 255))
            self.screen.blit(text_surface, (50, 50))

            pygame.display.update()

    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                print("Saindo do estado UpperState")
                # Retorna ao estado anterior ao empilhar o estado
                return "main"  # Modifique isso para o estado anterior que deseja retornar

