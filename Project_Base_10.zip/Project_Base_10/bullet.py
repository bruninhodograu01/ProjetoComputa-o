#bullet.py


import pygame
import math
from utils import Colors, Settings

class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y, direction, origin):
        super().__init__()
        self.direction = direction
        self.speed = 7
        self.damage = 5
        self.radius = 5  # Tamanho da bala
        self.color = Colors.WHITE
        self.rect = pygame.Rect(x - self.radius, y - self.radius, self.radius * 2, self.radius * 2)
        self.origin = origin  # A origem da bala (quem disparou)

    def update(self):
        # Move a bala de acordo com sua direção e velocidade
        self.rect.x += int(self.speed * math.cos(self.direction))
        self.rect.y += int(self.speed * math.sin(self.direction))

        # Remove a bala se sair da tela
        if (self.rect.x < 0 or self.rect.x > Settings.WIDTH or
            self.rect.y < 0 or self.rect.y > Settings.HEIGHT):
            self.kill()

    def draw(self, screen):
        # Desenha a bala na tela
        pygame.draw.circle(screen, self.color, self.rect.center, self.radius)



