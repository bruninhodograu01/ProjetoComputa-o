import pygame
import math
from bullet import Bullet
from utils import Settings  # Importe apenas o necessário

class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.original_image = pygame.image.load("images/player_with_gun.png").convert_alpha()
        self.image = self.original_image
        self.rect = self.image.get_rect()
        self.rect.center = (Settings.WIDTH // 2, Settings.HEIGHT // 2)

        # Atributos do jogador
        self.direction = 0  # Direção inicial
        self.bullet_cooldown = 0
        self.health = 100
        self.max_health = 100
        self.speed = 3
        self.level = 1
        self.exp = 0
        self.exp_to_next_level = 100
        self.regen_rate = 1
        self.regen_cooldown = 120  # Ticks (2 segundos a 60 FPS)
        self.regen_timer = 0

        # Sincronizar a direção inicial do jogador com o mouse
        self.update_direction()

    def gain_exp(self, amount):
        """Ganha EXP e sobe de nível se necessário."""
        self.exp += amount
        while self.exp >= self.exp_to_next_level:
            self.exp -= self.exp_to_next_level
            self.level_up()

    def level_up(self):
        """Aumenta o nível do jogador e ajusta os atributos."""
        self.level += 1
        self.exp_to_next_level = int(self.exp_to_next_level * 1.5)
        self.max_health += 10
        self.health = self.max_health
        print(f"Subiu de nível! Nível atual: {self.level}")

    def update(self):
        """Atualiza a posição e a saúde do jogador."""
        self.handle_movement()
        self.update_direction()
        self.handle_regeneration()

    def handle_movement(self):
        """Gerencia a movimentação do jogador com as teclas WASD."""
        keys = pygame.key.get_pressed()
        if keys[pygame.K_w] and self.rect.top > 0:
            self.rect.y -= self.speed
        if keys[pygame.K_s] and self.rect.bottom < Settings.HEIGHT:
            self.rect.y += self.speed
        if keys[pygame.K_a] and self.rect.left > 0:
            self.rect.x -= self.speed
        if keys[pygame.K_d] and self.rect.right < Settings.WIDTH:
            self.rect.x += self.speed

    def handle_regeneration(self):
        """Regenera a saúde do jogador se o cooldown permitir."""
        self.regen_timer += 1
        if self.regen_timer >= self.regen_cooldown and self.health < self.max_health:
            self.health += self.regen_rate
            self.health = min(self.health, self.max_health)
            self.regen_timer = 0

    def update_direction(self):
        """Atualiza a direção do jogador para olhar na direção do mouse."""
        mouse_x, mouse_y = pygame.mouse.get_pos()
        rel_x = mouse_x - self.rect.centerx
        rel_y = mouse_y - self.rect.centery
        angle = math.degrees(math.atan2(rel_y, rel_x))
        self.direction = angle
        self.image = pygame.transform.rotate(self.original_image, -self.direction)
        self.rect = self.image.get_rect(center=self.rect.center)

    def shoot(self, bullets):
        """Dispara uma bala se o cooldown permitir."""
        if self.bullet_cooldown <= 0:
            angle = math.radians(self.direction)
            bullet = Bullet(self.rect.centerx, self.rect.centery, angle, self)
            bullets.add(bullet)
            self.bullet_cooldown = Settings.FPS // 2  # Cooldown de meio segundo

        if self.bullet_cooldown > 0:
            self.bullet_cooldown -= 1


