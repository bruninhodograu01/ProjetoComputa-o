# upper_state.py

import pygame
from utils import Settings, draw_health_bar

middle_top = Settings.HEIGHT // 2 - 50
middle_bottom = Settings.HEIGHT // 2 + 50

class UpperState:
    def __init__(self, game):
        self.game = game
        self.next_state = None  # Próximo estado
        self.screen = pygame.display.get_surface()  # Superfície principal
        self.background = pygame.image.load("images/most_perfect_thing.jpeg")  # Define o fundo do estado
        self.background = pygame.transform.scale(self.background, Settings.RESOLUTION)

    def run(self):
        clock = pygame.time.Clock()
        player = self.game["player"]
        player_group = pygame.sprite.Group()
        player_group.add(player)

        # Ajustar posição inicial do jogador ao entrar neste estado
        if "player_entry_position" in self.game:
            entry_x, entry_y = self.game["player_entry_position"]
            player.rect.topleft = (entry_x, entry_y)

        running = True
        while running:
            clock.tick(Settings.FPS)
            self.screen.blit(self.background, (0, 0))

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    exit()

            player_group.update()
            draw_health_bar(self.screen, 70, 20, player.health, player.max_health)

            # Verificar transição para o ShedState (descer)
            if player.rect.bottom >= Settings.HEIGHT and middle_top <= player.rect.centerx <= middle_bottom:
                print("Jogador desceu para o estado 'shed'")
                self.game["player_entry_position"] = (player.rect.x, 0)  # Ajustar entrada
                self.next_state = "shed"
                return self.next_state

            # Verificar transição para outros estados (se necessário)
            # Adicione lógica para transição a partir do `UpperState` para outros estados

            player_group.draw(self.screen)
            pygame.display.flip()

