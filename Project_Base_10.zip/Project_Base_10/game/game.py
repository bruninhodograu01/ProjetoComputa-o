#game.py


import pygame
from utils import Settings
from player import Player
from game.game_states.mainstate import MainGameState
from game.game_states.shedstate import ShedState
from game.game_states.upperstate import UpperState


def game_loop():
    pygame.display.set_caption("Wilderness Explorer")
    clock = pygame.time.Clock()

    # Inicializa o jogo e os estados
    game = {"player": Player(), "player_entry_position": None}
    states = {
        "main": MainGameState,
        "shed": ShedState,
        "upper": UpperState,
    }

    current_state_name = "main"
    current_state = states[current_state_name](game)

    while current_state:
        next_state_name = current_state.run()  # Executa o estado atual

        if next_state_name:
            # Troca para o próximo estado, criando uma nova instância se necessário
            if next_state_name in states:
                current_state = states[next_state_name](game)
            else:
                print(f"Estado desconhecido: {next_state_name}")
                break
        else:
            break  # Sai do loop se não houver próximo estado

        clock.tick(Settings.FPS)

    pygame.quit()




