import random
import pygame
import math
from bullet import Bullet
from game import game
from utils import Settings

class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.game = game
        self.powerups = pygame.sprite.Group()
        self.original_image = pygame.image.load("images/player_with_gun.png").convert_alpha()
        self.image = self.original_image
        self.rect = self.image.get_rect()
        self.rect.center = (Settings.WIDTH // 2, Settings.HEIGHT // 2)

        # Atributos do jogador
        self.health_regen_multiplier = 1
        self.damage_multiplier = 1
        self.is_invincible = False
        self.color = (255, 255, 255)
        self.direction = 0
        self.health = 100
        self.max_health = 100
        self.speed = 3
        self.level = 1
        self.exp = 0
        self.exp_to_next_level = 100
        self.regen_rate = 1
        self.regen_cooldown = 120  # 2 segundos
        self.regen_timer = 0
        self.damage = 10
        self.weapon_cooldown = 0  # Cooldown da arma

        self.weapons = [
            {"name": "Pistola", "damage": 10, "speed": 7, "pattern": "single", "cooldown": 10},
            {"name": "Espingarda", "damage": 15, "speed": 5, "pattern": "spread", "spread": 20, "cooldown": 30},
            {"name": "Rifle", "damage": 20, "speed": 10, "pattern": "single", "cooldown": 5},
        ]
        self.current_weapon_index = 0
        self.cooldown = self.weapons[self.current_weapon_index]["cooldown"]

    def get_current_weapon(self):
        return self.weapons[self.current_weapon_index]

    def select_weapon(self, index):
        if 0 <= index < len(self.weapons):
            self.current_weapon_index = index
            self.cooldown = self.weapons[self.current_weapon_index]["cooldown"]
            print(f"Arma selecionada: {self.weapons[index]['name']}")

    def shoot(self, bullets):
        if self.weapon_cooldown <= 0:
            weapon = self.get_current_weapon()
            angle = math.radians(self.direction)

            if weapon["pattern"] == "single":
                bullet = Bullet(self.rect.centerx, self.rect.centery, angle, weapon["damage"], weapon["speed"], self)
                bullets.add(bullet)
            elif weapon["pattern"] == "spread":
                spread = weapon.get("spread", 20)
                for offset in [-spread, 0, spread]:
                    bullet_angle = angle + math.radians(offset)
                    bullet = Bullet(self.rect.centerx, self.rect.centery, bullet_angle, weapon["damage"],
                                    weapon["speed"], self)
                    bullets.add(bullet)

            self.weapon_cooldown = self.weapons[self.current_weapon_index]["cooldown"]
            print(f"Disparou com {weapon['name']}, cooldown de {self.cooldown}")

    def gain_exp(self, amount):
        self.exp += amount
        while self.exp >= self.exp_to_next_level:
            self.exp -= self.exp_to_next_level
            self.level_up()

    def level_up(self):
        self.level += 1
        self.exp_to_next_level = int(self.exp_to_next_level * 1.5)
        self.max_health += 10
        self.health = self.max_health
        print(f"Subiu de nível! Nível atual: {self.level}")

    def update(self):
        # Atualiza o estado do jogador
        self.damage = 10 * self.damage_multiplier
        self.color = (255, 255, 0) if self.is_invincible else (255, 255, 255)

        self.handle_movement()
        self.update_direction()
        self.handle_regeneration()

        self.check_player_powerup_collision()
    def handle_movement(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_w] and self.rect.top > 0:
            self.rect.y -= self.speed
        if keys[pygame.K_s] and self.rect.bottom < Settings.HEIGHT:
            self.rect.y += self.speed
        if keys[pygame.K_a] and self.rect.left > 0:
            self.rect.x -= self.speed
        if keys[pygame.K_d] and self.rect.right < Settings.WIDTH:
            self.rect.x += self.speed

    def handle_regeneration(self):
        self.regen_timer += 1
        if self.regen_timer >= self.regen_cooldown and self.health < self.max_health:
            self.health += self.regen_rate
            self.health = min(self.health, self.max_health)
            self.regen_timer = 0

    def update_direction(self):
        mouse_x, mouse_y = pygame.mouse.get_pos()
        rel_x = mouse_x - self.rect.centerx
        rel_y = mouse_y - self.rect.centery
        angle = math.degrees(math.atan2(rel_y, rel_x))
        self.direction = angle
        self.image = pygame.transform.rotate(self.original_image, -self.direction)
        self.rect = self.image.get_rect(center=self.rect.center)

    def check_player_powerup_collision(self):
        for powerup in self.powerups:
            if self.rect.colliderect(powerup.rect):  # Usar powerup.rect diretamente
                powerup.affect_player(self)  # Aplica o efeito no jogador
                powerup.is_active = True  # Marca o power-up como ativo (se necessário)
                powerup.affect_game(self.game)  # Aplica o efeito no jogo (se necessário)
                powerup.kill()  # Remove o power-up do jogo
                print("Power-up apanhado!")  # Para depuração








