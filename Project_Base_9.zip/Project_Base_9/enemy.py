# enemy.py
import pygame
import random
import math
from bullet import Bullet  # Importa a classe Bullet
from utils import Settings

class Enemy(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        # Carregar a imagem original do inimigo
        self.original_image = pygame.image.load("images/zombie(1).png").convert_alpha()
        self.image = self.original_image
        self.rect = self.image.get_rect()

        # Inicializar posição aleatória
        self.rect.x = random.randint(0, Settings.WIDTH - self.rect.width)
        self.rect.y = random.randint(0, Settings.HEIGHT - self.rect.height)

        # Atributos do inimigo
        self.speed = 1
        self.health = 10
        self.damage = 0.5  # Dano causado ao jogador
        self.exp_reward = 20  # EXP que o jogador ganha ao derrotar este inimigo

        # Atributo para controlar o cooldown de dano
        self.damage_cooldown = 100  # 1 segundo a 60 FPS
        self.damage_timer = 0

        # Atributo para controle de cooldown de disparo
        self.shoot_cooldown = 200  # Exemplo: 3 segundos a 60 FPS
        self.shoot_timer = 0

    def shoot_bullet(self, player, bullet_group):
        # Cria uma bala na posição do inimigo e direciona para o jogador
        bullet = Bullet(self.rect.x, self.rect.y, math.atan2(player.rect.y - self.rect.y, player.rect.x - self.rect.x), self)
        bullet_group.add(bullet)

    def update(self, player, bullet_group, enemies):
        # Cálculo de direção em relação ao jogador
        dx = player.rect.x - self.rect.x
        dy = player.rect.y - self.rect.y
        direction = math.atan2(dy, dx)

        # Movimento do inimigo
        self.rect.x += self.speed * math.cos(direction)
        self.rect.y += self.speed * math.sin(direction)

        # Verifica se o cooldown de dano expirou e se há colisão com o jogador
        if self.damage_timer == 0 and self.rect.colliderect(player.rect):
            self.apply_damage(player)

        # Decrementa o timer de cooldown, se maior que 0
        if self.damage_timer > 0:
            self.damage_timer -= 1

        # Verifica se é hora de disparar uma bala
        if self.shoot_timer == 0:
            self.shoot_bullet(player, bullet_group)
            self.shoot_timer = self.shoot_cooldown
        else:
            self.shoot_timer -= 1

        # Evita que inimigos colidam e fiquem sobrepostos, mas sem causar dano entre si
        for enemy in enemies:
            if enemy != self and self.rect.colliderect(enemy.rect):
                # Ajusta a posição para evitar sobreposição
                overlap_dx = self.rect.centerx - enemy.rect.centerx
                overlap_dy = self.rect.centery - enemy.rect.centery
                distance = max(1, math.sqrt(overlap_dx**2 + overlap_dy**2))
                self.rect.x += overlap_dx / distance
                self.rect.y += overlap_dy / distance

        # Verifica colisões com balas, ignorando balas disparadas por este inimigo
        for bullet in bullet_group:
            if bullet.rect.colliderect(self.rect) and bullet.origin != self:
                # Só aplica dano se a bala não for do mesmo tipo (não atinge o mesmo inimigo)
                if isinstance(bullet.origin, Enemy):
                    continue  # Ignora balas disparadas por outros inimigos
                self.health -= bullet.damage
                bullet.kill()  # Remove a bala após a colisão
                print(f"Inimigo atingido! Saúde restante: {self.health}")


        if self.health <= 0:
            player.gain_exp(self.exp_reward)  # Concede EXP ao jogador
            self.kill()  # Remove o inimigo do jogo
            print("Inimigo derrotado!")

    def apply_damage(self, player):
        """
        Aplica dano ao jogador e reinicia o cooldown de dano.
        """
        player.health -= 10  # Quantidade de dano causada ao jogador
        player.health = max(player.health, 0)  # Evita valores negativos
        self.damage_timer = self.damage_cooldown  # Reinicia o cooldown de dano

        # Adicione um efeito sonoro ou visual, se necessário
        print("Jogador levou dano!")  # Exemplo de feedback de debug

    def update_image(self, dx):
        """
        Atualiza a imagem para refletir a direção do movimento.
        """
        if dx > 0:  # Movimento para a direita
            self.image = pygame.transform.flip(self.original_image, True, False)
        else:  # Movimento para a esquerda
            self.image = self.original_image






'''
import pygame
import math
import random
from utils import Settings



class Enemy(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        # Carregar a imagem original do inimigo (exemplo de zumbi)
        self.original_image = pygame.image.load("images/zombie(1).png").convert_alpha()
        self.image = self.original_image
        self.rect = self.image.get_rect()
        self.enemies = pygame.sprite.Group()

        # Inicializar a posição do inimigo aleatoriamente
        self.rect.x = random.randint(0, Settings.WIDTH - self.rect.width)
        self.rect.y = random.randint(0, Settings.HEIGHT - self.rect.height)

        # Configurar a velocidade e saúde do inimigo
        self.speed = 1
        self.health = 10

    def update(self, player):
        """
        Atualiza a posição do inimigo para se mover em direção ao jogador.
        """
        # Cálculo da diferença entre as posições do jogador e do inimigo
        dx = player.rect.x - self.rect.x
        dy = player.rect.y - self.rect.y

        # Calcula a direção (em radianos) para o movimento
        direction = math.atan2(dy, dx)

        # Atualiza a posição do inimigo
        self.rect.x += self.speed * math.cos(direction)
        self.rect.y += self.speed * math.sin(direction)

        # Atualiza a imagem com base na direção do movimento (esquerda/direita)
        self.update_image(dx)

        # Atualiza o retângulo da imagem para manter a posição correta
        self.rect = self.image.get_rect(center=self.rect.center)

    def update_image(self, dx):
        """
        Atualiza a imagem do inimigo para refletir a direção do movimento.
        """
        if dx > 0:  # Movimento para a direita
            self.image = pygame.transform.flip(self.original_image, True, False)
        else:  # Movimento para a esquerda
            self.image = self.original_image
            '''


