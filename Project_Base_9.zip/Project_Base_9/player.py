#player.py

import math
from bullet import Bullet
from utils import *  # Para acessar variáveis globais (ex.: largura, altura)



class Player(pygame.sprite.Sprite):

    def __init__(self):
        super().__init__()
        self.original_image = pygame.image.load("images/player_with_gun.png").convert_alpha()
        self.image = self.original_image
        self.rect = self.image.get_rect()
        self.rect.center = (Settings.WIDTH // 2, Settings.HEIGHT // 2)  # Posiciona o jogador no centro da tela

        # Atributos de direção e cooldown de tiro
        self.direction = 0  # Direção inicial
        self.bullet_cooldown = 0  # Contador para limitar tiros

        #atributos do player
        self.health = 100
        self.max_health = 100  # Vida máxima para referência
        self.speed = 3
        self.level = 1
        self.exp = 0
        self.exp_to_next_level = 100  # EXP necessária para o próximo nível

        #atributos de regeneração
        self.regen_rate = 1  # Quantidade de saúde regenerada por "tick"
        self.regen_cooldown = 120  # Ticks para regenerar (2 segundos a 60 FPS)
        self.regen_timer = 0  # Contador para controlar o cooldown de regeneração

        # Sincronizar direção inicial com o rato
        self.sync_with_mouse()

    def gain_exp(self, amount):
        """Ganha EXP e sobe de nível se necessário."""
        self.exp += amount
        while self.exp >= self.exp_to_next_level:
            self.exp -= self.exp_to_next_level
            self.level_up()

    def level_up(self):
        """Aumenta o nível do jogador e ajusta os atributos."""
        self.level += 1
        self.exp_to_next_level = int(self.exp_to_next_level * 1.5)  # Exemplo de progressão de EXP
        self.max_health += 10  # Exemplo de aumento de atributo
        self.health = self.max_health  # Restaura a saúde ao subir de nível
        print(f"Subiu de nível! Nível atual: {self.level}")

    def sync_with_mouse(self):
        """
        Sincroniza a direção inicial do jogador com a posição do mouse.
        """
        mouse_x, mouse_y = pygame.mouse.get_pos()  # Obtém a posição do rato
        rel_x = mouse_x - self.rect.centerx
        rel_y = mouse_y - self.rect.centery

        # Calcula o ângulo inicial corretamente
        angle = math.degrees(math.atan2(rel_y, rel_x))  # Usa rel_y e rel_x diretamente
        self.direction = angle  # Define a direção inicial

        # Rotaciona a imagem para alinhar com a direção inicial
        self.image = pygame.transform.rotate(self.original_image, -self.direction)
        self.rect = self.image.get_rect(center=self.rect.center)

    def update(self):
        keys = pygame.key.get_pressed()

        # Movimentação com as teclas WASD
        if keys[pygame.K_w] and self.rect.top > 0:  # Para cima
            self.rect.y -= self.speed
        if keys[pygame.K_s] and self.rect.bottom < Settings.HEIGHT:  # Para baixo
            self.rect.y += self.speed
        if keys[pygame.K_a] and self.rect.left > 0:  # Para a esquerda
            self.rect.x -= self.speed
        if keys[pygame.K_d] and self.rect.right < Settings.WIDTH:  # Para a direita
            self.rect.x += self.speed

        # Atualizar a direção para olhar na direção do mouse
        self.update_direction()

        self.regen_timer += 1
        if self.regen_timer >= self.regen_cooldown and self.health < self.max_health:
            self.health += self.regen_rate
            self.health = min(self.health, self.max_health)  # Limitar à saúde máxima
            self.regen_timer = 0  # Reinicia o contador
        """
        if self.health <= 0:
            print("O jogador foi derrotado!")
            pygame.quit()
            exit()
        """
    def update_direction(self):
        """
        Atualiza a direção do jogador para olhar na direção do mouse.
        """
        mouse_x, mouse_y = pygame.mouse.get_pos()  # Pega a posição do mouse
        rel_x = mouse_x - self.rect.centerx
        rel_y = mouse_y - self.rect.centery

        # Calcula o ângulo com base no mouse corretamente
        angle = math.degrees(math.atan2(rel_y, rel_x))  # Usa rel_y e rel_x diretamente
        self.direction = angle  # Define a direção do jogador

        # Rotaciona a imagem do jogador
        self.image = pygame.transform.rotate(self.original_image, -self.direction)
        self.rect = self.image.get_rect(center=self.rect.center)

    def shoot(self, bullets):
        if self.bullet_cooldown <= 0:
            # Criar uma bala na posição atual do jogador e na direção que ele está olhando
            angle = math.radians(self.direction)
            bullet = Bullet(self.rect.centerx, self.rect.centery, angle)
            bullets.add(bullet)
            self.bullet_cooldown = Settings.FPS // 2  # Define um cooldown de meio segundo

        # Reduz o cooldown a cada frame
        if self.bullet_cooldown > 0:
            self.bullet_cooldown -= 1


