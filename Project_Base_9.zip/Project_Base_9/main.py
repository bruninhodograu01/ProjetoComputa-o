import pygame

from bullet import Bullet
from enemy import Enemy

from menu import Menu


def main():
    """
    Função principal que inicializa o jogo, define a tela e chama o menu principal.
    """
    # Inicializa todos os módulos do Pygame
    pygame.init()

    # Define a resolução da tela e cria a janela
    screen = pygame.display.set_mode((720, 720))
    pygame.display.set_caption("Menu Principal do Jogo")

    # Cria a instância do menu e exibe-o
    menu = Menu(screen)
    menu.run()

    # Encerra o Pygame corretamente
    pygame.quit()
if __name__ == "__main__":
    main()


