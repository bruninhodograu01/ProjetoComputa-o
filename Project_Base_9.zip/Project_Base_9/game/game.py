#game.py


import pygame
from utils import Settings , check_bullet_collisions
from player import Player
from game.game_states.mainstate import MainGameState
from game.game_states.shedstate import ShedState
from game.game_states.uppersate import UpperState



def game_loop():
    pygame.display.set_caption("Wilderness Explorer")
    clock = pygame.time.Clock()

    # Inicializa o jogo e os estados
    game = {"player": Player(), "player_entry_position": None}
    states = {
        "main": MainGameState,
        "shed": ShedState,
        "upper": UpperState,  # Registra o novo estado
    }

    # Estado inicial
    current_state_name = "main"
    current_state = states[current_state_name](game)

    while current_state:
        next_state_name = current_state.run()  # Executa o estado atual

        if next_state_name:
            # Troca para o próximo estado
            current_state = states.get(next_state_name, None)
            if current_state:
                current_state = current_state(game)
            else:
                print(f"Estado desconhecido: {next_state_name}")
                break
        else:
            break  # Sai do loop se não houver próximo estado

        clock.tick(Settings.FPS)

    pygame.quit()


'''
def game_loop():
    game = {"player": Player(), "current_state": "main"}
    states = {
        "main": MainGameState(game),
        "shed": ShedState(game),
    }


    pygame.display.set_caption("Wilderness Explorer")
    clock = pygame.time.Clock()

    running = True


    while running:
        # Convertendo 'game' para um dicionário normal para acesso seguro
        game_dict = dict(game)

        state = states.get(game_dict.get("current_state"))
        if state:
            next_state = state.run()
            if next_state:
                game_dict["current_state"] = next_state
                # Atualizando o TypedDict original, se necessário
                game.update(game_dict)
        else:
            print("Estado desconhecido!")
            pygame.quit()
            exit()

        clock.tick(Settings.FPS)
'''
