#shed_state

import pygame
from utils import Settings, draw_health_bar
from underC import Underc

# Inicialize a tela e a instância de Utils fora das classes
pygame.display.set_caption("Game State")


middle_top = Settings.HEIGHT // 2 - 50  # Parte superior da faixa (ajuste 50 para ajustar a largura da faixa)
middle_bottom = Settings.HEIGHT // 2 + 50  # Parte inferior da faixa

class ShedState:
    def __init__(self, game):
        self.game = game
        self.underC = Underc(pygame.display.get_surface())  # Referência à instância de Utils
        self.next_state = None  # Define o atributo aqui

    def run(self):
        screen = pygame.display.get_surface()
        clock = pygame.time.Clock()
        background = pygame.image.load("images/farm.png")
        background = pygame.transform.scale(background, Settings.RESOLUTION)

        player = self.game["player"]
        player_group = pygame.sprite.Group()
        player_group.add(player)

        special_area = pygame.Rect(530, 30, 140, 140)

        if "player_entry_position" in self.game:
            entry_x, entry_y = self.game["player_entry_position"]
            player.rect.topleft = (entry_x, entry_y)

        running = True
        while running:
            clock.tick(Settings.FPS)
            screen.blit(background, (0, 0))

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    exit()

            player_group.update()
            draw_health_bar(screen, 70, 20, player.health, player.max_health)
            # Verifique se o jogador entrou na área especial (a casa)
            if special_area.colliderect(player.rect):
                print("Jogador entrou na área especial (a casa).")
                # Chama a função only quando necessário
                self.underC.under_construction()

            if player.rect.left <= 0 and middle_top <= player.rect.centery <= middle_bottom:
                print("Jogador saiu para o estado 'main'")
                player.rect.left = Settings.WIDTH - player.rect.width
                self.next_state = "main"
                return self.next_state

            if player.rect.top <= 0 and middle_top <= player.rect.centerx <= middle_bottom:
                print("Jogador subiu para o estado 'upper'")
                self.game["player_entry_position"] = (player.rect.x, Settings.HEIGHT - player.rect.height)
                self.next_state = "upper"
                return self.next_state




            player_group.draw(screen)
            pygame.display.flip()
