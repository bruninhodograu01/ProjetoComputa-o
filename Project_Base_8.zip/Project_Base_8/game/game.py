#game.py


import pygame
from utils import Settings , check_bullet_collisions
from player import Player
from game.game_states.mainstate import MainGameState
from game.game_states.shedstate import ShedState



def game_loop():
    pygame.display.set_caption("Wilderness Explorer")
    clock = pygame.time.Clock()

    game = {"player": Player(), "current_state": "main"}

    states = {
        "main": MainGameState(game),
        "shed": ShedState(game),
    }

    # Inicialização dos grupos de sprites
    enemy_group = pygame.sprite.Group()
    bullet_group = pygame.sprite.Group()

    running = True
    while running:
        state = states.get(game["current_state"])
        if state:
            next_state = state.run()
            if next_state:
                game["current_state"] = next_state
        else:
            print(f"Estado desconhecido: {game['current_state']}")
            running = False

            # Atualiza os inimigos e verifica se eles devem disparar
            for enemy in enemy_group:
                enemy.update(game["player"], bullet_group)

            # Atualiza as balas
            bullet_group.update()

            # Desenha os elementos na tela
            screen = pygame.display.get_surface()
            screen.fill((0, 0, 0))  # Cor de fundo

            # Desenha os inimigos e as balas
            enemy_group.draw(screen)
            bullet_group.draw(screen)

            # Desenha o jogador
            screen.blit(game["player"].image, game["player"].rect)

        clock.tick(Settings.FPS)
    pygame.quit()


'''
def game_loop():
    game = {"player": Player(), "current_state": "main"}
    states = {
        "main": MainGameState(game),
        "shed": ShedState(game),
    }


    pygame.display.set_caption("Wilderness Explorer")
    clock = pygame.time.Clock()

    running = True


    while running:
        # Convertendo 'game' para um dicionário normal para acesso seguro
        game_dict = dict(game)

        state = states.get(game_dict.get("current_state"))
        if state:
            next_state = state.run()
            if next_state:
                game_dict["current_state"] = next_state
                # Atualizando o TypedDict original, se necessário
                game.update(game_dict)
        else:
            print("Estado desconhecido!")
            pygame.quit()
            exit()

        clock.tick(Settings.FPS)
'''
