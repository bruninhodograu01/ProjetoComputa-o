#main_ state

import pygame
import math
from utils import Settings, draw_health_bar , check_bullet_collisions
from bullet import Bullet
from enemy import Enemy
from underC import Underc

# Inicialização da tela e da instância de Utils
screen = pygame.display.set_mode((720, 720))
pygame.display.set_caption("Game State")
utils = Underc(screen)

# Constantes para definir as margens de controle do jogador
middle_top = Settings.HEIGHT // 2 - 50
middle_bottom = Settings.HEIGHT // 2 + 50

class MainGameState:
    def __init__(self, game, spawn_rate=0.5, enemy_limit=10):
        self.game = game
        self.next_state = None
        self.bullets = pygame.sprite.Group()
        self.enemies = pygame.sprite.Group()
        self.screen = screen  # Referência ao objeto de tela global
        self.utils = utils  # Referência à instância de Utils

        self.spawn_rate = spawn_rate if spawn_rate is not None else Settings.ENEMY_SPAWN_RATE
        self.enemy_limit = enemy_limit if enemy_limit is not None else Settings.ENEMY_LIMIT
        self.enemy_cooldown = Settings.FPS * self.spawn_rate
        self.enemy_counter = 0

    def spawn_enemy(self, enemies):
        """Cria e adiciona um novo inimigo à lista de inimigos."""
        if self.enemy_counter < self.enemy_limit:
            enemy = Enemy()
            enemies.add(enemy)
            self.enemy_counter += 1
            print(f"Novo inimigo gerado {self.enemy_counter}!")

    def handle_collisions(self):
        """Verifica colisões entre balas e inimigos e aplica dano se houver colisão."""
        for bullet in self.bullets:
            collided_enemies = pygame.sprite.spritecollide(bullet, self.enemies, False)

            if collided_enemies:
                print(f"Bala colidiu com {len(collided_enemies)} inimigos")
                for enemy in collided_enemies:
                    print(f"Bala atingiu inimigo com saúde {enemy.health}")
                    enemy.health -= bullet.damage  # Aplica o dano da bala
                    bullet.kill()  # Remove a bala após a colisão

                    if enemy.health <= 0:
                        enemy.kill()  # Remove o inimigo se a saúde for 0 ou menos
                        print("Inimigo derrotado!")

    def run(self):
        clock = pygame.time.Clock()
        background = pygame.image.load("images/most_perfect_thing.jpeg")
        background = pygame.transform.scale(background, Settings.RESOLUTION)

        player = self.game["player"]
        player_group = pygame.sprite.Group()
        player_group.add(player)

        enemies = pygame.sprite.Group()
        enemy_cooldown = self.enemy_cooldown

        running = True
        while running:
            clock.tick(Settings.FPS)
            self.screen.blit(background, (0, 0))

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    exit()
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    angle = math.radians(player.direction)
                    # Passa o jogador como origem da bala
                    bullet = Bullet(player.rect.centerx, player.rect.centery, angle, player)
                    self.bullets.add(bullet)

            player_group.update()
            self.bullets.update()

            # Verifica colisões entre balas e inimigos
            self.handle_collisions()

            for enemy in enemies:
                enemy.update(player, self.bullets, enemies)

            if enemy_cooldown <= 0:
                self.spawn_enemy(enemies)
                enemy_cooldown = Settings.FPS * self.spawn_rate
            enemy_cooldown -= 1

            draw_health_bar(self.screen, 70, 20, player.health, player.max_health)

            if player.rect.right >= Settings.WIDTH and middle_top <= player.rect.centery <= middle_bottom:
                print("Jogador saiu para o estado 'shed'")
                self.game["player_entry_position"] = (0, player.rect.y)
                self.next_state = "shed"
                return self.next_state

            player_group.draw(self.screen)
            enemies.draw(self.screen)
            for bullet in self.bullets:
                bullet.draw(self.screen)

            pygame.display.flip()




"""
    def handle_collisions(self):
      Verifica colisões entre balas e inimigos.
        for bullet in self.bullets:
            collided_enemies = pygame.sprite.spritecollide(bullet, self.enemies, False)
            for enemy in collided_enemies:
                enemy.health -= bullet.damage
                bullet.kill()
                if enemy.health <= 0:
                    enemy.kill()
"""

"""
class MainGameState:
    def __init__(self, game, spawn_rate=0.5, enemy_limit=None):
        self.game = game
        self.next_state = None
        self.bullets = pygame.sprite.Group()
        self.screen = screen
        self.utils = utils  # Referência à instância de Utils

        # Use a taxa de spawn personalizada se fornecida, senão use a taxa padrão de Settings
        self.spawn_rate = spawn_rate if spawn_rate is not None else Settings.ENEMY_SPAWN_RATE
        self.enemy_limit = enemy_limit if enemy_limit is not None else Settings.ENEMY_LIMIT  # Limite de inimigos
        self.enemy_cooldown = Settings.FPS * self.spawn_rate
        self.enemy_counter = 0  # Contador de inimigos gerados

    def run(self):
        screen = pygame.display.get_surface()
        clock = pygame.time.Clock()
        background = pygame.image.load("images/most_perfect_thing.jpeg")
        background = pygame.transform.scale(background, Settings.RESOLUTION)

        player = self.game["player"]
        player_group = pygame.sprite.Group()
        player_group.add(player)

        enemies = pygame.sprite.Group()
        enemy_cooldown = self.enemy_cooldown  # Usando a variável de taxa de spawn personalizada

        running = True
        while running:
            clock.tick(Settings.FPS)
            screen.blit(background, (0, 0))

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    exit()
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    angle = math.radians(player.direction)
                    bullet = Bullet(player.rect.centerx, player.rect.centery, angle)
                    self.bullets.add(bullet)

            player_group.update()
            self.bullets.update()
            for enemy in enemies:
                enemy.update(player, self.bullets)

            if enemy_cooldown <= 0 and self.enemy_counter < self.enemy_limit:
                enemy = Enemy()
                enemies.add(enemy)
                self.enemy_counter += 1  # Incrementa o contador de inimigos
                print(f"Novo inimigo gerado {self.enemy_counter}!")
                enemy_cooldown = Settings.FPS * self.spawn_rate
            enemy_cooldown -= 1

            draw_health_bar(screen, 70, 20, player.health, player.max_health)

            if player.rect.right >= Settings.WIDTH and middle_top <= player.rect.centery <= middle_bottom:
                print("Jogador saiu para o estado 'shed'")
                self.game["player_entry_position"] = (0, player.rect.y)
                self.next_state = "shed"
                return self.next_state

            player_group.draw(screen)
            enemies.draw(screen)
            for bullet in self.bullets:
                bullet.draw(screen)

            for bullet in self.bullets:
                collided_enemies = pygame.sprite.spritecollide(bullet, enemies, False)
                for enemy in collided_enemies:
                    enemy.health -= bullet.damage
                    bullet.kill()
                    if enemy.health <= 0:
                        enemy.kill()

            pygame.display.flip()

"""
"""
class MainGameState:
    def __init__(self, game):
        self.game = game
        self.next_state = None
        self.bullets = pygame.sprite.Group()
        self.screen = screen
        self.utils = utils  # Referência à instância de Utils


    def run(self):
        screen = pygame.display.get_surface()
        clock = pygame.time.Clock()
        background = pygame.image.load("images/most_perfect_thing.jpeg")
        background = pygame.transform.scale(background, Settings.RESOLUTION)

        player = self.game["player"]
        player_group = pygame.sprite.Group()
        player_group.add(player)


        enemies = pygame.sprite.Group()
        enemy_cooldown = 0

        running = True
        while running:
            clock.tick(Settings.FPS)
            screen.blit(background, (0, 0))

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    exit()
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    angle = math.radians(player.direction)
                    bullet = Bullet(player.rect.centerx, player.rect.centery, angle)
                    self.bullets.add(bullet)  # Adiciona uma instância de Bullet ao grupo

            player_group.update()
            # Atualiza o grupo de balas
            self.bullets.update()
            for enemy in enemies:
                enemy.update(player, self.bullets)

            if enemy_cooldown <= 0:
                enemy = Enemy()
                enemies.add(enemy)  # Adiciona uma instância de Enemy ao grupo
                enemy_cooldown = Settings.FPS * 2
            enemy_cooldown -= 1

            draw_health_bar(screen, 70, 20, player.health, player.max_health)

            if player.rect.right >= Settings.WIDTH and middle_top <= player.rect.centery <= middle_bottom:
                print("Jogador saiu para o estado 'shed'")
                self.game["player_entry_position"] = (0, player.rect.y)
                self.next_state = "shed"

                return self.next_state
            # Desenha o jogador, inimigos e balas na tela
            player_group.draw(screen)
            enemies.draw(screen)
            self.bullets.update()
            for bullet in self.bullets:
                bullet.draw(screen)

            for bullet in self.bullets:
                collided_enemies = pygame.sprite.spritecollide(bullet, enemies, False)
                for enemy in collided_enemies:
                    enemy.health -= bullet.damage
                    bullet.kill()
                    if enemy.health <= 0:
                        enemy.kill()
            pygame.display.flip()
"""

"""
 running = True
 while running:
     clock.tick(Settings.FPS)
     screen.blit(background, (0, 0))

     for event in pygame.event.get():
         if event.type == pygame.QUIT:
             pygame.quit()
             exit()
         if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
             angle = math.radians(player.direction)
             bullet = Bullet(player.rect.centerx, player.rect.centery, angle)
             self.bullets.add(bullet)

     player_group.update()
     for enemy in enemies:
         enemy.update(player, self.bullets)

     if enemy_cooldown <= 0:
         enemy = Enemy()
         enemies.add(enemy)
         enemy_cooldown = Settings.FPS * 2
     enemy_cooldown -= 1

     self.bullets.update()
     for bullet in self.bullets:
         bullet.draw(screen)

     for bullet in self.bullets:
         collided_enemies = pygame.sprite.spritecollide(bullet, enemies, False)
         for enemy in collided_enemies:
             enemy.health -= bullet.damage
             bullet.kill()
             if enemy.health <= 0:
                 enemy.kill()
     """