# upper_state.py

from game.game_states.mainstate import MainGameState
from utils import Settings, draw_health_bar, draw_exp_bar, draw_money
from powerups import *
from enemy import Zombie
# Inicialização da tela e da instância de Utils
screen = pygame.display.set_mode(Settings.RESOLUTION)
pygame.display.set_caption("Game State")

class Level4(MainGameState):
    def __init__(self, game):
        super().__init__(game, spawn_rate=0.4, enemy_limit=5)