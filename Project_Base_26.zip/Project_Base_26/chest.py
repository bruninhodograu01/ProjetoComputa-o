import pygame
import random
from powerups import *
from utils import Settings


class Chest(pygame.sprite.Sprite):
    def __init__(self, x, y, player, available_options):
        super().__init__()

        self.x = x
        self.y = y
        self.image = pygame.image.load("images/bau(1).png")
        self.image = pygame.transform.scale(self.image, (50, 50))
        self.rect = self.image.get_rect(topleft=(self.x, self.y))
        self.player = player
        self.opened = False
        self.options = []
        self.used_options = set()  # Opcões já usadas nesta interação
        self.available_options = available_options  # Opções ainda disponíveis no jogo

        self.update_options()  # Atualiza as opções do baú

        self.option_rects = [
            pygame.Rect(Settings.WIDTH // 2 - 100, Settings.HEIGHT // 2 - 60, 200, 40),
            pygame.Rect(Settings.WIDTH // 2 - 100, Settings.HEIGHT // 2, 200, 40),
            pygame.Rect(Settings.WIDTH // 2 - 100, Settings.HEIGHT // 2 + 60, 200, 40),
        ]

    def update_options(self):
        """Atualiza as opções disponíveis, retirando as já usadas."""
        available_options = [opt for opt in self.available_options if opt not in self.used_options]

        if not available_options:
            # Se não houver mais opções, não altere a imagem nem selecione opções
            return

        # Seleciona até 3 opções aleatórias das disponíveis
        self.options = random.sample(available_options, k=min(3, len(available_options)))

    def open(self):
        """Abre o baú e gera as opções de power-ups."""
        if not self.opened:
            self.opened = True
            self.update_options()

    def display_options(self, screen):
        """Renderiza as opções de escolha."""
        if self.opened:
            font = pygame.font.Font(None, 36)
            for i, option in enumerate(self.options):
                text = font.render(option, True, (255, 255, 255))
                pygame.draw.rect(screen, (0, 0, 0), self.option_rects[i])  # Fundo do bloco
                pygame.draw.rect(screen, (255, 255, 255), self.option_rects[i], 2)  # Borda
                screen.blit(text, (self.option_rects[i].x + 10, self.option_rects[i].y + 5))

    def check_click(self, pos):
        """Verifica se o jogador clicou numa das opções do baú."""
        if self.opened:
            for i, rect in enumerate(self.option_rects):
                if rect.collidepoint(pos):
                    return self.options[i]
        return None

    def improve_powerup(self, powerup_type, game_state):
        """Melhora o Power-up escolhido e atualiza a lista de usados no MainGameState."""
        # Melhorando o power-up com base no tipo
        if powerup_type == 'DamageBoostPU':
            powerup = DamageBoostPU(self.x, self.y)
            powerup.improve(self.player)
        elif powerup_type == 'HealthRegenPU':
            powerup = HealthRegenPU(self.x, self.y)
            powerup.improve(self.player)
            print(f"[DEBUG] HealthRegenPU após melhoria: quantificator = {powerup.quantificator}")  # Verificar o aumento
        elif powerup_type == 'RegenBoostPU':
            powerup = RegenBoostPU(self.x, self.y)
            powerup.improve(self.player)
        elif powerup_type == 'InvincibilityPU':
            powerup = InvincibilityPU(self.x, self.y)
            powerup.improve(self.player)
        elif powerup_type == 'DespawnerPU':
            powerup = DespawnerPU(self.x, self.y)
            powerup.improve(self.player)

        # Marcar o power-up como usado no MainGameState
        game_state.mark_powerup_as_used(powerup_type)

        # Atualiza as opções no baú
        self.used_options.add(powerup_type)
        self.update_options()