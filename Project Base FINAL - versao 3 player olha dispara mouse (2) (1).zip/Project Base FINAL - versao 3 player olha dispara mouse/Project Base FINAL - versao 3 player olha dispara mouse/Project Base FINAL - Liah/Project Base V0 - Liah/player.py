import pygame
import math
from bullet import Bullet
from config import *

class Player(pygame.sprite.Sprite):

    def __init__(self):
        super().__init__()
        self.original_image = pygame.image.load("images/player_with_gun (1).png").convert_alpha()
        self.image = self.original_image
        self.rect = self.image.get_rect()
        self.rect.center = (width // 2, height // 2)

        self.direction = 0
        self.speed = 3
        self.health = 100
        self.bullet_cooldown = 0

        # Sincronizar direção inicial com o rato
        self.sync_with_mouse()

    def sync_with_mouse(self):
        """
        Sincroniza a direção inicial do jogador com a posição do mouse.
        """
        mouse_x, mouse_y = pygame.mouse.get_pos()
        rel_x = mouse_x - self.rect.centerx
        rel_y = mouse_y - self.rect.centery

        angle = math.degrees(math.atan2(rel_y, rel_x))
        self.direction = angle

        self.image = pygame.transform.rotate(self.original_image, -self.direction)
        self.rect = self.image.get_rect(center=self.rect.center)

    def update(self):
        keys = pygame.key.get_pressed()

        # Movimentação
        if keys[pygame.K_w] and self.rect.top > 0:
            self.rect.y -= self.speed
        if keys[pygame.K_s] and self.rect.bottom < height:
            self.rect.y += self.speed
        if keys[pygame.K_a] and self.rect.left > 0:
            self.rect.x -= self.speed
        if keys[pygame.K_d] and self.rect.right < width:
            self.rect.x += self.speed

        self.update_direction()

    def update_direction(self):
        """
        Atualiza a direção do jogador para olhar na direção do mouse.
        """
        mouse_x, mouse_y = pygame.mouse.get_pos()
        rel_x = mouse_x - self.rect.centerx
        rel_y = mouse_y - self.rect.centery

        angle = math.degrees(math.atan2(rel_y, rel_x))
        self.direction = angle

        self.image = pygame.transform.rotate(self.original_image, -self.direction)
        self.rect = self.image.get_rect(center=self.rect.center)

    def shoot(self, bullets):
        """
        Método para o jogador atirar na direção atual.
        """
        if self.bullet_cooldown <= 0:
            angle = math.radians(self.direction)
            bullet = Bullet(self.rect.centerx, self.rect.centery, angle)
            bullets.add(bullet)
            self.bullet_cooldown = fps // 2

        if self.bullet_cooldown > 0:
            self.bullet_cooldown -= 1

