from interface import *

def main():
    interface()

if __name__ == '__main__':
    main()