from config import *
import pygame
import random
import math

class Enemy(pygame.sprite.Sprite):

    def __init__(self):
        super().__init__()

        # Carregar a imagem original do zumbi (olhando para a esquerda)
        self.original_image = pygame.image.load("images/zombie(1).png").convert_alpha()

        # Inicialmente, o zumbi está olhando para a esquerda
        self.image = self.original_image
        self.rect = self.image.get_rect()

        # Definindo uma posição aleatória para o inimigo na tela
        self.rect.x = random.randint(0, width - self.rect.width)
        self.rect.y = random.randint(0, height - self.rect.height)

        # Definindo a velocidade do inimigo
        self.speed = 1

        # Definindo a vida do inimigo
        self.health = 10

    def update(self, player):
        """
        Atualiza a posição do inimigo em direção ao jogador.
        """
        # Cálculo da diferença entre as posições do jogador e do inimigo
        dx = player.rect.x - self.rect.x
        dy = player.rect.y - self.rect.y

        # Calcula a direção (radianos) em que o inimigo deve se mover
        direction = math.atan2(dy, dx)

        # Atualiza a posição do inimigo
        self.rect.x += self.speed * math.cos(direction)
        self.rect.y += self.speed * math.sin(direction)

        # Verifica se o inimigo se move para a direita ou esquerda para inverter a imagem
        if dx > 0:  # Zumbi se movendo para a direita
            self.image = pygame.transform.flip(self.original_image, True, False)  # Inverter horizontalmente
        else:  # Zumbi se movendo para a esquerda
            self.image = self.original_image  # Imagem original (olhando para a esquerda)

        # Atualiza o retângulo da imagem para garantir que o inimigo se mova corretamente
        self.rect = self.image.get_rect(center=self.rect.center)
