import pygame
from utils import Colors, Button
from game import game
import logging

# Configuração de logging
logging.basicConfig(level=logging.INFO)

class Menu:
    def __init__(self, screen):
        self.screen = screen
        self.buttons = self._initialize_buttons()

    def _initialize_buttons(self):
        """Inicializa os botões do menu e os retorna em uma lista."""
        buttons = [
            Button("Wilderness Explorer", pygame.Rect(90, 240, 540, 60), Colors.DARK_RED, self.wilderness_explorer),
            Button("Rules", pygame.Rect(90, 480, 140, 60), Colors.GREY, self.rules),
            Button("Options", pygame.Rect(90, 600, 140, 60), Colors.GREY, self.options),
            Button("Quit", pygame.Rect(450, 600, 140, 60), Colors.GREY, self.quit),
            Button("Credits", pygame.Rect(450, 480, 140, 60), Colors.GREY, self.credits),
            Button("Mini-engine", pygame.Rect(300, 350, 100, 60), Colors.GREY, self.mini_engine)
        ]
        return buttons

    def run(self):
        """Executa o loop do menu."""
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False  # Sai do loop de execução, mas não chama pygame.quit() ainda
                self.handle_event(event)

            self.draw()
            pygame.display.update()

        # Chama pygame.quit() apenas depois que o loop terminar
        pygame.quit()  # Finaliza o Pygame corretamente
        exit()  # Encerra o programa

    def draw(self):
        """Desenha todos os botões e elementos na tela."""
        self.screen.fill(Colors.DEEP_BLACK)
        for button in self.buttons:
            button.draw(self.screen)

        # Adiciona o título do projeto
        font = pygame.font.SysFont('Comic Sans MS', 50)
        title_text = font.render("Computation III - Project", True, Colors.GLOWING_LIGHT_RED)
        self.screen.blit(title_text, (55, 0))

    def handle_event(self, event):
        """Trata eventos de clique nos botões."""
        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse_pos = event.pos
            for button in self.buttons:
                if button.is_clicked(mouse_pos):
                    button.click()

    def wilderness_explorer(self):
        """Inicia o jogo."""
        logging.info("Iniciando o jogo...")
        game.game_loop()

    def rules(self):
        """Exibe as regras."""
        logging.info("Exibindo regras...")

    def options(self):
        """Exibe as opções."""
        logging.info("Exibindo opções...")

    def quit(self):
        """Sai do jogo."""
        logging.info("Saindo do jogo...")
        pygame.quit()
        exit()

    def credits(self):
        """Exibe os créditos."""
        logging.info("Exibindo créditos...")

    def mini_engine(self):
        """Função para iniciar a mini-engine."""
        logging.info("Iniciando a mini-engine...")
        # Adicione aqui a lógica para iniciar a mini-engine


