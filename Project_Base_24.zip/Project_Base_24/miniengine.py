import pygame

class MiniEngine:
    def __init__(self, screen):
        self.screen = screen
        self.items = []

    def handle_events(self):
        """
        Função para processar eventos de entrada, como cliques do mouse.
        """
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  # Verifica se o clique é do botão esquerdo
                    mouse_x, mouse_y = event.pos
                    # Adiciona o item na posição do clique (exemplo: imagem de item padrão)
                    self.items.append({'image': None, 'position': (mouse_x, mouse_y)})

    def render_items(self):
        """
        Função para desenhar todos os itens na tela.
        """
        for item in self.items:
            if item['image/zombie(1)']:  # Verifica se a imagem foi definida
                self.screen.blit(item['image'], item['position'])

    def update(self):
        """
        Atualiza a tela com a renderização dos itens.
        """
        self.handle_events()
        self.render_items()
        pygame.display.update()




