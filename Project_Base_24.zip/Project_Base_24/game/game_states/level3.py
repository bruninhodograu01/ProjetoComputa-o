# upper_state.py

from game.game_states.mainstate import MainGameState
from utils import Settings, draw_health_bar, draw_exp_bar, draw_money
from powerups import *
from enemy import Zombie
# Inicialização da tela e da instância de Utils
screen = pygame.display.set_mode(Settings.RESOLUTION)
pygame.display.set_caption("Game State")

class Level3(MainGameState):
    def __init__(self, game):
        super().__init__(game, spawn_rate=0.4, enemy_limit=5)


    def run(self):
        """Metodo principal do estado atual do jogo, onde verificamos as condições de transição."""
        clock = pygame.time.Clock()
        background = pygame.image.load("images/imagem background final.png")
        background = pygame.transform.scale(background, Settings.RESOLUTION)

        player = self.player
        player_group = pygame.sprite.Group(player)

        entry_position = self.game.get_player_entry_position()
        if entry_position:
            entry_x, entry_y = entry_position
            player.rect.topleft = (entry_x, entry_y)

        running = True
        while running:
            clock.tick(Settings.FPS)
            self.screen.blit(background, (0, 0))

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    exit()

                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    self.shoot(player, pygame.mouse.get_pos())

                if event.type == pygame.KEYDOWN:
                    if event.key in (pygame.K_1, pygame.K_2, pygame.K_3, pygame.K_4):
                        player.select_weapon(event.key - pygame.K_1)

                    if event.key == pygame.K_9:  # Salva o jogo
                        self.save_game()


                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    for chest in self.chests:
                        chosen_powerup = chest.check_click(event.pos)
                        if chosen_powerup:
                            chest.improve_powerup(chosen_powerup)
                            self.chests.remove(chest)  # Remove o baú após escolher


            self.handle_collisions()
            self.bullets.update()
            self.spawn_enemy()
            self.check_player_powerup_collision()
            self.check_player_chest_collision()  # Abre baús automaticamente
            self.powerups.update()
            self.chests.update()  # Atualiza os baús
            player_group.update()  # Atualiza os estados dos sprites
            for sprite in player_group:
                sprite.render(screen)  # Desenha os sprites


            self.chests.draw(self.screen)
            for chest in self.chests:
                if chest.opened:
                    chest.display_options(self.screen)

            # Gerar o boss somente se todos os zombies foram derrotados
            if len([enemy for enemy in self.enemies if isinstance(enemy, Zombie)]) == 0:
                if self.zombies_generated >= self.enemy_limit and not self.boss_spawned:
                    self.spawn_boss()

            # Gerar power-ups com base nas probabilidades
            if random.random() < 0.1 and self.active_powerup is None:  # Garante que apenas um power-up será gerado de cada vez
                self.spawn_powerup()

            for enemy in self.enemies:
                enemy.update(player, self.bullets, self.enemies)



            draw_health_bar(self.screen, 70, 20, player.health, player.max_health)
            draw_exp_bar(self.screen, self.player, x=70, y=41)
            draw_money(self.screen, player)


            player_group.draw(self.screen)
            self.enemies.draw(self.screen)
            self.bullets.draw(self.screen)
            self.powerups.draw(self.screen)  # Desenha os power-ups

            pygame.display.flip()

            if player.weapon_cooldown > 0:
                player.weapon_cooldown -= 1

            if player.rect.left <= 0 and Settings.MIDDLE_TOP <= player.rect.centery <= Settings.MIDDLE_BOTTOM:
                print("Jogador saiu para o estado 'level2'")
                self.save_game()
                player.rect.left = Settings.WIDTH - player.rect.width
                self.next_state = "level2"
                return self.next_state

            if self.check_boss_defeated():
                if player.rect.right >= Settings.WIDTH and Settings.MIDDLE_TOP <= player.rect.centery <= Settings.MIDDLE_BOTTOM:
                    print(f"Jogador derrotou o Boss e saiu para o próximo estado 'level4'")  # Debug
                    self.save_game()  # Salva o progresso automaticamente
                    self.game.set_player_entry_position((0, player.rect.y))
                    self.next_state = "level4"  # Define o próximo estado
                    running = False


        return self.next_state