# player
import pygame

import math
from utils import Settings
import pickle


class Player(pygame.sprite.Sprite):


    def __init__(self):
        super().__init__()
        self.powerups = pygame.sprite.Group()
        self.original_image = pygame.image.load("images/player_with_gun.png").convert_alpha()
        self.image = self.original_image
        self.rect = self.image.get_rect()
        self.rect.center = (Settings.WIDTH // 2, Settings.HEIGHT // 2)
        self.is_invincible = False
        self.damageB_active = False
        self.color = (255, 255, 255)
        self.direction = 0
        self.alive = True
        self.aura_color = None
        self.aura_duration = 0

        # Atributos do jogador
        self.speed = 3
        self.health_regen_multiplier = 1
        self.damage_multiplier = 1
        self.damage = 0
        self.health = 100
        self.max_health = 100

        # exp and money
        self.money = 0
        self.level = 1
        self.exp = 0
        self.exp_to_next_level = 100

        # regen
        self.regen_rate = 1
        self.regen_cooldown = 120  # 2 segundos
        self.regen_timer = 0

        #powerups
        self.damage_boost = None
        self.health_regen = None
        self.regen_boost = None
        self.invincibility = None
        self.despawner = None

        # weapons
        self.weapon_cooldown = 0  # cooldown da arma
        self.current_weapon_index = 0
        self.purchased_weapons = []  # Lista das armas compradas
        self.weapons = [
            {"name": "Pistola", "damage": 10, "speed": 7, "pattern": "single", "cooldown": 10},
            {"name": "Espingarda", "damage": 20, "speed": 5, "pattern": "spread", "spread": 20, "cooldown": 30,
             "locked": True},
            {"name": "Rifle", "damage": 15, "speed": 10, "pattern": "single", "cooldown": 5, "locked": True},
            {"name": "Cajado", "damage": 0, "speed": 0, "pattern": "none", "cooldown": 50, "special": True,
             "locked": True},  # Cajado bloqueado inicialmente
        ]
        self.cooldown = self.weapons[self.current_weapon_index]["cooldown"]
    def unlock_weapon(self, weapon_name):
        """Desbloqueia uma arma quando comprada"""
        for weapon in self.weapons:
            if weapon["name"] == weapon_name:
                weapon["locked"] = False
                self.purchased_weapons.append(weapon_name)

    def is_weapon_unlocked(self, weapon_name):
        """Verifica se uma arma está desbloqueada"""
        for weapon in self.weapons:
            if weapon["name"] == weapon_name:
                return not weapon.get("locked", False)
        return False

    def apply_health_regen(self):
        if self.health_regen:
            self.health += self.health_regen.quantificator
            if self.health > self.max_health:
                self.health = self.max_health

    def handle_regeneration(self):
        self.regen_timer += 1
        if self.regen_timer >= self.regen_cooldown and self.health < self.max_health:
            # Aplica o multiplicador de regeneração
            self.health += self.regen_rate * self.health_regen_multiplier
            self.health = min(self.health, self.max_health)
            self.regen_timer = 0

    def save_player_progress(self, filename="player_data.pkl"):
        with open(filename, "wb") as f:
            # Aqui, salvamos o estado do jogador, sem a mecânica dos power-ups
            pickle.dump({
                "money": self.money,
                "level": self.level,
                "exp": self.exp,
                "exp_to_next_level": self.exp_to_next_level,
                "health": self.health,
                "max_health": self.max_health,
                "damage_multiplier": self.damage_multiplier,
                "health_regen_multiplier": self.health_regen_multiplier,
                "current_weapon_index": self.current_weapon_index,
                "purchased_weapons": self.purchased_weapons,
            }, f)
            print("Progresso do jogador salvo!")

    def load_player_progress(self, filename="player_data.pkl"):
        try:
            with open(filename, "rb") as f:
                # Carrega o progresso do jogador
                data = pickle.load(f)

                # Restaura os atributos do jogador a partir dos dados carregados
                self.money = data.get("money")
                self.level = data.get("level")
                self.exp = data.get("exp")
                self.exp_to_next_level = data.get("exp_to_next_level")
                self.max_health = data.get("max_health")  # Atualiza max_health
                self.health = min(data.get("health", self.max_health), self.max_health)
                self.damage_multiplier = data.get("damage_multiplier")
                self.health_regen_multiplier = data.get("health_regen_multiplier")
                self.current_weapon_index = data.get("current_weapon_index")
                self.purchased_weapons = data.get("purchased_weapons", [])

                # Restaura o cooldown da arma
                self.cooldown = self.weapons[self.current_weapon_index]["cooldown"]

                # Desbloqueia as armas que foram compradas
                for weapon_name in self.purchased_weapons:
                    self.unlock_weapon(weapon_name)

                print("Progresso do jogador carregado!")
        except FileNotFoundError:
            print("Arquivo de progresso do jogador não encontrado. Nenhum progresso carregado.")

    def reset_player_to_default(self):
        self.money = 0
        self.level = 1
        self.exp = 0
        self.exp_to_next_level = 100
        self.health = 100
        self.max_health = 100
        self.damage_multiplier = 1
        self.health_regen_multiplier = 1
        self.current_weapon_index = 0
        self.cooldown = self.weapons[self.current_weapon_index]["cooldown"]
        self.purchased_weapons = []  # Aqui, você define como uma lista vazia
        print("Progresso do jogador resetado para os valores padrão!")

    def use_staff(self, enemies):
        """Usa o cajado para derrotar todos os inimigos no mapa."""
        if self.get_current_weapon().get("special"):  # Verifica se a arma é o cajado
            for enemy in enemies:
                enemy.take_damage(9999, self)  # Dano suficiente para matar todos os inimigos
            print("Todos os inimigos foram derrotados com o Cajado!")

    def buy_weapon(self, weapon_name):
        """
        Permite que o jogador compre uma arma, caso tenha dinheiro suficiente.
        """
        weapon_prices = {
            "Espingarda": 100,  # Preço da espingarda
            "Rifle": 150,  # Preço do rifle
            "Cajado": 200,  # Preço do cajado
        }

        if weapon_name in weapon_prices and self.money >= weapon_prices[weapon_name]:
            # Deduz o preço da arma do dinheiro do jogador
            self.money -= weapon_prices[weapon_name]

            # Adiciona a arma ao inventário
            for i, weapon in enumerate(self.weapons):
                if weapon["name"] == weapon_name:
                    self.select_weapon(i)  # Seleciona a arma comprada
                    print(f"Você comprou a {weapon_name}!")
                    break
        else:
            print("Você não tem dinheiro suficiente para comprar essa arma.")

    def get_current_weapon(self):
        return self.weapons[self.current_weapon_index]

    def select_weapon(self, index):
        if 0 <= index < len(self.weapons):
            self.current_weapon_index = index
            self.cooldown = self.weapons[self.current_weapon_index]["cooldown"]
            print(f"Arma selecionada: {self.weapons[index]['name']}")

    def gain_money(self, amount):
        """Método para o jogador ganhar dinheiro ao derrotar inimigos."""
        if amount is not None:
            self.money += amount
        else:
            print("Erro: amount é None")

    def render_money(self, screen):
        """Método para renderizar a quantidade de dinheiro na tela."""
        font = pygame.font.Font(None, 36)  # Escolhe a fonte e o tamanho
        money_text = font.render(f"Dinheiro: ${self.money}", True, (255, 255, 255))  # Cor do texto
        screen.blit(money_text, (10, 10))

    def level_up(self):
        self.level += 1
        self.exp_to_next_level = int(self.exp_to_next_level * 1.5)
        self.max_health += 10
        self.health = self.max_health
        print(f"Subiu de nível! Nível atual: {self.level}")

    def gain_exp(self, amount):
        self.exp += amount
        while self.exp >= self.exp_to_next_level:
            self.exp -= self.exp_to_next_level
            self.level_up()

    def update(self):
        # Atualiza o estado do jogador
        self.damage = 10 * self.damage_multiplier

        if self.aura_duration > 0:
            self.aura_duration -= 1
        else:
            self.aura_color = None
            self.is_invincible = False  # Desativa a invencibilidade quando a aura acaba

        self.handle_movement()
        self.update_direction()
        self.handle_regeneration()

    def render(self, screen):
        # Desenha o jogador e elementos visuais
        if self.aura_color:
            pygame.draw.circle(
                screen,
                self.aura_color,
                self.rect.center,
                self.rect.width // 2 + 10,  # Tamanho da aura
                4  # Largura da borda
            )
        screen.blit(self.image, self.rect)

    def handle_movement(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_w] and self.rect.top > 0:
            self.rect.y -= self.speed
        if keys[pygame.K_s] and self.rect.bottom < Settings.HEIGHT:
            self.rect.y += self.speed
        if keys[pygame.K_a] and self.rect.left > 0:
            self.rect.x -= self.speed
        if keys[pygame.K_d] and self.rect.right < Settings.WIDTH:
            self.rect.x += self.speed

    def update_direction(self):
        mouse_x, mouse_y = pygame.mouse.get_pos()
        rel_x = mouse_x - self.rect.centerx
        rel_y = mouse_y - self.rect.centery
        angle = math.degrees(math.atan2(rel_y, rel_x))
        self.direction = angle
        self.image = pygame.transform.rotate(self.original_image, -self.direction)
        self.rect = self.image.get_rect(center=self.rect.center)

    def die(self):
        """Método chamado quando o jogador morre."""
        print("O jogador morreu!")
        # Aqui pode adicionar lógica para o fim do jogo ou reiniciar
        self.alive = False  # Marque o jogador como morto
        self.kill()  # Remove o sprite do jogador (se necessário)

    def take_damage(self, amount):
        """Método para reduzir a saúde do jogador quando ele é atingido."""
        if not self.is_invincible:  # Verifica se o jogador não está invencível
            self.health -= amount
            if self.health <= 0:
                self.health = 0
                self.die()  # Lógica de morte do jogador, se necessário

    def attack(self, target):
        weapon = self.get_current_weapon()
        base_damage = weapon["damage"]
        # Aplica o multiplicador apenas se o power-up estiver ativo
        if self.damageB_active:
            total_damage = base_damage * self.damage_multiplier
        else:
            total_damage = base_damage

        target.take_damage(total_damage)
        print(f"{target} levou {total_damage} de dano.")

    def on_powerup_collected(self, powerup):
        """Método chamado quando o jogador coleta um Power-up"""
        # Chama a função affect_player do Power-up para ativar o efeito no jogador
        powerup.affect_player(self)
        powerup.is_active = True  # Marca o Power-up como ativo
