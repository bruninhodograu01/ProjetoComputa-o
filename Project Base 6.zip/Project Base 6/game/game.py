#game.py


import pygame
from utils import Settings
from game.game_states.mainstate import MainGameState
from game.game_states.shedstate import ShedState

from player import Player


def game_loop():
    pygame.display.set_caption("Wilderness Explorer")
    clock = pygame.time.Clock()

    game = {"player": Player(), "current_state": "main"}

    states = {
        "main": MainGameState(game),
        "shed": ShedState(game),
    }

    running = True
    while running:
        state = states.get(game["current_state"])
        if state:
            next_state = state.run()
            if next_state:
                game["current_state"] = next_state
        else:
            print(f"Estado desconhecido: {game['current_state']}")
            running = False

        clock.tick(Settings.FPS)
    pygame.quit()


'''
def game_loop():
    game = {"player": Player(), "current_state": "main"}
    states = {
        "main": MainGameState(game),
        "shed": ShedState(game),
    }


    pygame.display.set_caption("Wilderness Explorer")
    clock = pygame.time.Clock()

    running = True


    while running:
        # Convertendo 'game' para um dicionário normal para acesso seguro
        game_dict = dict(game)

        state = states.get(game_dict.get("current_state"))
        if state:
            next_state = state.run()
            if next_state:
                game_dict["current_state"] = next_state
                # Atualizando o TypedDict original, se necessário
                game.update(game_dict)
        else:
            print("Estado desconhecido!")
            pygame.quit()
            exit()

        clock.tick(Settings.FPS)
'''
