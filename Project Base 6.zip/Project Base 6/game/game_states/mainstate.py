#main_ state

import pygame
from utils import Settings
from bullet import Bullet
from enemy import Enemy
import math
from underC import underC

# Inicialize a tela e a instância de Utils fora das classes
screen = pygame.display.set_mode((720, 720))
pygame.display.set_caption("Game State")
utils = underC(screen)  # Instância de Utils


middle_top = Settings.HEIGHT // 2 - 50  # Parte superior da faixa (ajuste 50 para ajustar a largura da faixa)
middle_bottom = Settings.HEIGHT // 2 + 50  # Parte inferior da faixa
class MainGameState:

    def __init__(self, game):
        self.game = game
        self.next_state = None
        self.bullets = pygame.sprite.Group()
        self.screen = screen
        self.utils = utils  # Referência à instância de Utils

    def run(self):
        screen = pygame.display.get_surface()
        clock = pygame.time.Clock()
        background = pygame.image.load("images/most_perfect_thing.jpeg")
        background = pygame.transform.scale(background, Settings.RESOLUTION)

        player = self.game["player"]
        player_group = pygame.sprite.Group()
        player_group.add(player)


        enemies = pygame.sprite.Group()
        enemy_cooldown = 0

        running = True
        while running:
            clock.tick(Settings.FPS)
            screen.blit(background, (0, 0))

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    exit()
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    angle = math.radians(player.direction)
                    bullet = Bullet(player.rect.centerx, player.rect.centery, angle)
                    self.bullets.add(bullet)

            player_group.update()
            enemies.update(player)

            if enemy_cooldown <= 0:
                enemy = Enemy()
                enemies.add(enemy)
                enemy_cooldown = Settings.FPS * 2
            enemy_cooldown -= 1

            self.bullets.update()
            for bullet in self.bullets:
                bullet.draw(screen)

            for bullet in self.bullets:
                collided_enemies = pygame.sprite.spritecollide(bullet, enemies, False)
                for enemy in collided_enemies:
                    enemy.health -= bullet.damage
                    bullet.kill()
                    if enemy.health <= 0:
                        enemy.kill()


            if player.rect.right >= Settings.WIDTH and middle_top <= player.rect.centery <= middle_bottom:
                print("Jogador saiu para o estado 'shed'")
                self.game["player_entry_position"] = (0, player.rect.y)
                self.next_state = "shed"

                return self.next_state



            player_group.draw(screen)
            enemies.draw(screen)
            pygame.display.flip()
