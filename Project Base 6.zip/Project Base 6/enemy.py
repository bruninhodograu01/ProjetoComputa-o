#enemy.py

import pygame
import math
import random
from utils import Settings



class Enemy(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        # Carregar a imagem original do inimigo (exemplo de zumbi)
        self.original_image = pygame.image.load("images/zombie(1).png").convert_alpha()
        self.image = self.original_image
        self.rect = self.image.get_rect()
        self.enemies = pygame.sprite.Group()

        # Inicializar a posição do inimigo aleatoriamente
        self.rect.x = random.randint(0, Settings.WIDTH - self.rect.width)
        self.rect.y = random.randint(0, Settings.HEIGHT - self.rect.height)

        # Configurar a velocidade e saúde do inimigo
        self.speed = 1
        self.health = 10

    def update(self, player):
        """
        Atualiza a posição do inimigo para se mover em direção ao jogador.
        """
        # Cálculo da diferença entre as posições do jogador e do inimigo
        dx = player.rect.x - self.rect.x
        dy = player.rect.y - self.rect.y

        # Calcula a direção (em radianos) para o movimento
        direction = math.atan2(dy, dx)

        # Atualiza a posição do inimigo
        self.rect.x += self.speed * math.cos(direction)
        self.rect.y += self.speed * math.sin(direction)

        # Atualiza a imagem com base na direção do movimento (esquerda/direita)
        self.update_image(dx)

        # Atualiza o retângulo da imagem para manter a posição correta
        self.rect = self.image.get_rect(center=self.rect.center)

    def update_image(self, dx):
        """
        Atualiza a imagem do inimigo para refletir a direção do movimento.
        """
        if dx > 0:  # Movimento para a direita
            self.image = pygame.transform.flip(self.original_image, True, False)
        else:  # Movimento para a esquerda
            self.image = self.original_image


