import pygame
from utils import *

class underC:

    def __init__(self, screen):
        self.screen = screen
        self.resolution = Settings.RESOLUTION
        self.deep_black = Colors.DEEP_BLACK
        self.white = Colors.WHITE
        self.dark_red = Colors.DARK_RED

    def draw_stick_figure_with_hat(self, x, y):
        """
        Desenha uma figura de pau com um chapéu de construção.
        """
        # cabeça
        pygame.draw.circle(self.screen, (255, 255, 255), (x, y), 20, 2)

        # corpo
        pygame.draw.line(self.screen, (255, 255, 255), (x, y + 20), (x, y + 60), 2)

        # braços
        pygame.draw.line(self.screen, (255, 255, 255), (x, y + 40), (x - 30, y + 40), 2)
        pygame.draw.line(self.screen, (255, 255, 255), (x, y + 40), (x + 30, y + 40), 2)

        # pernas
        pygame.draw.line(self.screen, (255, 255, 255), (x, y + 60), (x - 20, y + 100), 2)
        pygame.draw.line(self.screen, (255, 255, 255), (x, y + 60), (x + 20, y + 100), 2)

        # chapéu
        hat_color = (255, 215, 0)
        pygame.draw.rect(self.screen, hat_color, [x - 25, y - 30, 50, 10])  # aba do chapéu
        pygame.draw.rect(self.screen, hat_color, [x - 20, y - 40, 40, 20])  # domo do chapéu

    def draw_normal_stick_figure(self, x, y):
        """
        Desenha uma figura de pau normal.
        """
        # cabeça
        pygame.draw.circle(self.screen, (255, 255, 255), (x, y), 20, 2)

        # corpo
        pygame.draw.line(self.screen, (255, 255, 255), (x, y + 20), (x, y + 60), 2)

        # braços
        pygame.draw.line(self.screen, (255, 255, 255), (x, y + 40), (x - 30, y + 40), 2)
        pygame.draw.line(self.screen, (255, 255, 255), (x, y + 40), (x + 30, y + 40), 2)

        # pernas
        pygame.draw.line(self.screen, (255, 255, 255), (x, y + 60), (x - 20, y + 100), 2)
        pygame.draw.line(self.screen, (255, 255, 255), (x, y + 60), (x + 20, y + 100), 2)

    def display_message(self, message, position=(400, 300), font_size=50, color=(255, 255, 255)):
        """
        Exibe uma mensagem na tela.
        """
        font = pygame.font.SysFont('Arial', font_size)
        text = font.render(message, True, color)
        text_rect = text.get_rect(center=position)
        self.screen.blit(text, text_rect)

    def draw_button(self, text, position, size=(200, 60), font_size=30, color=(0, 128, 255), text_color=(255, 255, 255)):
        """
        Desenha um botão na tela e exibe o texto.
        """
        x, y = position
        button_rect = pygame.Rect(x, y, size[0], size[1])
        pygame.draw.rect(self.screen, color, button_rect)
        font = pygame.font.SysFont('Arial', font_size)
        text_surface = font.render(text, True, text_color)
        text_rect = text_surface.get_rect(center=button_rect.center)
        self.screen.blit(text_surface, text_rect)
        return button_rect

    def is_button_clicked(self, button_rect, event):
        """
        Verifica se um botão foi clicado.
        """
        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse_x, mouse_y = event.pos
            if button_rect.collidepoint(mouse_x, mouse_y):
                return True
        return False

    def handle_interface_events(self, buttons):
        """
        Processa eventos de clique em botões.
        """
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            for button_text, button_rect in buttons.items():
                if self.is_button_clicked(button_rect, event):
                    if button_text == "Back":
                        return "back"
                    elif button_text == "Mini Engine":
                        return "mini_engine"
        return None

    def under_construction(self):
        """
        Tela de 'Under Construction' com figuras e botões.
        """
        corbelfont = pygame.font.SysFont("Corbel", 50)
        conversation_font = pygame.font.SysFont("Arial", 30)

        # Textos
        back_text = corbelfont.render("Back", True, self.white)
        construction_text = corbelfont.render("UNDER CONSTRUCTION", True, self.white)
        first_speech = conversation_font.render("Can we fix it?", True, self.white)
        bob_speech = conversation_font.render("Probably not...", True, self.white)

        # Posições
        bob_x, bob_y = 460, 450
        normal_x, normal_y = 260, 450

        running = True
        while running:
            self.screen.fill(self.deep_black)

            # Desenha o texto de construção
            construction_rect = construction_text.get_rect(center=(self.resolution[0] // 2, 300))
            self.screen.blit(construction_text, construction_rect)

            # Botão de volta
            back_rect = self.draw_button("Back", (450, 600), size=(140, 60), color=self.dark_red)

            # Desenha as figuras de pau e os textos de fala
            self.draw_normal_stick_figure(normal_x, normal_y)
            self.draw_stick_figure_with_hat(bob_x, bob_y)

            self.screen.blit(first_speech, (normal_x - 60, normal_y - 80))
            self.screen.blit(bob_speech, (bob_x - 60, bob_y - 80))

            # Verifica eventos de clique
            action = self.handle_interface_events({'Back': back_rect})
            if action == "back":
                running = False

            pygame.display.update()

