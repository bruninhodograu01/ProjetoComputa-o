# game.py

import pygame
from utils import Settings
from player import Player
from game.game_states.mainstate import MainGameState
from game.game_states.shedstate import ShedState
from game.game_states.level1 import Level1


class Game:
    """
    Classe que representa o jogo e gerencia seus estados, o jogador, e outras entidades como inimigos e power-ups.

    A classe Game é responsável pela inicialização do jogo, gerenciamento de estados, controle do jogador e
    a lógica de transições de estado.

    Attributes
    ----------
    screen : pygame.Surface
        A superfície da tela onde o jogo será exibido.
    player : Player
        A instância do jogador controlado no jogo.
    spawn_rate : float
        A taxa de spawn de inimigos no jogo.
    bullets : pygame.sprite.Group
        Grupo de balas disparadas pelo jogador.
    enemies : pygame.sprite.Group
        Grupo de inimigos presentes no jogo.
    powerups : pygame.sprite.Group
        Grupo de power-ups no jogo.
    chests : pygame.sprite.Group
        Grupo de baús presentes no jogo.
    state : GameState, optional
        O estado atual do jogo.
    _player_entry_position : tuple of int
        A posição de entrada do jogador no mapa.
    """

    def __init__(self):
        """
        Inicializa uma nova instância do jogo.

        Este método configura a tela, cria o jogador e inicializa as taxas de spawn,
        grupos de sprites para balas, inimigos, power-ups e baús, e define o estado inicial do jogo.

        Attributes
        ----------
        screen : pygame.Surface
            A tela onde o jogo será exibido.
        player : Player
            A instância do jogador no jogo.
        spawn_rate : float
            A taxa de spawn dos inimigos.
        bullets : pygame.sprite.Group
            O grupo de balas disparadas.
        enemies : pygame.sprite.Group
            O grupo de inimigos no jogo.
        powerups : pygame.sprite.Group
            O grupo de power-ups disponíveis no jogo.
        chests : pygame.sprite.Group
            O grupo de baús presentes no jogo.
        state : GameState, optional
            O estado atual do jogo.
        _player_entry_position : tuple of int
            A posição inicial do jogador.
        """
        self.screen = pygame.display.set_mode((Settings.WIDTH, Settings.HEIGHT))  # Criação da tela
        self.player = Player()  # Passando a instância de Game para o jogador
        self.spawn_rate = 1.0  # A taxa inicial de spawn de inimigos
        self.bullets = pygame.sprite.Group()
        self.enemies = pygame.sprite.Group()
        self.powerups = pygame.sprite.Group()
        self.chests = pygame.sprite.Group()
        self.state = None  # Estado atual do jogo
        self._player_entry_position = (0, 0)

    def set_player_entry_position(self, position):
        """
        Define a posição de entrada do jogador no jogo.

        Parameters
        ----------
        position : tuple of int
            A posição (x, y) onde o jogador começará o jogo.
        """
        self._player_entry_position = position

    def get_player_entry_position(self):
        """
        Retorna a posição de entrada do jogador.

        Returns
        -------
        tuple of int
            A posição (x, y) de entrada do jogador.
        """
        return self._player_entry_position

    def change_state(self, state):
        """
        Altera o estado atual do jogo para o novo estado.

        Parameters
        ----------
        state : GameState
            O novo estado a ser definido como o estado atual.
        """
        self.state = state


def game_loop():
    """
    Loop principal do jogo, onde os estados são processados e transições entre estados ocorrem.

    Este método controla a execução do jogo, processando a lógica dos estados, realizando as transições
    entre eles e mantendo o jogo em execução até que o jogador decida sair ou o jogo termine.

    A função cria e gerencia os estados do jogo, como "main", "shed" e "level1", e assegura que a transição
    entre os estados ocorra de forma adequada.

    Returns
    -------
    None
    """
    pygame.display.set_caption("Wilderness Explorer")
    clock = pygame.time.Clock()

    # Inicializa o jogo com a classe Game
    game = Game()  # Agora é uma instância de Game, não um dicionário
    states = {
        "main": MainGameState,
        "shed": ShedState,
        "level1": Level1,
    }

    current_state_name = "main"  # Inicialmente, começa no estado "main"
    current_state = states[current_state_name](game)  # Instancia o primeiro estado
    game.change_state(current_state)  # Define o estado atual no objeto Game

    while current_state:
        next_state_name = current_state.run()  # Executa o estado atual

        if next_state_name:
            # Troca para o próximo estado
            if next_state_name in states:
                next_state = states[next_state_name](game)
                game.change_state(next_state)  # Atualiza o estado no objeto Game
                current_state = next_state
            else:
                print(f"Estado desconhecido: {next_state_name}")
                break
        else:
            break  # Sai do loop se não houver próximo estado

        clock.tick(Settings.FPS)

    pygame.quit()




