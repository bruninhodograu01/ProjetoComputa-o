import math
from utils import Settings, draw_health_bar, draw_exp_bar, draw_money
from powerups import *
from bullet import Bullet
from enemy import Zombie, Boss
from player import Player
from chest import Chest

# Inicialização da tela e da instância de Utils
pygame.display.set_caption("Game State")

class MainGameState:
    """
    Classe que gerencia o estado principal do jogo, incluindo a lógica de inimigos, power-ups, balas, e interações do jogador.

    Atributos:
    game (Game): A instância do jogo.
    next_state (str): O próximo estado do jogo após a transição.
    bullets (pygame.sprite.Group): Grupo de balas disparadas no jogo.
    enemies (pygame.sprite.Group): Grupo de inimigos presentes no jogo.
    powerups (pygame.sprite.Group): Grupo de power-ups gerados no jogo.
    chests (pygame.sprite.Group): Grupo de baús gerados no jogo.
    screen (pygame.Surface): A superfície da tela onde o jogo é exibido.
    spawn_rate (float): Taxa de spawn de inimigos.
    enemy_limit (int): Limite máximo de inimigos no jogo.
    zombies_generated (int): Contador de inimigos gerados.
    enemy_cooldown (int): Cooldown para o spawn de inimigos.
    enemy_counter (int): Contador auxiliar de spawn de inimigos.
    player (Player): A instância do jogador.
    boss_spawned (bool): Indica se o Boss foi gerado.
    active_powerup (str): O power-up ativo no momento.
    active_chest (bool): Indica se um baú está ativo.
    powerup_chances (dict): Dicionário com as chances de spawn de cada power-up.
    used_powerups (list): Lista de power-ups já usados.
    all_options (list): Lista com todos os tipos de power-ups.
    available_options (list): Opções de power-ups disponíveis para os baús.
    powerup_spawn_probability (float): Probabilidade global de spawn de power-ups.
    max_active_powerups (int): Limite máximo de power-ups ativos.
    """

    def __init__(self, game, spawn_rate=0.5, enemy_limit=10, powerup_chances=None, powerup_spawn_probability=1):
        """
        Inicializa a instância do estado principal do jogo.

        Parâmetros:
        game (Game): A instância do jogo.
        spawn_rate (float, opcional): Taxa de spawn de inimigos (padrão é 0.5).
        enemy_limit (int, opcional): Limite máximo de inimigos (padrão é 10).
        powerup_chances (dict, opcional): Dicionário com as chances de spawn de power-ups (padrão é None).
        powerup_spawn_probability (float, opcional): Probabilidade global de spawn de power-ups (padrão é 1).
        """
        self.game = game
        self.next_state = None
        self.bullets = pygame.sprite.Group()
        self.enemies = pygame.sprite.Group()
        self.powerups = pygame.sprite.Group()
        self.chests = pygame.sprite.Group()  # Grupo para os baús
        self.screen = Settings.SCREEN
        self.spawn_rate = spawn_rate
        self.enemy_limit = enemy_limit
        self.zombies_generated = 0  # Número total de zombies gerados
        self.enemy_cooldown = Settings.FPS * self.spawn_rate
        self.enemy_counter = 0
        self.player = Player()
        self.boss_spawned = False  # Indica se o Boss já foi gerado
        self.active_powerup = None  # Variável para controlar o power-up ativo
        self.active_chest = False

        self.player.load_player_progress()

        # Probabilidades de spawn dos power-ups
        if powerup_chances is None:
            powerup_chances = {
                "InvincibilityPU": 1.0,  # 20% de chance de gerar
                "DespawnerPU": .0,  # 10% de chance de gerar
                "RegenBoostPU": .0,  # 30% de chance de gerar
                "HealthRegenPU": .0,  # 30% de chance de gerar
                "DamageBoostPU": .0,  # 10% de chance de gerar
            }
        self.powerup_chances = powerup_chances
        self.used_powerups = []  # Lista de power-ups já usados
        self.all_options = ['DamageBoostPU', 'HealthRegenPU', 'RegenBoostPU', 'InvincibilityPU', 'DespawnerPU']

        # Se as opções de power-ups estiverem vazias, não geramos mais baús
        self.available_options = self.all_options.copy()

        # Probabilidade global de spawn de power-ups
        self.powerup_spawn_probability = powerup_spawn_probability

        # Limite máximo de power-ups ativos
        self.max_active_powerups = 3

    def save_game(self):
        """
        Salva o estado atual do jogo, incluindo o progresso do jogador.

        Este método chama o método `save_player_progress` do jogador para armazenar o progresso.
        """
        self.player.save_player_progress()
        print("Jogo salvo!")

    def load_game(self):
        """
        Carrega o progresso salvo do jogador.

        Este método chama o método `load_player_progress` do jogador para restaurar o progresso.
        """
        self.player.load_player_progress()
        print("Jogo carregado!")

    def spawn_powerup(self):
        """
        Gera um power-up aleatoriamente com base nas probabilidades, respeitando o limite de power-ups ativos.

        Verifica se o número de power-ups ativos é menor que o limite máximo. Se sim, gera um power-up
        com base nas probabilidades fornecidas e o adiciona ao grupo de power-ups.
        """
        if len(self.powerups) < self.max_active_powerups:  # Verifica se há espaço para mais power-ups
            # Verifica se a probabilidade global de spawn de power-ups foi alcançada
            if random.random() <= self.powerup_spawn_probability:
                rand_value = random.random()  # Gera um número aleatório entre 0 e 1
                cumulative_probability = 0.0

                # Determina o power-up com base na probabilidade
                for powerup_class_name, chance in self.powerup_chances.items():
                    cumulative_probability += chance
                    if rand_value <= cumulative_probability:
                        # Determina a posição aleatória na tela para o power-up
                        x = random.randint(0, Settings.WIDTH)
                        y = random.randint(0, Settings.HEIGHT)
                        # Instancia o power-up de acordo com a classe
                        powerup_class = globals()[powerup_class_name]
                        powerup = powerup_class(x, y)  # A posição aleatória pode ser configurada
                        self.powerups.add(powerup)
                        return

    def handle_collisions(self):
        """
        Verifica colisões entre balas e inimigos ou jogador e aplica dano se houver colisão.

        Para cada bala, verifica se ela colide com algum inimigo. Se colidir, o dano é aplicado ao inimigo
        e a bala é destruída.
        """
        for bullet in self.bullets:
            # Verificar colisões entre a bala e inimigos
            for enemy in pygame.sprite.spritecollide(bullet, self.enemies, False):
                enemy.take_damage(bullet.damage, self.player)
                if bullet.origin != enemy:  # Evitar que balas de inimigos colidam com outros inimigos
                    enemy.take_damage(bullet.damage, self.player)
                    bullet.kill()
                    print(bullet.damage)

    def check_player_powerup_collision(self):
        """
        Verifica colisões entre o jogador e power-ups, e aplica os efeitos do power-up.

        Se o jogador colidir com um power-up, o power-up afetará o jogador e o jogo, marcando-o como ativo
        e destruindo-o após o uso.
        """
        for powerup in self.powerups:
            if self.player.rect.colliderect(powerup.rect):
                print(f"Colisão detectada com {type(powerup).__name__}")
                powerup.affect_player(self.player)
                powerup.affect_game(self)
                powerup.is_active = True  # Marca o Power-up como ativo
                powerup.kill()  # Destrói o Power-up após ser usado

    def spawn_enemy(self):
        """
        Cria e adiciona novos zombies até atingir o limite definido.

        Este método cria zombies com atributos predeterminados (saúde, dano, velocidade, etc.) e os adiciona
        ao grupo de inimigos, respeitando o limite máximo de inimigos.
        """
        if self.zombies_generated < self.enemy_limit:
            # Atributos do zombie
            health = 100
            damage = 10
            speed = 2
            exp_reward = 50
            money_reward = random.randint(5, 15)

            # Gerar posição aleatória
            x = random.randint(0, Settings.WIDTH)
            y = random.randint(0, Settings.HEIGHT)

            # Criar e adicionar zombie
            zombie = Zombie(x, y, health, damage, speed, exp_reward, money_reward)
            self.enemies.add(zombie)
            self.zombies_generated += 1  # Incrementar o contador de zombies gerados

    def spawn_boss(self):
        """
        Gera o Boss no centro da tela.

        O Boss é gerado apenas uma vez e é adicionado ao grupo de inimigos.
        """
        if not self.boss_spawned:
            health = 500
            damage = 30
            speed = 1
            exp_reward = 300
            money_reward = random.randint(30, 60)
            boss = Boss(Settings.WIDTH // 2, Settings.HEIGHT // 2, health, damage, speed, exp_reward, money_reward)
            self.enemies.add(boss)
            self.boss_spawned = True

    def check_all_enemies_defeated(self):
        """
        Verifica se todos os inimigos (zombies e bosses) foram derrotados e faz a transição de estado.

        Retorna True se não houverem inimigos restantes.
        """
        if all(not enemy.alive() for enemy in self.enemies):  # Verifica se nenhum inimigo está vivo
            self.next_state = "shed"  # Nome do próximo estado
            return True
        return False

    def check_boss_defeated(self):
        """
        Verifica se o Boss foi derrotado e gera um baú com chance.

        Se o Boss for derrotado e a chance for atingida, um baú será gerado.
        """
        if self.boss_spawned and self.check_all_enemies_defeated():
            if random.random() <= 1 and len(self.chests) == 0:
                # Verifica se ainda há power-ups disponíveis para melhorar
                available_options = [opt for opt in self.all_options if opt not in self.used_powerups]

                if available_options:
                    print(f"Opções disponíveis para baú: {available_options}")  # Depuração
                    chest = Chest(x:=random.randint(0, Settings.WIDTH), y:=random.randint(0, Settings.HEIGHT),
                                  player=self.player, available_options=available_options)
                    self.chests.add(chest)  # Adiciona o baú ao grupo de baús
                    self.active_chest = True
                    print(f"Baús ativos: {len(self.chests)}")
                    print("Baú gerado!")  # Depuração
                else:
                    self.active_chest = False  # Não gera o baú se não houver mais opções
                return True
        return False

    def mark_powerup_as_used(self, powerup_type):
        """
        Marca o power-up como usado.

        Adiciona o tipo de power-up à lista de power-ups usados.

        Parâmetros:
        powerup_type (str): O tipo de power-up a ser marcado como usado.
        """
        if powerup_type not in self.used_powerups:
            self.used_powerups.append(powerup_type)
            print(f"Power-up {powerup_type} adicionado à lista de usados.")

    def check_player_chest_collision(self):
        """
        Abre automaticamente o baú quando o jogador passa por cima.

        Para cada baú na lista de baús, verifica se o jogador está em colisão com o baú
        e se o baú ainda não foi aberto. Se ambos os critérios forem verdadeiros,
        o baú é aberto automaticamente.

        Parâmetros
        ----------
        None
        """
        for chest in self.chests:
            if chest.rect.colliderect(self.player.rect) and not chest.opened:
                chest.open()

    def shoot(self, player, mouse_pos):
        """
        Gerencia o disparo de balas do jogador.

        Este método é responsável por calcular o ângulo de disparo baseado na posição do
        mouse e no centro do jogador. Ele verifica o padrão de disparo da arma e gera
        balas de acordo.

        Parâmetros
        ----------
        player : Player
            O jogador que está realizando o disparo.
        mouse_pos : tuple
            A posição do mouse na tela, usada para calcular a direção do disparo.

        Retorna
        -------
        None
        """
        if player.weapon_cooldown <= 0:
            angle = math.atan2(mouse_pos[1] - player.rect.centery, mouse_pos[0] - player.rect.centerx)
            weapon = player.get_current_weapon()
            bullet_pattern = weapon["pattern"]
            if bullet_pattern == "single":
                self.add_bullet(player, angle, weapon)
            elif bullet_pattern == "spread":
                for offset in [-weapon.get("spread", 15), 0, weapon.get("spread", 15)]:
                    self.add_bullet(player, angle + math.radians(offset), weapon)
            player.weapon_cooldown = weapon["cooldown"]

    def handle_mouse_click(self, event, player):
        """
        Verifica o clique do mouse e executa ações dependendo da arma selecionada.

        Quando o jogador clica com o botão esquerdo do mouse, o método verifica se a
        arma está desbloqueada e executa a ação correspondente. Se a arma tiver um efeito
        especial (como o "Cajado"), o efeito será ativado, caso contrário, o disparo da arma
        será realizado.

        Parâmetros
        ----------
        event : pygame.event
            O evento do mouse que contém informações sobre o clique.
        player : Player
            O jogador que está realizando a ação.

        Retorna
        -------
        None
        """
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            current_weapon = player.get_current_weapon()

            if player.is_weapon_unlocked(current_weapon["name"]):
                if current_weapon.get("special", False):
                    if current_weapon["name"] == "Cajado":
                        self.use_staff(player)
                else:
                    self.shoot(player, pygame.mouse.get_pos())
            else:
                print(f"A arma {current_weapon['name']} está bloqueada e não pode ser utilizada.")

    def use_staff(self, player):
        """
        Usa o cajado para derrotar todos os inimigos no mapa.

        Este método aplica dano massivo a todos os inimigos, derrotando-os instantaneamente.

        Parâmetros
        ----------
        player : Player
            O jogador que está utilizando o cajado.

        Retorna
        -------
        None
        """
        for enemy in self.enemies:
            enemy.take_damage(9999, player)

    def add_bullet(self, player, angle, weapon):
        """
        Cria uma bala e a adiciona ao grupo de balas.

        Calcula o dano da bala com base no multiplicador de dano do jogador e cria uma instância
        da classe `Bullet`, que é adicionada ao grupo de balas.

        Parâmetros
        ----------
        player : Player
            O jogador que está disparando a bala.
        angle : float
            O ângulo de disparo calculado.
        weapon : dict
            O dicionário contendo informações sobre a arma (como dano, velocidade, etc.).

        Retorna
        -------
        None
        """
        damage_with_multiplier = weapon["damage"] * player.damage_multiplier
        bullet = Bullet(player.rect.centerx, player.rect.centery, angle, damage_with_multiplier, weapon["speed"],
                        player)
        self.bullets.add(bullet)

    def run(self):
        """
        Método principal do estado atual do jogo, onde verificamos as condições de transição.

        Esse método gerencia o loop principal do jogo, tratando os eventos (como cliques e pressionamento de teclas),
        verificando condições de vitória e derrota, gerando inimigos e power-ups, e atualizando a tela.

        Parâmetros
        ----------
        None

        Retorna
        -------
        str
            O próximo estado do jogo (por exemplo, "shed").
        """
        clock = pygame.time.Clock()
        background = pygame.image.load("images/main.png")
        background = pygame.transform.scale(background, Settings.RESOLUTION)

        player = self.player
        player_group = pygame.sprite.Group(player)

        running = True
        while running:
            clock.tick(Settings.FPS)
            self.screen.blit(background, (0, 0))

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    exit()

                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    self.shoot(player, pygame.mouse.get_pos())
                    self.handle_mouse_click(event, player)

                if event.type == pygame.KEYDOWN:
                    if event.key in (pygame.K_1, pygame.K_2, pygame.K_3, pygame.K_4):
                        player.select_weapon(event.key - pygame.K_1)

                    if event.key == pygame.K_9:
                        self.save_game()

                    if event.key == pygame.K_8:
                        player.reset_player_to_default()

                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    for chest in self.chests:
                        chosen_powerup = chest.check_click(event.pos)
                        if chosen_powerup:
                            chest.improve_powerup(chosen_powerup, self)
                            self.chests.remove(chest)

            self.check_boss_defeated()
            self.handle_collisions()
            self.bullets.update()
            self.spawn_enemy()
            self.check_player_powerup_collision()
            self.check_player_chest_collision()
            self.powerups.update()
            self.chests.update()
            player_group.update()
            for sprite in player_group:
                sprite.render(self.screen)

            self.chests.draw(self.screen)
            for chest in self.chests:
                if chest.opened:
                    chest.display_options(self.screen)

            if len([enemy for enemy in self.enemies if isinstance(enemy, Zombie)]) == 0:
                if self.zombies_generated >= self.enemy_limit and not self.boss_spawned:
                    self.spawn_boss()

            if random.random() < 0.1 and self.active_powerup is None:
                self.spawn_powerup()

            for enemy in self.enemies:
                enemy.update(player, self.bullets, self.enemies)

            draw_health_bar(self.screen, 70, 20, player.health, player.max_health)
            draw_exp_bar(self.screen, self.player, x=70, y=41)
            draw_money(self.screen, player)

            player_group.draw(self.screen)
            self.enemies.draw(self.screen)
            self.bullets.draw(self.screen)
            self.powerups.draw(self.screen)

            pygame.display.flip()

            if player.weapon_cooldown > 0:
                player.weapon_cooldown -= 1

            if self.check_all_enemies_defeated() and player.rect.right >= Settings.WIDTH and Settings.MIDDLE_TOP <= player.rect.centery <= Settings.MIDDLE_BOTTOM:
                print("Jogador derrotou o Boss e saiu para o próximo estado.")
                self.save_game()
                self.game.set_player_entry_position((4, player.rect.y))
                self.next_state = "shed"
                running = False

        return self.next_state


