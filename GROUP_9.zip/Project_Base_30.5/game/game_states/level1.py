# upper_state.py

from game.game_states.mainstate import MainGameState
from utils import Settings, draw_health_bar, draw_exp_bar, draw_money
from powerups import *
from enemy import Zombie

# Inicialização da tela e da instância de Utils
screen = pygame.display.set_mode(Settings.RESOLUTION)
pygame.display.set_caption("Game State")

class Level1(MainGameState):
    """
    Classe que representa o estado de nível 1 do jogo, herda de MainGameState.

    Esta classe lida com a inicialização do nível 1, a gestão dos eventos do jogo, a atualização de sprites,
    a geração de inimigos, a verificação de colisões e a transição para o próximo nível ou estado do jogo.

    Attributes
    ----------
    game : Game
        A instância do jogo que contém informações e estados globais.
    player : Player
        O jogador controlado no jogo.
    spawn_rate : float
        A taxa de spawn dos inimigos no nível.
    enemy_limit : int
        O número máximo de inimigos no nível.
    powerup_chances : None or list
        Probabilidade dos power-ups aparecerem no jogo.
    powerup_spawn_probability : float
        A probabilidade de spawn de um power-up durante o jogo.
    """

    def __init__(self, game):
        """
        Inicializa o estado do nível 1.

        Parameters
        ----------
        game : Game
            A instância do jogo que contém informações e estados globais.
        """
        super().__init__(game, spawn_rate=0.5, enemy_limit=1, powerup_chances=None, powerup_spawn_probability=1)
        self.show_message = False

    def run(self):
        """
        Executa o loop principal do nível 1.

        Este método é responsável por:
        - Atualizar o estado do jogo.
        - Gerenciar eventos como cliques e pressionamento de teclas.
        - Controlar o comportamento de sprites, inimigos e power-ups.
        - Transitar para o próximo estado do jogo ou encerrar o jogo.

        Returns
        -------
        next_state : str
            O próximo estado para o qual o jogo deve transitar.
        """
        clock = pygame.time.Clock()
        background = pygame.image.load("images/mapa_final.png")
        background = pygame.transform.scale(background, Settings.RESOLUTION)

        player = self.player
        player_group = pygame.sprite.Group(player)

        # Posiciona o jogador na entrada definida, se existir
        entry_position = self.game.get_player_entry_position()
        if entry_position:
            entry_x, entry_y = entry_position
            player.rect.topleft = (entry_x, entry_y)

        running = True
        while running:
            clock.tick(Settings.FPS)
            self.screen.blit(background, (0, 0))

            rect_width = 200
            rect_height = 100
            rect_x = (Settings.WIDTH - rect_width) // 2
            rect_y = 70
            story = pygame.Rect(rect_x, rect_y, rect_width, rect_height)  # Área lógica do retângulo

            # Inicializar a fonte para exibir a mensagem
            font = pygame.font.Font(None, 36)  # Fonte padrão, tamanho 36
            message = "Colisão detectada!"  # Mensagem a exibir

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    exit()

                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    self.shoot(player, pygame.mouse.get_pos())

                if event.type == pygame.KEYDOWN:
                    if event.key in (pygame.K_1, pygame.K_2, pygame.K_3, pygame.K_4):
                        player.select_weapon(event.key - pygame.K_1)

                    if event.key == pygame.K_9:  # Salva o jogo
                        self.save_game()

                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    for chest in self.chests:
                        chosen_powerup = chest.check_click(event.pos)
                        if chosen_powerup:
                            chest.improve_powerup(chosen_powerup)
                            self.chests.remove(chest)  # Remove o baú após escolher

            self.handle_collisions()
            self.bullets.update()
            self.spawn_enemy()
            self.check_player_powerup_collision()
            self.check_player_chest_collision()  # Abre baús automaticamente
            self.powerups.update()
            self.chests.update()  # Atualiza os baús
            player_group.update()  # Atualiza os estados dos sprites
            for sprite in player_group:
                sprite.render(screen)  # Desenha os sprites

            self.chests.draw(self.screen)
            for chest in self.chests:
                if chest.opened:
                    chest.display_options(self.screen)

            # Gerar o boss somente se todos os zombies foram derrotados
            if len([enemy for enemy in self.enemies if isinstance(enemy, Zombie)]) == 0:
                if self.zombies_generated >= self.enemy_limit and not self.boss_spawned:
                    self.spawn_boss()

            # Gerar power-ups com base nas probabilidades
            if random.random() < 0.1 and self.active_powerup is None:  # Garante que apenas um power-up será gerado de cada vez
                self.spawn_powerup()

            for enemy in self.enemies:
                enemy.update(player, self.bullets, self.enemies)

            draw_health_bar(self.screen, 70, 20, player.health, player.max_health)
            draw_exp_bar(self.screen, self.player, x=70, y=41)
            draw_money(self.screen, player)

            player_group.draw(self.screen)
            self.enemies.draw(self.screen)
            self.bullets.draw(self.screen)
            self.powerups.draw(self.screen)  # Desenha os power-ups

            pygame.display.flip()

            if player.weapon_cooldown > 0:
                player.weapon_cooldown -= 1

            if self.check_all_enemies_defeated():
                if player.rect.colliderect(story):
                    pygame.quit()
                    exit()

            # Desenhar o contorno do retângulo
            pygame.draw.rect(self.screen, (0, 0, 255), story, width=1)

            if self.check_all_enemies_defeated():
                if (player.rect.bottom >= Settings.HEIGHT and
                        Settings.MIDDLE_TOP <= player.rect.centerx <= Settings.MIDDLE_BOTTOM):
                    print("Jogador desceu para o estado 'shed'")
                    self.save_game()  # Salva o progresso automaticamente
                    self.game.set_player_entry_position((player.rect.x, 4))  # Ajustar entrada
                    self.next_state = "shed"
                    running = False

        return self.next_state


