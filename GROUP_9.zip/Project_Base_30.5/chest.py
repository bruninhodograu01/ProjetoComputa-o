import pygame
import random
from powerups import *
from utils import Settings


class Chest(pygame.sprite.Sprite):
    """
    Classe que representa um baú no jogo, contendo opções de power-ups que o jogador pode escolher.

    O baú pode ser aberto para revelar até três opções de power-ups disponíveis, e as opções são removidas
    após a escolha. Cada baú pode conter diferentes opções de power-ups e garantir que as opções não se repitam
    durante a interação.

    Attributes
    ----------
    x : int
        A coordenada x da posição do baú na tela.
    y : int
        A coordenada y da posição do baú na tela.
    image : pygame.Surface
        A superfície que representa a imagem do baú.
    rect : pygame.Rect
        O retângulo que define a posição e o tamanho do baú na tela.
    player : object
        O jogador que interage com o baú.
    opened : bool
        Indica se o baú foi aberto.
    options : list
        Lista de opções de power-ups disponíveis no baú.
    used_options : set
        Conjunto de opções já escolhidas pelo jogador.
    available_options : list
        Lista das opções de power-ups disponíveis para o baú.
    option_rects : list
        Lista de retângulos representando as áreas clicáveis para cada opção.
    """

    def __init__(self, x, y, player, available_options):
        """
        Inicializa o baú com posição, jogador e opções disponíveis.

        Parameters
        ----------
        x : int
            A coordenada x da posição do baú.
        y : int
            A coordenada y da posição do baú.
        player : object
            O jogador que interage com o baú.
        available_options : list
            Lista de opções de power-ups disponíveis para o baú.
        """
        super().__init__()

        self.x = x
        self.y = y
        self.image = pygame.image.load("images/bau(1).png")
        self.image = pygame.transform.scale(self.image, (50, 50))
        self.rect = self.image.get_rect(topleft=(self.x, self.y))
        self.player = player
        self.opened = False
        self.options = []
        self.used_options = set()  # Opcões já usadas nesta interação
        self.available_options = available_options  # Opções ainda disponíveis no jogo

        self.update_options()  # Atualiza as opções do baú

        self.option_rects = [
            pygame.Rect(Settings.WIDTH // 2 - 100, Settings.HEIGHT // 2 - 60, 200, 40),
            pygame.Rect(Settings.WIDTH // 2 - 100, Settings.HEIGHT // 2, 200, 40),
            pygame.Rect(Settings.WIDTH // 2 - 100, Settings.HEIGHT // 2 + 60, 200, 40),
        ]

    def update_options(self):
        """
        Atualiza as opções disponíveis no baú, retirando as opções já usadas.

        Se não houver mais opções disponíveis, o baú não alterará sua imagem nem gerará novas opções.
        Caso contrário, escolhe aleatoriamente até três opções das disponíveis.
        """
        available_options = [opt for opt in self.available_options if opt not in self.used_options]

        if not available_options:
            # Se não houver mais opções, não altere a imagem nem selecione opções
            return

        # Seleciona até 3 opções aleatórias das disponíveis
        self.options = random.sample(available_options, k=min(3, len(available_options)))

    def open(self):
        """
        Abre o baú e gera novas opções de power-ups.

        O baú só será aberto uma vez, e ao ser aberto, ele atualiza suas opções de power-ups disponíveis.
        """
        if not self.opened:
            self.opened = True
            self.update_options()

    def display_options(self, screen):
        """
        Renderiza as opções de power-ups disponíveis para o jogador.

        Se o baú estiver aberto, desenha os retângulos clicáveis e as opções de power-ups para o jogador escolher.

        Parameters
        ----------
        screen : pygame.Surface
            A superfície onde as opções serão desenhadas.
        """
        if self.opened:
            font = pygame.font.Font(None, 36)
            for i, option in enumerate(self.options):
                text = font.render(option, True, (255, 255, 255))
                pygame.draw.rect(screen, (0, 0, 0), self.option_rects[i])  # Fundo do bloco
                pygame.draw.rect(screen, (255, 255, 255), self.option_rects[i], 2)  # Borda
                screen.blit(text, (self.option_rects[i].x + 10, self.option_rects[i].y + 5))

    def check_click(self, pos):
        """
        Verifica se o jogador clicou em uma das opções do baú.

        Se o jogador clicar em uma das opções disponíveis, essa opção é retornada.

        Parameters
        ----------
        pos : tuple
            A posição do clique na tela.

        Returns
        -------
        str or None
            O tipo de power-up selecionado, ou None se o clique não for em uma opção válida.
        """
        if self.opened:
            for i, rect in enumerate(self.option_rects):
                if rect.collidepoint(pos):
                    return self.options[i]
        return None

    def improve_powerup(self, powerup_type, game_state):
        """
        Melhora o power-up escolhido pelo jogador e atualiza o estado do jogo.

        O método melhora o power-up selecionado, com base no tipo de power-up e no jogador,
        e marca esse power-up como usado.

        Parameters
        ----------
        powerup_type : str
            O tipo de power-up escolhido pelo jogador.
        game_state : object
            O estado atual do jogo onde o power-up será registrado.
        """
        # Melhorando o power-up com base no tipo
        if powerup_type == 'DamageBoostPU':
            powerup = DamageBoostPU(self.x, self.y)
            DamageBoostPU.improve(self.player)
        elif powerup_type == 'HealthRegenPU':
            powerup = HealthRegenPU(self.x, self.y)
            HealthRegenPU.improve(self.player)
            print(f"[DEBUG] HealthRegenPU após melhoria: quantificator = {powerup.quantificator}")  # Verificar o aumento
        elif powerup_type == 'RegenBoostPU':
            powerup = RegenBoostPU(self.x, self.y)
            RegenBoostPU.improve(self.player)
        elif powerup_type == 'InvincibilityPU':
            powerup = InvincibilityPU(self.x, self.y)
            InvincibilityPU.improve(self.player)
        elif powerup_type == 'DespawnerPU':
            powerup = DespawnerPU(self.x, self.y)
            DespawnerPU.improve(self.player)

        # Marcar o power-up como usado no MainGameState
        game_state.mark_powerup_as_used(powerup_type)

        # Atualiza as opções no baú
        self.used_options.add(powerup_type)
        self.update_options()
