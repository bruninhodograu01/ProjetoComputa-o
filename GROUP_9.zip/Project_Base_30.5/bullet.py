import pygame
import math


class Bullet(pygame.sprite.Sprite):
    """
    Classe que representa uma bala disparada no jogo.

    A classe é responsável por criar uma bala que pode ser movida pela tela de acordo com a direção e velocidade fornecidas.
    Ela também lida com a remoção da bala quando sai da tela.

    Attributes
    ----------
    direction : float
        A direção do disparo da bala, em radianos.
    speed : float
        A velocidade da bala, que determina o quão rápido ela se move.
    damage : int
        O dano que a bala causa ao atingir o alvo.
    radius : int
        O raio da bala, usado para determinar seu tamanho.
    color : tuple
        A cor da bala, definida usando valores RGB.
    origin : object
        A origem da bala, ou seja, quem disparou a bala (jogador, inimigo, etc.).
    image : pygame.Surface
        A superfície que representa a imagem da bala.
    rect : pygame.Rect
        O retângulo que define a posição e o tamanho da bala na tela.
    """

    def __init__(self, x, y, direction, damage, speed, origin):
        """
        Inicializa a bala com posição, direção, dano, velocidade e origem.

        Parameters
        ----------
        x : int
            A coordenada x da posição inicial da bala.
        y : int
            A coordenada y da posição inicial da bala.
        direction : float
            A direção em radianos para onde a bala será disparada.
        damage : int
            O dano que a bala causará ao atingir um alvo.
        speed : float
            A velocidade com que a bala se moverá.
        origin : object
            A origem da bala, como o jogador ou inimigo que disparou.
        """
        super().__init__()
        from utils import Colors
        self.direction = direction
        self.speed = speed  # Velocidade configurável
        self.damage = damage  # Dano configurável
        self.radius = 5
        self.color = Colors.WHITE
        self.origin = origin  # Identifica quem disparou (jogador, inimigo, etc.)

        # Cria uma superfície para a bala
        self.image = pygame.Surface((self.radius * 2, self.radius * 2), pygame.SRCALPHA)
        pygame.draw.circle(self.image, self.color, (self.radius, self.radius), self.radius)

        # Define o rect da bala
        self.rect = self.image.get_rect(center=(x, y))

    def update(self):
        """
        Atualiza a posição da bala e verifica se ela saiu da tela.

        A bala é movida com base na sua direção e velocidade. Se a bala sair da tela, ela é removida.
        """
        from utils import Settings
        # Move a bala de acordo com sua direção e velocidade
        self.rect.x += int(self.speed * math.cos(self.direction))
        self.rect.y += int(self.speed * math.sin(self.direction))

        # Remove a bala se sair da tela
        if (self.rect.x < 0 or self.rect.x > Settings.WIDTH or
            self.rect.y < 0 or self.rect.y > Settings.HEIGHT):
            self.kill()




