import pygame
from utils import *

class Underc:
    """
    Classe responsável pela interface de compra de armas no jogo.

    A classe permite ao jogador comprar armas, visualizar mensagens sobre o estado da compra e navegar pela interface.

    Attributes
    ----------
    screen : pygame.Surface
        A superfície onde a interface será desenhada.
    resolution : tuple
        A resolução da tela do jogo.
    deep_black : tuple
        A cor de fundo da interface, usada para preencher a tela.
    white : tuple
        A cor branca, usada para texto.
    dark_red : tuple
        A cor vermelha escura, usada para o botão de "Back".
    player : object
        O jogador que interage com a interface.
    weapon_prices : dict
        Um dicionário com os preços das armas disponíveis para compra.
    """

    def __init__(self, screen, player):
        """
        Inicializa a interface de compra de armas.

        Parameters
        ----------
        screen : pygame.Surface
            A superfície onde a interface será desenhada.
        player : object
            O jogador que interage com a interface.
        """
        self.screen = screen
        self.resolution = Settings.RESOLUTION
        self.deep_black = Colors.DEEP_BLACK
        self.white = Colors.WHITE
        self.dark_red = Colors.DARK_RED
        self.player = player

        # Preços das armas
        self.weapon_prices = {
            "Espingarda": 100,
            "Rifle": 150,
            "Cajado": 200
        }

    def draw_button(self, text, position, size=(200, 60), font_size=30, color=(0, 128, 255), text_color=(255, 255, 255)):
        """
        Desenha um botão na interface com o texto fornecido.

        Parameters
        ----------
        text : str
            O texto que será exibido no botão.
        position : tuple
            A posição (x, y) do botão na tela.
        size : tuple, optional
            O tamanho (largura, altura) do botão (default é (200, 60)).
        font_size : int, optional
            O tamanho da fonte para o texto do botão (default é 30).
        color : tuple, optional
            A cor de fundo do botão (default é (0, 128, 255)).
        text_color : tuple, optional
            A cor do texto do botão (default é (255, 255, 255)).

        Returns
        -------
        pygame.Rect
            O retângulo que define a área do botão.
        """
        x, y = position
        button_rect = pygame.Rect(x, y, size[0], size[1])
        pygame.draw.rect(self.screen, color, button_rect)
        font = pygame.font.SysFont('Arial', font_size)
        text_surface = font.render(text, True, text_color)
        text_rect = text_surface.get_rect(center=button_rect.center)
        self.screen.blit(text_surface, text_rect)
        return button_rect

    def display_message(self, message, position=(400, 300), font_size=50, color=(255, 255, 255)):
        """
        Exibe uma mensagem na tela.

        Parameters
        ----------
        message : str
            A mensagem a ser exibida.
        position : tuple, optional
            A posição (x, y) onde a mensagem será exibida (default é (400, 300)).
        font_size : int, optional
            O tamanho da fonte para a mensagem (default é 50).
        color : tuple, optional
            A cor do texto da mensagem (default é (255, 255, 255)).
        """
        font = pygame.font.SysFont('Arial', font_size)
        text = font.render(message, True, color)
        text_rect = text.get_rect(center=position)
        self.screen.blit(text, text_rect)

    def handle_interface_events(self, buttons):
        """
        Processa os eventos da interface, como cliques nos botões.

        Parameters
        ----------
        buttons : dict
            Um dicionário onde as chaves são os textos dos botões e os valores são os retângulos que definem as áreas dos botões.

        Returns
        -------
        str or None
            O texto do botão clicado, ou None se nenhum botão for clicado.
        """
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            for button_text, button_rect in buttons.items():
                if self.is_button_clicked(button_rect, event):
                    return button_text
        return None

    @staticmethod
    def is_button_clicked(button_rect, event):
        """
        Verifica se um botão foi clicado.

        Parameters
        ----------
        button_rect : pygame.Rect
            O retângulo que define a área do botão.
        event : pygame.event
            O evento que será verificado.

        Returns
        -------
        bool
            True se o botão foi clicado, False caso contrário.
        """
        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse_x, mouse_y = event.pos
            if button_rect.collidepoint(mouse_x, mouse_y):
                return True
        return False

    def under_construction(self, player):
        """
        Exibe a interface de compra de armas e lida com a interação do jogador.

        A interface permite ao jogador comprar armas, com base no dinheiro disponível, e exibe mensagens
        sobre o sucesso ou falha na compra.

        Parameters
        ----------
        player : object
            O jogador que interage com a interface.
        """
        running = True
        while running:
            self.screen.fill(self.deep_black)

            espingarda_text = "Espingarda"
            rifle_text = "Rifle"
            cajado_text = "Cajado"

            espingarda_button_rect = self.draw_button(
                f"{espingarda_text} ({self.weapon_prices['Espingarda']})" if not player.is_weapon_unlocked(
                    espingarda_text) else espingarda_text,
                (300, 250)
            )
            rifle_button_rect = self.draw_button(
                f"{rifle_text} ({self.weapon_prices['Rifle']})" if not player.is_weapon_unlocked(
                    rifle_text) else rifle_text,
                (300, 350)
            )
            cajado_button_rect = self.draw_button(
                f"{cajado_text} ({self.weapon_prices['Cajado']})" if not player.is_weapon_unlocked(
                    cajado_text) else cajado_text,
                (300, 450)
            )

            back_rect = self.draw_button("Back", (450, 600), size=(140, 60), color=self.dark_red)

            action = self.handle_interface_events({
                "Espingarda": espingarda_button_rect,
                "Rifle": rifle_button_rect,
                "Cajado": cajado_button_rect,
                "Back": back_rect
            })

            if action == "Espingarda" and not player.is_weapon_unlocked("Espingarda"):
                if player.money >= self.weapon_prices["Espingarda"]:
                    player.money -= self.weapon_prices["Espingarda"]
                    player.unlock_weapon("Espingarda")
                    self.display_message("Espingarda comprada!", (self.resolution[0] // 2, 550))
                else:
                    self.display_message("Dinheiro insuficiente!", (self.resolution[0] // 2, 550))
            elif action == "Rifle" and not player.is_weapon_unlocked("Rifle"):
                if player.money >= self.weapon_prices["Rifle"]:
                    player.money -= self.weapon_prices["Rifle"]
                    player.unlock_weapon("Rifle")
                    self.display_message("Rifle comprada!", (self.resolution[0] // 2, 550))
                else:
                    self.display_message("Dinheiro insuficiente!", (self.resolution[0] // 2, 550))
            elif action == "Cajado" and not player.is_weapon_unlocked("Cajado"):
                if player.money >= self.weapon_prices["Cajado"]:
                    player.money -= self.weapon_prices["Cajado"]
                    player.unlock_weapon("Cajado")
                    self.display_message("Cajado comprado!", (self.resolution[0] // 2, 550))
                else:
                    self.display_message("Dinheiro insuficiente!", (self.resolution[0] // 2, 550))
            elif action == "Back":
                running = False

            player.render_money(self.screen)
            pygame.display.update()







