import pygame
import math
from bullet import Bullet  # Certifique-se de que a classe Bullet seja importada corretamente

class Enemy(pygame.sprite.Sprite):
    def __init__(self, x, y, health, damage, speed, exp_reward, money_reward):
        """
        Inicializa um novo inimigo.

        Parâmetros:
        -----------
        x : int
            A posição x inicial do inimigo.
        y : int
            A posição y inicial do inimigo.
        health : int
            A quantidade de saúde do inimigo.
        damage : int
            O dano que o inimigo causa ao jogador.
        speed : int
            A velocidade de movimento do inimigo.
        exp_reward : int
            A quantidade de experiência dada ao jogador ao derrotar o inimigo.
        money_reward : int
            A quantidade de dinheiro dada ao jogador ao derrotar o inimigo.
        """
        super().__init__()
        self.image = pygame.image.load("images/zombie1.png").convert_alpha()  # Carrega a imagem do inimigo
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)

        # Atributos fixos definidos pelo jogador
        self.health = health
        self.damage = damage
        self.speed = speed
        self.exp_reward = exp_reward
        self.money_reward = money_reward
        self.damage_cooldown = 100
        self.damage_timer = 0

    def update(self, player, bullet_group, enemies):
        """
        Método que será sobrescrito nas subclasses.

        Este método deve ser implementado nas subclasses para definir o comportamento de atualização do inimigo.

        Parâmetros:
        -----------
        player : Player
            O jogador que está sendo perseguido pelo inimigo.
        bullet_group : pygame.sprite.Group
            O grupo de balas do jogo.
        enemies : list
            A lista de inimigos que podem interagir com o inimigo atual.
        """
        pass

    def apply_damage(self, player):
        """
        Aplica dano ao jogador quando o inimigo colide com ele.

        Este método verifica se o jogador não está invencível e aplica o dano do inimigo, reduzindo a saúde do jogador.

        Parâmetros:
        -----------
        player : Player
            O jogador que será atingido pelo dano do inimigo.
        """
        if not player.is_invincible:  # Verifica se o jogador não está invencível
            player.health -= self.damage
            player.health = max(player.health, 0)  # Garante que a saúde não fique negativa
            self.damage_timer = self.damage_cooldown

    def take_damage(self, amount, player):
        """
        Aplica dano ao inimigo.

        Este método reduz a saúde do inimigo de acordo com a quantidade de dano recebida. Quando a saúde do inimigo
        atinge zero ou menos, ele é removido do jogo e o jogador recebe as recompensas de EXP e dinheiro.

        Parâmetros:
        -----------
        amount : int
            A quantidade de dano a ser aplicada ao inimigo.
        player : Player
            O jogador que receberá as recompensas ao derrotar o inimigo.
        """
        self.health -= amount
        if self.health <= 0:
            if self.alive():  # Verifica se o inimigo ainda não foi 'morto' oficialmente
                self.kill()
                if player:  # Garante que o jogador receba as recompensas uma única vez
                    player.gain_money(self.money_reward)
                    player.gain_exp(self.exp_reward)
                    print(f"Recompensa: {self.exp_reward} EXP, {self.money_reward} dinheiro!")  # Debug


class Boss(Enemy):
    def __init__(self, x, y, health, damage, speed, exp_reward, money_reward):
        """
        Inicializa um novo Boss.

        Parâmetros:
        -----------
        x : int
            A posição x inicial do boss.
        y : int
            A posição y inicial do boss.
        health : int
            A quantidade de saúde do boss.
        damage : int
            O dano que o boss causa ao jogador.
        speed : int
            A velocidade de movimento do boss.
        exp_reward : int
            A quantidade de experiência dada ao jogador ao derrotar o boss.
        money_reward : int
            A quantidade de dinheiro dada ao jogador ao derrotar o boss.
        """
        super().__init__(x, y, health, damage, speed, exp_reward, money_reward)
        self.hitbox = pygame.Rect(self.rect.x, self.rect.y, 50, 50)  # Define a hitbox inicial
        self.image = pygame.image.load("images/boss2.png").convert_alpha()  # Carrega a imagem do inimigo

    def update(self, player, bullet_group, enemies):
        """
        Atualiza o estado do Boss, incluindo disparos e movimento.

        Este método atualiza a posição do boss em direção ao jogador e verifica colisões com balas e com o jogador.
        O boss também pode causar dano ao jogador se ele colidir com ele.

        Parâmetros:
        -----------
        player : Player
            O jogador que está sendo perseguido pelo boss.
        bullet_group : pygame.sprite.Group
            O grupo de balas do jogo.
        enemies : list
            A lista de inimigos no jogo.
        """
        # Movimento básico em direção ao jogador
        dx = player.rect.x - self.rect.x
        dy = player.rect.y - self.rect.y
        angle = math.atan2(dy, dx)
        self.rect.x += self.speed * math.cos(angle)
        self.rect.y += self.speed * math.sin(angle)

        # Atualiza a hitbox para seguir o boss
        self.hitbox.topleft = self.rect.topleft  # Move a hitbox com o boss

        # Verifica colisões com balas
        for bullet in bullet_group:
            if bullet.rect.colliderect(self.hitbox) and bullet.origin != self:
                self.take_damage(bullet.damage, player)

        # Colisão com o jogador para dano
        if self.damage_timer == 0 and self.rect.colliderect(player.rect):
            self.apply_damage(player)

        if self.damage_timer > 0:
            self.damage_timer -= 1


class Zombie(Enemy):
    def __init__(self, x, y, health, damage, speed, exp_reward, money_reward):
        """
        Inicializa um novo Zombie.

        Parâmetros:
        -----------
        x : int
            A posição x inicial do zombie.
        y : int
            A posição y inicial do zombie.
        health : int
            A quantidade de saúde do zombie.
        damage : int
            O dano que o zombie causa ao jogador.
        speed : int
            A velocidade de movimento do zombie.
        exp_reward : int
            A quantidade de experiência dada ao jogador ao derrotar o zombie.
        money_reward : int
            A quantidade de dinheiro dada ao jogador ao derrotar o zombie.
        """
        super().__init__(x, y, health, damage, speed, exp_reward, money_reward)  # A imagem foi adicionada aqui

    def update(self, player, bullet_group, enemies):
        """
        Faz o inimigo perseguir o jogador e causar dano se colidir com ele.

        Este método faz com que o zombie se mova em direção ao jogador e aplique dano se colidir com ele. O zombie
        também verifica colisões com outros inimigos para evitar sobreposição e com balas.

        Parâmetros:
        -----------
        player : Player
            O jogador que está sendo perseguido pelo zombie.
        bullet_group : pygame.sprite.Group
            O grupo de balas do jogo.
        enemies : list
            A lista de inimigos no jogo.
        """
        dx = player.rect.x - self.rect.x
        dy = player.rect.y - self.rect.y
        direction = math.atan2(dy, dx)

        # Movimento do inimigo
        self.rect.x += self.speed * math.cos(direction)
        self.rect.y += self.speed * math.sin(direction)

        # Verifica colisão com o jogador para dano
        if self.damage_timer == 0 and self.rect.colliderect(player.rect):
            self.apply_damage(player)

        if self.damage_timer > 0:
            self.damage_timer -= 1

        # Colisão com outros inimigos para evitar sobreposição
        for enemy in enemies:
            if enemy != self and self.rect.colliderect(enemy.rect):
                overlap_dx = self.rect.centerx - enemy.rect.centerx
                overlap_dy = self.rect.centery - enemy.rect.centery
                distance = max(1, int(math.sqrt(overlap_dx ** 2 + overlap_dy ** 2)))
                self.rect.x += overlap_dx / distance
                self.rect.y += overlap_dy / distance

        # Colisão com balas
        for bullet in bullet_group:
            if bullet.rect.colliderect(self.rect) and bullet.origin != self:
                self.take_damage(bullet.damage, player)




















