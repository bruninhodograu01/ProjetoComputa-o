import pygame
from abc import ABC, abstractmethod
import random


class PowerUp(pygame.sprite.Sprite, ABC):
    """
    Classe base para todos os Power-ups no jogo.

    Atributos:
        x (int): A posição x do Power-up na tela.
        y (int): A posição y do Power-up na tela.
        duration (int): A duração do efeito do Power-up em quadros.
        improved (bool): Indicador de se o Power-up foi melhorado.
        image (pygame.Surface): A imagem associada ao Power-up.
        rect (pygame.Rect): O retângulo da colisão do Power-up.
        player (Player): Referência ao jogador que pode pegar o Power-up.
        powerup_type (str): Tipo do Power-up.
        is_active (bool): Indicador se o Power-up está ativo.
    """

    def __init__(self, x, y, duration=300):
        """
        Inicializa um Power-up.

        Parâmetros:
            x (int): A posição x do Power-up.
            y (int): A posição y do Power-up.
            duration (int, opcional): Duração do efeito do Power-up (padrão é 300).
        """
        super().__init__()
        from player import Player
        self.x = x
        self.y = y
        self.duration = duration
        self.improved = False
        self.image = None
        self.rect = None
        self.player = Player
        self.powerup_type = None
        self.is_active = False

    @abstractmethod
    def affect_player(self, player):
        """
        Aplica o efeito do Power-up no jogador.

        Parâmetros:
            player (Player): O jogador afetado pelo Power-up.
        """
        pass

    @abstractmethod
    def affect_game(self, game):
        """
        Aplica o efeito do Power-up no jogo.

        Parâmetros:
            game (Game): A instância do jogo.
        """
        pass

    @abstractmethod
    def draw(self, screen):
        """
        Desenha o Power-up na tela.

        Parâmetros:
            screen (pygame.Surface): A superfície onde o Power-up será desenhado.
        """
        pass

    @abstractmethod
    def improve(self, player):
        """
        Melhora o Power-up de alguma forma.

        Parâmetros:
            player (Player, opcional): O jogador que pode afetar o Power-up (padrão é None).
        """
        pass

    @abstractmethod
    def remove_effect(self, player):
        """
        Remove o efeito do Power-up no jogador.

        Parâmetros:
            player (Player): O jogador do qual o efeito será removido.
        """
        pass

    def update(self):
        """
        Atualiza o estado do Power-up, incluindo a duração do efeito.

        Se o Power-up estiver ativo, diminui a duração. Quando a duração atinge zero, o efeito é removido.
        """
        if self.is_active:
            self.duration -= 1
            if self.duration <= 0:
                self.is_active = False
                self.remove_effect(self.player)

        self.rect.topleft = (self.x, self.y)


class InvincibilityPU(PowerUp):
    """
    Power-up que concede invencibilidade ao jogador.

    Atributos:
        is_invincible (bool): Indicador se o jogador está invencível.
        improved (bool): Indicador se o Power-up foi melhorado.
    """

    is_invincible = False
    improved = False

    def __init__(self, x, y, duration=300):
        """
        Inicializa o Power-up de Invencibilidade.

        Parâmetros:
            x (int): A posição x do Power-up.
            y (int): A posição y do Power-up.
            duration (int, opcional): A duração do efeito de invencibilidade (padrão é 300).
        """
        super().__init__(x, y, duration)
        self.powerup_type = 'InvincibilityPU'
        self.image = pygame.image.load("images/carne_zombie.png")
        self.rect = self.image.get_rect(topleft=(self.x, self.y))

    def affect_player(self, player):
        """
        Aplica o efeito de invencibilidade no jogador.

        Parâmetros:
            player (Player): O jogador afetado pelo Power-up.
        """
        self.is_active = True
        if InvincibilityPU.improved:
            self.duration = 600
        InvincibilityPU.is_invincible = True
        player.aura_color = (255, 255, 0)  # Amarelo
        player.aura_duration = self.duration
        player.is_invincible = InvincibilityPU.is_invincible
        print(f"{self.duration}")

    def affect_game(self, game):
        pass

    def remove_effect(self, player):
        """
        Remove o efeito de invencibilidade do jogador.

        Parâmetros:
            player (Player): O jogador do qual o efeito será removido.
        """
        player.aura_color = None
        self.is_active = False

    def improve(self, player=None):
        """
        Melhora o Power-up de invencibilidade, tornando-o mais duradouro.

        Parâmetros:
            player (Player, opcional): O jogador que pode afetar o Power-up (padrão é None).
        """
        InvincibilityPU.improved = True

    def draw(self, screen):
        """
        Desenha o Power-up de invencibilidade na tela.

        Parâmetros:
            screen (pygame.Surface): A superfície onde o Power-up será desenhado.
        """
        screen.blit(self.image, self.rect)


class DespawnerPU(PowerUp):
    """
    Power-up que reduz a taxa de spawn e pode remover inimigos.

    Atributos:
        remove_chance (float): A chance de remover um inimigo ao ser ativado.
    """

    remove_chance = 0.5

    def __init__(self, x, y, duration=300):
        """
        Inicializa o Power-up de Despawn.

        Parâmetros:
            x (int): A posição x do Power-up.
            y (int): A posição y do Power-up.
            duration (int, opcional): A duração do efeito do Power-up (padrão é 300).
        """
        super().__init__(x, y, duration)
        self.powerup_type = 'DespawnerPU'
        self.image = pygame.image.load("images/carne_zombie.png")
        self.rect = self.image.get_rect(topleft=(self.x, self.y))

    def affect_player(self, player):
        """
        Aplica o efeito do Power-up no jogador.

        Parâmetros:
            player (Player): O jogador afetado pelo Power-up.
        """
        self.is_active = True
        player.aura_color = (255, 255, 0)  # Amarelo
        player.aura_duration = self.duration

    def affect_game(self, game):
        """
        Aplica o efeito do Power-up no jogo, reduzindo o spawn de inimigos e removendo alguns.

        Parâmetros:
            game (Game): A instância do jogo.
        """
        self.is_active = True
        game.spawn_rate = max(0.5, game.spawn_rate * 0.8)
        if random.random() < self.remove_chance:
            if game.enemies:
                random_enemy = random.choice(game.enemies.sprites())
                random_enemy.kill()
        print(f"{DespawnerPU.remove_chance}")

    def remove_effect(self, player):
        """
        Remove o efeito do Power-up no jogador.

        Parâmetros:
            player (Player): O jogador do qual o efeito será removido.
        """
        pass

    def improve(self, game=None):
        """
        Melhora o Power-up, aumentando a chance de remover inimigos.

        Parâmetros:
            game (Game, opcional): A instância do jogo que pode ser afetada (padrão é None).
        """
        DespawnerPU.remove_chance = 0.7
        print(f"{DespawnerPU.remove_chance}")

    def draw(self, screen):
        """
        Desenha o Power-up de Despawn na tela.

        Parâmetros:
            screen (pygame.Surface): A superfície onde o Power-up será desenhado.
        """
        screen.blit(self.image, self.rect)


class RegenBoostPU(PowerUp):
    """
    Power-up que aumenta a regeneração de vida do jogador.

    Atributos:
        multiplicator (int): O multiplicador da regeneração de vida.
    """

    multiplicator = 2

    def __init__(self, x, y, duration=300):
        """
        Inicializa o Power-up de aumento de regeneração.

        Parâmetros:
            x (int): A posição x do Power-up.
            y (int): A posição y do Power-up.
            duration (int, opcional): A duração do efeito do Power-up (padrão é 300).
        """
        super().__init__(x, y, duration)
        self.powerup_type = 'RegenBoostPU'
        self.image = pygame.image.load("images/carne_zombie.png")
        self.rect = self.image.get_rect(topleft=(self.x, self.y))
        self.multiplicator = RegenBoostPU.multiplicator

    def affect_player(self, player):
        """
        Aplica o efeito de aumento de regeneração no jogador.

        Parâmetros:
            player (Player): O jogador afetado pelo Power-up.
        """
        self.is_active = True
        player.aura_color = (0, 0, 255)  # Azul
        player.aura_duration = self.duration
        print(f"{RegenBoostPU.multiplicator}")

    def affect_game(self, game):
        pass

    def remove_effect(self, player):
        """
        Remove o efeito de regeneração do jogador.

        Parâmetros:
            player (Player): O jogador do qual o efeito será removido.
        """
        player.health_regen_multiplier = 1

    def improve(self, player=None):
        """
        Melhora o Power-up, aumentando o multiplicador de regeneração.

        Parâmetros:
            player (Player, opcional): O jogador que pode afetar o Power-up (padrão é None).
        """
        RegenBoostPU.multiplicator = 4
        print(f"{RegenBoostPU.multiplicator}")

    def draw(self, screen):
        """
        Desenha o Power-up de aumento de regeneração na tela.

        Parâmetros:
            screen (pygame.Surface): A superfície onde o Power-up será desenhado.
        """
        screen.blit(self.image, self.rect)


class HealthRegenPU(PowerUp):
    """
    Power-up que regenera uma parte da vida do jogador.

    Atributos:
        improved (bool): Indicador se o Power-up foi melhorado.
        quantificator (int): A quantidade de vida a ser regenerada.
    """

    improved = False

    def __init__(self, x, y):
        """
        Inicializa o Power-up de regeneração de vida.

        Parâmetros:
            x (int): A posição x do Power-up.
            y (int): A posição y do Power-up.
        """
        super().__init__(x, y)
        self.quantificator = 20  # Valor inicial
        self.powerup_type = 'HealthRegenPU'
        self.image = pygame.image.load("images/carne_zombie.png")
        self.rect = self.image.get_rect(topleft=(self.x, self.y))

    def affect_player(self, player):
        """
        Aplica o efeito de regeneração de vida no jogador.

        Parâmetros:
            player (Player): O jogador afetado pelo Power-up.
        """
        self.is_active = True
        if HealthRegenPU.improved:
            self.quantificator = 30
        else:
            self.quantificator = 20

        player.health += self.quantificator
        if player.health > player.max_health:
            player.health = player.max_health

        player.aura_color = (0, 255, 0)  # Verde
        player.aura_duration = self.duration
        print(f"[DEBUG] quantificator = {self.quantificator}")

    def affect_game(self, game):
        pass

    def remove_effect(self, player):
        pass

    def improve(self, player=None):
        """
        Melhora o Power-up, aumentando a quantidade de vida regenerada.

        Parâmetros:
            player (Player, opcional): O jogador que pode afetar o Power-up (padrão é None).
        """
        HealthRegenPU.improved = True

    def draw(self, screen):
        """
        Desenha o Power-up de regeneração de vida na tela.

        Parâmetros:
            screen (pygame.Surface): A superfície onde o Power-up será desenhado.
        """
        screen.blit(self.image, self.rect)


class DamageBoostPU(PowerUp):
    """
    Power-up que aumenta o dano do jogador.

    Atributos:
        improved (bool): Indicador se o Power-up foi melhorado.
        multiplicator (int): O multiplicador de dano.
    """

    improved = False
    multiplicator = 2

    def __init__(self, x, y, duration=300):
        """
        Inicializa o Power-up de aumento de dano.

        Parâmetros:
            x (int): A posição x do Power-up.
            y (int): A posição y do Power-up.
            duration (int, opcional): A duração do efeito do Power-up (padrão é 300).
        """
        super().__init__(x, y, duration)
        self.powerup_type = 'DamageBoostPU'
        self.image = pygame.image.load("images/carne_zombie.png")
        self.rect = self.image.get_rect(topleft=(self.x, self.y))
        self.multiplicator = DamageBoostPU.multiplicator

    def affect_player(self, player):
        """
        Aplica o efeito de aumento de dano no jogador.

        Parâmetros:
            player (Player): O jogador afetado pelo Power-up.
        """
        self.is_active = True
        if DamageBoostPU.improved:
            self.multiplicator = 4

        player.damageB_active = True
        player.aura_color = (255, 0, 0)  # Vermelho
        player.powerups.add(self)
        player.aura_duration = self.duration
        print(f"multipl = {self.multiplicator},{self.duration}")

    def remove_effect(self, player):
        """
        Remove o efeito de aumento de dano do jogador.

        Parâmetros:
            player (Player): O jogador do qual o efeito será removido.
        """
        player.damageB_active = False
        player.aura_color = None

    def affect_game(self, game):
        pass

    def improve(self, player=None):
        """
        Melhora o Power-up, aumentando o multiplicador de dano.

        Parâmetros:
            player (Player, opcional): O jogador que pode afetar o Power-up (padrão é None).
        """
        DamageBoostPU.improved = True

    def draw(self, screen):
        """
        Desenha o Power-up de aumento de dano na tela.

        Parâmetros:
            screen (pygame.Surface): A superfície onde o Power-up será desenhado.
        """
        screen.blit(self.image, self.rect)


