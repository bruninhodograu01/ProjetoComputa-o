# player
import pygame

import math
import pickle

from powerups import DamageBoostPU, RegenBoostPU
from utils import Settings



class Player(pygame.sprite.Sprite):
    """
    Classe que representa o jogador no jogo.
    O jogador pode se mover, atacar, adquirir power-ups e armas, e interagir com a interface do jogo.

    Atributos:
    -----------
    speed : int
        Velocidade de movimento do jogador.
    health : int
        Saúde atual do jogador.
    max_health : int
        Máxima quantidade de saúde do jogador.
    money : int
        Quantidade de dinheiro do jogador.
    level : int
        Nível do jogador.
    exp : int
        Experiência acumulada pelo jogador.
    exp_to_next_level : int
        Quantidade de experiência necessária para o próximo nível.
    regen_rate : int
        Taxa de regeneração de saúde do jogador.
    regen_cooldown : int
        Intervalo de tempo entre regenerações de saúde (em ciclos de atualização).
    regen_timer : int
        Contador de tempo para regeneração de saúde.
    powerups : pygame.sprite.Group
        Grupo de power-ups ativos do jogador.
    weapons : list
        Lista de armas disponíveis para o jogador.
    current_weapon_index : int
        Índice da arma atualmente equipada.
    purchased_weapons : list
        Lista das armas compradas pelo jogador.
    is_invincible : bool
        Define se o jogador está invencível devido a algum power-up.
    """

    def __init__(self):
        """
        Inicializa a classe Player.

        Define as variáveis de estado do jogador, incluindo atributos de saúde, dinheiro,
        experiência, armas, e power-ups. Também carrega a imagem e define o retângulo
        de colisão do jogador.
        """
        super().__init__()
        self.powerups = pygame.sprite.Group()
        self.original_image = pygame.image.load("images/player.png").convert_alpha()
        self.image = self.original_image
        self.rect = self.image.get_rect()
        self.rect.center = (Settings.WIDTH // 2, Settings.HEIGHT // 2)
        self.is_invincible = False
        self.damageB_active = False
        self.color = (255, 255, 255)
        self.direction = 0
        self.alive = True
        self.aura_color = None
        self.aura_duration = 0

        # Atributos do jogador
        self.speed = 3
        self.health_regen_multiplier = 1
        self.damage = 0
        self.health = 100
        self.max_health = 100

        # Exp e dinheiro
        self.money = 0
        self.level = 1
        self.exp = 0
        self.exp_to_next_level = 100

        # Regeneração
        self.regen_rate = 1
        self.regen_cooldown = 120  # 2 segundos
        self.regen_timer = 0

        # Power-ups
        self.improved = False
        self.damage_boost = None
        self.health_regen = None
        self.regen_boost = None
        self.despawner = None

        # Armas
        self.weapon_cooldown = 0  # cooldown da arma
        self.current_weapon_index = 0
        self.purchased_weapons = []  # Lista das armas compradas
        self.weapons = [
            {"name": "Pistola", "damage": 10, "speed": 7, "pattern": "single", "cooldown": 10},
            {"name": "Espingarda", "damage": 20, "speed": 5, "pattern": "spread", "spread": 20, "cooldown": 30,
             "locked": True},
            {"name": "Rifle", "damage": 15, "speed": 10, "pattern": "single", "cooldown": 5, "locked": True},
            {"name": "Cajado", "damage": 0, "speed": 0, "pattern": "none", "cooldown": 50, "special": True,
             "locked": True},
        ]
        self.cooldown = self.weapons[self.current_weapon_index]["cooldown"]

    def unlock_weapon(self, weapon_name):
        """
        Desbloqueia uma arma quando comprada.

        Parâmetros:
        -----------
        weapon_name : str
            Nome da arma a ser desbloqueada.
        """
        for weapon in self.weapons:
            if weapon["name"] == weapon_name:
                weapon["locked"] = False
                self.purchased_weapons.append(weapon_name)

    def is_weapon_unlocked(self, weapon_name):
        """
        Verifica se uma arma está desbloqueada.

        Parâmetros:
        -----------
        weapon_name : str
            Nome da arma a ser verificada.

        Retorna:
        --------
        bool
            Retorna True se a arma estiver desbloqueada, caso contrário, False.
        """
        for weapon in self.weapons:
            if weapon["name"] == weapon_name:
                return not weapon.get("locked", False)
        return False

    def get_current_weapon(self):
        """
        Retorna a arma atualmente equipada.

        Retorna:
        --------
        dict
            Dicionário representando a arma atualmente equipada.
        """
        return self.weapons[self.current_weapon_index]

    def select_weapon(self, index):
        """
        Seleciona uma arma da lista de armas.

        Parâmetros:
        -----------
        index : int
            Índice da arma na lista de armas.
        """
        if 0 <= index < len(self.weapons):
            weapon = self.weapons[index]
            if not weapon.get("locked", False):  # Só permite selecionar armas desbloqueadas
                self.current_weapon_index = index
                self.cooldown = self.weapons[self.current_weapon_index]["cooldown"]
                print(f"Arma selecionada: {weapon['name']}")
            else:
                print("Esta arma está bloqueada!")

    def buy_weapon(self, weapon_name):
        """
        Permite que o jogador compre uma arma, caso tenha dinheiro suficiente.

        Parâmetros:
        -----------
        weapon_name : str
            Nome da arma a ser comprada.
        """
        weapon_prices = {
            "Espingarda": 100,  # Preço da espingarda
            "Rifle": 150,  # Preço do rifle
            "Cajado": 200,  # Preço do cajado
        }

        if weapon_name in weapon_prices and self.money >= weapon_prices[weapon_name]:
            # Deduz o preço da arma do dinheiro do jogador
            self.money -= weapon_prices[weapon_name]

            # Adiciona a arma ao inventário
            for i, weapon in enumerate(self.weapons):
                if weapon["name"] == weapon_name:
                    self.select_weapon(i)  # Seleciona a arma comprada
                    print(f"Você comprou a {weapon_name}!")
                    break
        else:
            print("Você não tem dinheiro suficiente para comprar essa arma.")

    def gain_money(self, amount):
        """
        Método para o jogador ganhar dinheiro ao derrotar inimigos.

        Parâmetros:
        -----------
        amount : int
            Quantidade de dinheiro a ser ganha.
        """
        if amount is not None:
            self.money += amount
        else:
            print("Erro: amount é None")

    def render_money(self, screen):
        """
        Método para renderizar a quantidade de dinheiro na tela.

        Parâmetros:
        -----------
        screen : pygame.Surface
            A superfície na qual o dinheiro será renderizado.
        """
        font = pygame.font.Font(None, 36)  # Escolhe a fonte e o tamanho
        money_text = font.render(f"Dinheiro: ${self.money}", True, (255, 255, 255))  # Cor do texto
        screen.blit(money_text, (10, 10))

    def apply_health_regen(self):
        """
        Aplica o efeito de regeneração de saúde, caso o power-up de regeneração esteja ativo.
        """
        if self.health_regen:
            self.health += self.health_regen.quantificator
            if self.health > self.max_health:
                self.health = self.max_health

    def handle_regeneration(self):
        """
        Lida com a regeneração de saúde com base no tempo e no cooldown.
        """
        self.regen_timer += 1
        if self.regen_timer >= self.regen_cooldown and self.health < self.max_health:
            # Aplica o multiplicador de regeneração
            self.health += self.regen_rate * RegenBoostPU.multiplicator
            self.health = min(self.health, self.max_health)
            self.regen_timer = 0

    def save_player_progress(self, file_path="player_save.pkl"):
        """
        Salva o estado atual do jogador em um ficheiro.

        Parâmetros:
        -----------
        file_path : str
            Caminho do arquivo onde o progresso será salvo.
        """
        try:
            with open(file_path, "wb") as save_file:
                pickle.dump({
                    "health": self.health,
                    "max_health": self.max_health,
                    "money": self.money,
                    "level": self.level,
                    "exp": self.exp,
                    "exp_to_next_level": self.exp_to_next_level,
                    "regen_rate": self.regen_rate,
                    "damage_multiplier": self.damage_multiplier,
                    "weapons": self.weapons,
                    "current_weapon_index": self.current_weapon_index,
                    "purchased_weapons": self.purchased_weapons,
                    "powerups": [powerup for powerup in self.powerups],
                }, save_file)
            print("Progresso salvo com sucesso!")
        except Exception as e:
            print(f"Erro ao salvar o progresso: {e}")

    def load_player_progress(self, file_path="player_save.pkl"):
        """
        Carrega o estado do jogador a partir de um ficheiro.

        Parâmetros:
        -----------
        file_path : str
            Caminho do arquivo de onde o progresso será carregado.
        """
        try:
            with open(file_path, "rb") as load_file:
                data = pickle.load(load_file)
                self.health = data["health"]
                self.max_health = data["max_health"]
                self.money = data["money"]
                self.level = data["level"]
                self.exp = data["exp"]
                self.exp_to_next_level = data["exp_to_next_level"]
                self.regen_rate = data["regen_rate"]
                self.damage_multiplier = data["damage_multiplier"]
                self.weapons = data["weapons"]
                self.current_weapon_index = data["current_weapon_index"]
                self.purchased_weapons = data["purchased_weapons"]
                self.powerups = pygame.sprite.Group(data["powerups"])
                print("Progresso carregado com sucesso!")
        except FileNotFoundError:
            print("Nenhum ficheiro de salvamento encontrado.")
        except Exception as e:
            print(f"Erro ao carregar o progresso: {e}")

    def reset_player_to_default(self):
        """
        Reinicia o estado do jogador para os valores iniciais.
        """
        self.health = 100
        self.max_health = 100
        self.money = 0
        self.level = 1
        self.exp = 0
        self.exp_to_next_level = 100
        self.regen_rate = 1
        self.damage_multiplier = 1
        self.weapons = [
            {"name": "Pistola", "damage": 10, "speed": 7, "pattern": "single", "cooldown": 10},
            {"name": "Espingarda", "damage": 20, "speed": 5, "pattern": "spread", "spread": 20, "cooldown": 30,
             "locked": True},
            {"name": "Rifle", "damage": 15, "speed": 10, "pattern": "single", "cooldown": 5, "locked": True},
            {"name": "Cajado", "damage": 0, "speed": 0, "pattern": "none", "cooldown": 50, "special": True,
             "locked": True},
        ]
        self.current_weapon_index = 0
        self.purchased_weapons = []
        self.powerups = pygame.sprite.Group()
        print("Jogador reiniciado para o estado inicial.")

    def level_up(self):
        """
        Realiza o processo de subir de nível do jogador, aumentando a saúde máxima e ajustando a quantidade de experiência necessária para o próximo nível.
        """
        self.level += 1
        self.exp_to_next_level = int(self.exp_to_next_level * 1.5)
        self.max_health += 10
        self.health = self.max_health
        print(f"Subiu de nível! Nível atual: {self.level}")

    def gain_exp(self, amount):
        """
        Adiciona experiência ao jogador e verifica se ele subiu de nível.

        Parâmetros:
        -----------
        amount : int
            Quantidade de experiência a ser ganha.
        """
        self.exp += amount
        while self.exp >= self.exp_to_next_level:
            self.exp -= self.exp_to_next_level
            self.level_up()

    def update(self):
        """
        Atualiza o estado do jogador, incluindo movimentação, direção, e regeneração de saúde.
        """
        if self.aura_duration > 0:
            self.aura_duration -= 1
        else:
            self.aura_color = None
            self.is_invincible = False  # Desativa a invencibilidade quando a aura acaba

        self.handle_movement()
        self.update_direction()
        self.handle_regeneration()

    def render(self, screen):
        """
        Desenha o jogador e seus efeitos visuais (como a aura de invencibilidade) na tela.

        Parâmetros:
        -----------
        screen : pygame.Surface
            A superfície onde o jogador será renderizado.
        """
        if self.aura_color:
            pygame.draw.circle(
                screen,
                self.aura_color,
                self.rect.center,
                self.rect.width // 2 + 10,  # Tamanho da aura
                4  # Largura da borda
            )
        screen.blit(self.image, self.rect)

    def handle_movement(self):
        """
        Lida com a movimentação do jogador com base nas teclas pressionadas.
        """
        keys = pygame.key.get_pressed()
        if keys[pygame.K_w] and self.rect.top > 0:
            self.rect.y -= self.speed
        if keys[pygame.K_s] and self.rect.bottom < Settings.HEIGHT:
            self.rect.y += self.speed
        if keys[pygame.K_a] and self.rect.left > 0:
            self.rect.x -= self.speed
        if keys[pygame.K_d] and self.rect.right < Settings.WIDTH:
            self.rect.x += self.speed

    def update_direction(self):
        """
        Atualiza a direção do jogador para a posição do rato.

        Este método calcula o ângulo entre o jogador e a posição do rato, rotacionando a imagem do jogador
        para que ele olhe para o cursor. A imagem do jogador é rotacionada de acordo com o ângulo calculado.

        Parâmetros:
        -----------
        Nenhum.

        Efeitos:
        --------
        - A direção do jogador é atualizada para o ângulo calculado.
        - A imagem do jogador é rotacionada para apontar na direção do rato.
        - O retângulo do jogador é ajustado para garantir que ele seja desenhado corretamente após a rotação.
        """
        mouse_x, mouse_y = pygame.mouse.get_pos()
        rel_x = mouse_x - self.rect.centerx
        rel_y = mouse_y - self.rect.centery
        angle = math.degrees(math.atan2(rel_y, rel_x))
        self.direction = angle
        self.image = pygame.transform.rotate(self.original_image, -self.direction)
        self.rect = self.image.get_rect(center=self.rect.center)

    def take_damage(self, amount):
        """
        Reduz a saúde do jogador quando ele é atingido.

        Este método verifica se o jogador não está invencível e, em caso negativo, aplica o dano recebido,
        reduzindo a saúde do jogador. Se a saúde atingir 0, o jogador morre (o objeto é removido).

        Parâmetros:
        -----------
        amount : int
            A quantidade de dano a ser aplicada à saúde do jogador.

        Efeitos:
        --------
        - Se o jogador não estiver invencível, sua saúde será reduzida pelo valor especificado.
        - Se a saúde do jogador atingir 0 ou menos, ele será removido do jogo.
        """
        if not self.is_invincible:  # Verifica se o jogador não está invencível
            self.health -= amount

        if self.health <= 0:
            self.health = 0
            self.kill()

    def attack(self, target):
        """
        Ataca o alvo com a arma atual do jogador.

        Este método aplica o dano da arma equipada no alvo. Se o power-up de aumento de dano estiver ativo,
        o dano é multiplicado pelo valor correspondente.

        Parâmetros:
        -----------
        target : pygame.sprite.Sprite
            O alvo a ser atacado. O alvo deve possuir o método `take_damage` para receber dano.

        Efeitos:
        --------
        - Aplica o dano ao alvo, levando em consideração o power-up de aumento de dano.
        """
        weapon = self.get_current_weapon()
        base_damage = weapon["damage"]
        # Aplica o multiplicador apenas se o power-up estiver ativo
        if self.damageB_active:
            total_damage = base_damage * DamageBoostPU.multiplicator
        else:
            total_damage = base_damage

        target.take_damage(total_damage)
        # print(f"{target} levou {total_damage} de dano.")

    def on_powerup_collected(self, powerup):
        """
        Método chamado quando o jogador coleta um Power-up.

        Este método chama a função `affect_player` do Power-up para aplicar o efeito ao jogador e marca
        o Power-up como ativo, indicando que o efeito foi aplicado.

        Parâmetros:
        -----------
        powerup : PowerUp
            O Power-up que foi coletado. O Power-up deve ter o método `affect_player` que aplica o efeito
            ao jogador.

        Efeitos:
        --------
        - Aplica o efeito do Power-up ao jogador.
        - Marca o Power-up como ativo.
        """
        powerup.affect_player(self)
        powerup.is_active = True  # Marca o Power-up como ativo

