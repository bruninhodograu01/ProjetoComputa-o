import pygame
import webbrowser  # Para abrir o link do Stripe
import game.game
from utils import Colors, Button
import logging

# Configuração de logging
logging.basicConfig(level=logging.INFO)

class Menu:
    def __init__(self, screen):
        self.screen = screen
        self.original_size = (720, 720)  # Tamanho original da tela
        self.small_size = (600, 400)  # Novo tamanho para a tela do banco
        self.buttons = self._initialize_buttons()

        # Carregar a imagem de background
        self.background_image = pygame.image.load("Last_Stand.png")
        self.background_image = pygame.transform.scale(self.background_image, self.original_size)

        # Iniciar a música em loop
        pygame.mixer.init()
        pygame.mixer.music.load("stranger-things-124008.mp3")  # Substitua pelo caminho do seu arquivo de som
        pygame.mixer.music.play(-1)  # -1 faz o som tocar em loop

    def _initialize_buttons(self):
        """Inicializa os botões do menu e os retorna em uma lista."""
        buttons = [
            Button("Play", pygame.Rect(280, 400, 170, 60), Colors.GREEN, self.wilderness_explorer, font_size=60, border_radius=15),  # Aumentado para 60px
            Button("Instructions", pygame.Rect(150, 500, 170, 60), Colors.GREY, self.instructions, font_size=36, border_radius=15),
            Button("Bank", pygame.Rect(150, 600, 170, 60), Colors.GREY, self.bank, font_size=36, border_radius=15),  # Alterado para Bank
            Button("Credits", pygame.Rect(400, 500, 170, 60), Colors.GREY, self.credits, font_size=36, border_radius=15),
            Button("Quit", pygame.Rect(400, 600, 170, 60), (255, 0, 0), self.quit, font_size=36, border_radius=15)
        ]
        return buttons

    def run(self):
        """Executa o loop do menu."""
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    for button in self.buttons:
                        if button.rect.collidepoint(event.pos):
                            button.on_click()

            # Desenhar tela
            self.screen.blit(self.background_image, (0, 0))
            for button in self.buttons:
                button.draw(self.screen)

            pygame.display.flip()

    # Funções dos botões
    def wilderness_explorer(self):
        logging.info("Play button clicked!")
        game.game.game_loop()

    def instructions(self):
        logging.info("Instructions button clicked!")

        # Criar o botão de "Back" no canto inferior direito
        back_button = Button("← Back", pygame.Rect(600, 660, 100, 40), Colors.RED, self.back_to_menu_from_instructions)

        # Texto explicativo
        instruction_text = [
            "welcome to the game!",
            "You should kill the zombies.",
            "if you kill enough zombies you will level up and gain money.",
            "with zumbucks you are able to buy weapons.",
            "that will help you kill enemies.",
            "you can buy zumbucks with real money in bank.",
            "you have 3 weapons: a pistol, a shotgun and a rifle, each of them with different mechanics.",
            "you also have 5 powerups: InvincibilityPU, DespawnerPU, RegenBoostPU, HealthRegenPU, DamageBoostPU.",
            "InvincibilityPU - Gives the player Invincibility.",
            "DespawnerPU - Despawns the enemy by a certain chance.",
            "RegenBoostPU - Increases the regeneration.",
            "HealthRegenPU - Will restore a certain amount of health.",
            "DamageBoostPU - Increases the damage.",
            "These powerups can be improved with the choice in the chest.",
            "There are 2 enemies: the normal zombie and the boss.",
            "The chest you acquire by killing the boss."
        ]

        # Criar o loop para exibir a tela de instruções
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

                # Verificar se o botão "Back" foi clicado
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if back_button.rect.collidepoint(event.pos):
                        back_button.on_click()

            # Preencher a tela com um fundo preto
            self.screen.fill((0, 0, 0))

            # Definir a fonte para o texto
            font = pygame.font.Font(None, 20)

            # Desenhar o texto explicativo na tela
            y_offset = 100  # Distância entre as linhas de texto
            for line in instruction_text:
                text = font.render(line, True, Colors.WHITE)
                text_rect = text.get_rect(center=(self.original_size[0] // 2, y_offset))
                self.screen.blit(text, text_rect)
                y_offset += 40  # Ajustar a posição para a próxima linha de texto

            # Desenhar o botão "Back"
            back_button.draw(self.screen)

            pygame.display.flip()

    def back_to_menu_from_instructions(self):
        logging.info("Back button clicked in instructions!")
        # Restaurar o tamanho original da tela
        pygame.display.set_mode(self.original_size)
        self.buttons = self._initialize_buttons()  # Recarregar os botões do menu
        self.screen.fill((0, 0, 0))  # Limpar a tela
        self.run()  # Voltar ao menu principal

    def bank(self):
        """Exibe a tela do banco com 6 imagens e valores"""
        self.show_bank_screen()

    def show_bank_screen(self):
        """Mostra a tela de compra com 6 imagens e seus valores"""
        running = True

        # Alterar a resolução da tela para menor
        pygame.display.set_mode(self.small_size)

        # Carregar imagens
        money_images = [
            pygame.image.load("images/noads.png"),  # Imagem de 5€
            pygame.image.load("images/100 moedas.png"),  # Imagem de 7€
            pygame.image.load("images/200 moedas.png"), # Imagem de 10€
            pygame.image.load("images/300moedas.png"), # Imagem de 13€
            pygame.image.load("images/400moedas.png"), # Imagem de 15€
            pygame.image.load("images/500moedas.png")  # Imagem de 20€
        ]
        money_images = [pygame.transform.scale(img, (100, 100)) for img in money_images]  # Redimensionar imagens para 100x100px

        # Definir as posições das imagens (3x3 layout)
        positions = [(100, 80), (250, 80), (400, 80),
                     (100, 230), (250, 230), (400, 230)]

        # Valores correspondentes
        values = ["5€", "7€", "10€", "13€", "15€", "20€"]
        stripe_links = [
            "https://buy.stripe.com/7sIbMgdHR58T6ek8wx",   # Link para o pagamento de NOADS
            "https://buy.stripe.com/6oEeYsdHReJt8mscMM",   # Link para o pagamento de 7€
            "https://buy.stripe.com/28o5nS9rB8l5byEfZ0",  # Link para o pagamento de 10€
            "https://buy.stripe.com/8wM8A4dHR7h1cCI3cf",  # Link para o pagamento de 13€
            "https://buy.stripe.com/14k3fK8nxgRB5agdQU",  # Link para o pagamento de 15€
            "https://buy.stripe.com/00gcQkcDN9p946c149"   # Link para o pagamento de 20€
        ]

        # Botão de "Back"
        back_button = Button("← Back", pygame.Rect(500, 340, 100, 40), Colors.RED, self.back_to_menu)

        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    for i, rect in enumerate(positions):
                        if pygame.Rect(rect[0], rect[1], 100, 100).collidepoint(event.pos):
                            # Abrir o link de pagamento correspondente
                            webbrowser.open(stripe_links[i])

                    # Verificar clique no botão "Back"
                    if back_button.rect.collidepoint(event.pos):
                        back_button.on_click()

            # Desenhar a tela do banco com fundo preto
            self.screen.fill((0, 0, 0))  # Fundo preto
            for i, pos in enumerate(positions):
                self.screen.blit(money_images[i], pos)  # Desenhar as imagens
                font = pygame.font.Font(None, 36)
                text = font.render(values[i], True, Colors.WHITE)  # Texto em branco

                self.screen.blit(text, (pos[0] + 35, pos[1] + 110))  # Desenhar o texto abaixo das imagens

            # Desenhar o botão "Back"
            back_button.draw(self.screen)

            pygame.display.flip()

    def back_to_menu(self):
        logging.info("Back button clicked!")
        # Restaurar o tamanho original da tela
        pygame.display.set_mode(self.original_size)
        self.buttons = self._initialize_buttons()  # Recarregar os botões do menu
        self.screen.fill((0, 0, 0))  # Limpar a tela
        self.run()  # Voltar ao menu principal

    def credits(self):
        logging.info("Credits button clicked!")

        # Criar o botão de "Back" (agora na parte inferior da tela)
        back_button = Button("ok 20,Back", pygame.Rect(500, 660, 150, 40), Colors.RED, self.back_to_menu_from_credits)

        # Criar um loop para exibir a tela de créditos
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

                # Verificar se o botão "Back" foi clicado
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if back_button.rect.collidepoint(event.pos):
                        back_button.on_click()

            # Preencher a tela com um fundo preto
            self.screen.fill((0, 0, 0))

            # Definir a fonte
            font = pygame.font.Font(None, 36)

            # Adicionar texto dos créditos
            text1 = font.render("Bruno Silva - 20231855", True, Colors.WHITE)
            text2 = font.render("Martim Mendes - 20231622", True, Colors.WHITE)

            # Adicionar imagem
            image = pygame.image.load("images/please.png")  # Substitua pelo caminho da sua imagem
            image = pygame.transform.scale(image, (300, 300))  # Ajuste o tamanho para 300x300px

            # Calcular a posição centralizada para os textos e imagem
            text1_x = self.original_size[0] // 2 - text1.get_width() // 2
            text2_x = self.original_size[0] // 2 - text2.get_width() // 2
            image_x = self.original_size[0] // 2 - image.get_width() // 2
            text3 = font.render("um 20?", True, Colors.WHITE)
            text3_x = self.original_size[0] // 2 - text3.get_width() // 2
            image_y = self.original_size[1] // 3 + 100  # Colocar a imagem um pouco abaixo dos créditos
            text3_y = image_y + image.get_height() + 10  # Posicionar o texto "um 20?" abaixo da imagem

            # Desenhar o texto, a imagem e o botão de "Back"
            self.screen.blit(text1, (text1_x, self.original_size[1] // 3))
            self.screen.blit(text2, (text2_x, self.original_size[1] // 3 + 50))
            self.screen.blit(image, (image_x, image_y))
            self.screen.blit(text3, (text3_x, text3_y))

            # Desenhar o botão "Back" na parte inferior
            back_button.draw(self.screen)

            pygame.display.flip()

        pygame.quit()
        exit()

    def back_to_menu_from_credits(self):
        logging.info("Back button clicked in credits!")
        # Restaurar o tamanho original da tela
        pygame.display.set_mode(self.original_size)
        self.buttons = self._initialize_buttons()  # Recarregar os botões do menu
        self.screen.fill((0, 0, 0))  # Limpar a tela
        self.run()  # Voltar ao menu principal

    def back_to_menu_from_credits(self):
        logging.info("Back button clicked in credits!")
        # Restaurar o tamanho original da tela
        pygame.display.set_mode(self.original_size)
        self.buttons = self._initialize_buttons()  # Recarregar os botões do menu
        self.screen.fill((0, 0, 0))  # Limpar a tela
        self.run()  # Voltar ao menu principal

    def quit(self):
        logging.info("Quit button clicked!")
        pygame.quit()
        exit()



class Button:
    def __init__(self, text, rect, color, on_click, font_size=36, border_radius=0):
        self.text = text
        self.rect = rect
        self.color = color
        self.on_click = on_click
        self.font_size = font_size  # Tamanho da fonte
        self.border_radius = border_radius

    def draw(self, screen):
        pygame.draw.rect(screen, self.color, self.rect, border_radius=self.border_radius)  # Desenhar com bordas arredondadas
        font = pygame.font.Font(None, self.font_size)  # Usar o tamanho da fonte
        text_surf = font.render(self.text, True, Colors.WHITE)
        text_rect = text_surf.get_rect(center=self.rect.center)
        screen.blit(text_surf, text_rect)



