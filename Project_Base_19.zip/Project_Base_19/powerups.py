import pygame
from abc import ABC, abstractmethod
import random
from player import Player
import pickle

class PowerUp(pygame.sprite.Sprite, ABC):
    def __init__(self, x, y, duration=300):  # Passar a duração como parâmetro
        super().__init__()
        self.x = x  # Posição x do Power-up
        self.y = y  # Posição y do Power-up
        self.duration = duration  # A duração agora será passada como argumento
        self.is_active = False  # Se o Power-up está ativo ou não
        self.image = None
        self.rect = None

    @abstractmethod
    def affect_player(self, player):
        """Afeta o jogador de alguma forma (modificar cor, invencibilidade, etc.)"""
        pass

    @abstractmethod
    def affect_game(self, game):
        """Afeta o jogo de alguma forma (e.g., despawn inimigos, etc.)"""
        pass

    @abstractmethod
    def draw(self, screen):
        """Desenha o Power-up na tela."""
        pass

    @abstractmethod
    def improve(self, player):
        pass

    def update(self):
        """Atualiza o estado do Power-up (e.g., duração do efeito)."""
        if self.is_active:
            self.duration -= 1
            if self.duration <= 0:
                self.is_active = False

        self.rect.topleft = (self.x, self.y)

def save_powerups(player, filename="powerups_data.pkl"):
    with open(filename, "wb") as f:
        # Serializa os power-ups ativos do jogador
        powerups_data = []
        for powerup in player.powerups:
            powerups_info = {
                "type": powerup.__class__.__name__,  # Nome da classe (tipo de power-up)
                "duration": powerup.duration,  # Duração do power-up
            }

            # Se o power-up tem atributos que podem ser modificados, como multiplicadores, adicione aqui
            if isinstance(powerup, DamageBoostPU):
                powerups_info["damage_multiplier"] = powerup.damage_multiplier  # Armazenar multiplicador de dano

            if isinstance(powerup, RegenBoostPU):
                powerups_info["multiplicator"] = powerup.multiplicator  # Armazenar multiplicador de regeneração

            if isinstance(powerup, HealthRegenPU):
                powerups_info["quantificator"] = powerup.quantificator  # Armazenar a quantidade de regeneração de vida

            if isinstance(powerup, DespawnerPU):
                powerups_info["remove_chance"] = powerup.remove_chance  # Armazenar a chance de remoção de inimigos

            powerups_data.append(powerups_info)

        pickle.dump(powerups_data, f)
        print("Power-ups salvos!")

def load_powerups(player, filename="powerups_data.pkl"):
    try:
        with open(filename, "rb") as f:
            powerups_data = pickle.load(f)
            # Limpa os power-ups antigos
            player.powerups.empty()

            # Recria os power-ups com base nos dados carregados
            for powerup_info in powerups_data:
                if powerup_info["type"] == "InvincibilityPU":
                    powerup = InvincibilityPU(0, 0, powerup_info["duration"])
                elif powerup_info["type"] == "DamageBoostPU":
                    powerup = DamageBoostPU(0, 0, powerup_info["duration"])
                    if "damage_multiplier" in powerup_info:
                        powerup.damage_multiplier = powerup_info["damage_multiplier"]  # Reaplica o multiplicador de dano
                elif powerup_info["type"] == "RegenBoostPU":
                    powerup = RegenBoostPU(0, 0, powerup_info["duration"])
                    if "multiplicator" in powerup_info:
                        powerup.multiplicator = powerup_info["multiplicator"]  # Reaplica o multiplicador de regeneração
                elif powerup_info["type"] == "HealthRegenPU":
                    powerup = HealthRegenPU(0, 0, powerup_info["duration"])
                    if "quantificator" in powerup_info:
                        powerup.quantificator = powerup_info["quantificator"]  # Reaplica a quantidade de regeneração de vida
                elif powerup_info["type"] == "DespawnerPU":
                    powerup = DespawnerPU(0, 0, powerup_info["duration"])
                    if "remove_chance" in powerup_info:
                        powerup.remove_chance = powerup_info["remove_chance"]  # Reaplica a chance de remoção de inimigos

                player.powerups.add(powerup)  # Adiciona o power-up ao grupo de power-ups

            print("Power-ups carregados!")
    except FileNotFoundError:
        print("Arquivo de power-ups não encontrado, nenhum power-up carregado.")



class InvincibilityPU(PowerUp):
    def __init__(self, x, y, duration=300):
        super().__init__(x, y, duration)
        self.image = pygame.image.load("images/carne_zombie.png")  # Imagem do Power-up
        self.rect = self.image.get_rect(topleft=(self.x, self.y))  # Define o retângulo para colisões
  # Define o retângulo para colisões

    def affect_player(self, player):
        player.is_invincible = True
        player.aura_color = (255, 255, 0)  # Amarelo
        player.aura_duration = self.duration

    def affect_game(self, game):
        pass  # Não altera nada no jogo, apenas afeta o jogador

    def improve(self, player):
        self.duration *= 1.5

    def draw(self, screen):
        screen.blit(self.image, self.rect)

class DespawnerPU(PowerUp):
    def __init__(self, x, y, duration=300):
        super().__init__(x, y, duration)
        self.image = pygame.image.load("images/carne_zombie.png")
        self.rect = self.image.get_rect(topleft=(self.x, self.y))  # Define o retângulo para colisões
        self.remove_chance = 0.5

    def affect_player(self, player):
        player.aura_color = (255, 255, 0)  # Amarelo
        player.aura_duration = self.duration  # O Power-up de De-spawner não afeta diretamente o jogador, mas afeta o jogo

    def affect_game(self, game):
        # Agora, game é uma instância de Game, então acessamos diretamente as propriedades
        game.spawn_rate = max(0.5, game.spawn_rate * 0.8)

        # Reduz a quantidade de inimigos
        if random.random() < self.remove_chance:  # 50% de chance de remover um inimigo
            if game.enemies:  # Acessamos os inimigos a partir da instância de game
                random_enemy = random.choice(game.enemies.sprites())
                random_enemy.kill()

    def improve(self, game):
        self.remove_chance = self.remove_chance * 1.20


    def draw(self, screen):
        screen.blit(self.image, self.rect)

class RegenBoostPU(PowerUp):
    def __init__(self, x, y, duration=300):
        super().__init__(x, y, duration)
        self.image = pygame.image.load("images/carne_zombie.png")  # Imagem do Power-up
        self.rect = self.image.get_rect(topleft=(self.x, self.y))  # Define o retângulo para colisões
        self.multiplicator = 2
    def affect_player(self, player):
        """Aumenta a regeneração de vida do jogador"""
        player.health_regen_multiplier = self.multiplicator  # Aumenta a regeneração de vida por 2x
        player.aura_color = (0, 0, 255) # azul
        player.aura_duration = self.duration

    def affect_game(self, game):
        pass

    def improve(self, player):
        self.duration *= 1.5
        self.multiplicator += 1


    def draw(self, screen):
        screen.blit(self.image, self.rect)

class HealthRegenPU(PowerUp):
    def __init__(self, x, y, duration=300):
        super().__init__(x, y, duration)
        self.image = pygame.image.load("images/carne_zombie.png")  # Imagem do Power-up
        self.rect = self.image.get_rect(topleft=(self.x, self.y))  # Define o retângulo para colisões
        self.quantificator = 20
    def affect_player(self, player):
        """Regenera uma parte da vida do jogador imediatamente"""
        player.health += self.quantificator  # Regenera 20 pontos de vida
        if player.health > player.max_health:
            player.health = player.max_health  # Garante que a vida não ultrapasse o máximo
        player.aura_color = (0, 255, 0) # verde
        player.aura_duration = self.duration

    def affect_game(self, game):
        pass  # Este Power-up não afeta o jogo, apenas o jogador

    def improve(self, player):
        self.quantificator += 10

    def draw(self, screen):
        screen.blit(self.image, self.rect)

class DamageBoostPU(PowerUp):
    def __init__(self, x, y, duration=300):
        super().__init__(x, y, duration)
        self.image = pygame.image.load("images/carne_zombie.png")
        self.rect = self.image.get_rect(topleft=(self.x, self.y))

    def affect_player(self, player):
        """Aumenta o dano do jogador."""
        player.damage_multiplier = 2
        print(f"Damage multiplier definido para {player.damage_multiplier}")
        player.aura_color = (255, 0, 0)  # vermelho
        player.aura_duration = self.duration

    def affect_game(self, game):
        pass

    def improve(self, player):
        """Melhora a duração ou intensidade do Power-up"""
        self.duration *= 1.5  # Aumenta a duração do Power-up
        if hasattr(player, "damage_multiplier"):
            player.damage_multiplier *= 1.5  # Aumenta o dano do jogador para 1.5x o valor anterior
        print(f"Power-up melhorado! Nova duração: {self.duration},{player.damage_multiplier}")

    def draw(self, screen):
        screen.blit(self.image, self.rect)



