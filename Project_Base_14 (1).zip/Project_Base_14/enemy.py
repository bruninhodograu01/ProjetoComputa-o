import pygame
import math
from bullet import Bullet  # Certifique-se de que a classe Bullet seja importada corretamente

class Enemy(pygame.sprite.Sprite):
    def __init__(self, x, y, health, damage, speed, exp_reward,money_reward):
        super().__init__()
        self.image = pygame.image.load("images/zombie(1).png").convert_alpha() # Carrega a imagem do inimigo
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)

        # Atributos fixos definidos pelo jogador
        self.health = health
        self.damage = damage
        self.speed = speed
        self.exp_reward = exp_reward
        self.money_reward = money_reward
        self.damage_cooldown = 100
        self.damage_timer = 0

    def update(self, player, bullet_group, enemies):
        """Método que será sobrescrito nas subclasses"""
        pass

    def apply_damage(self, player):
        """Aplica dano ao jogador e reinicia o cooldown de dano."""
        player.health -= self.damage
        player.health = max(player.health, 0)
        self.damage_timer = self.damage_cooldown

    def take_damage(self, amount, player):
        """Aplica dano ao inimigo"""
        self.health -= amount
        if self.health <= 0:
            self.kill()
            player.gain_money(self.money_reward)  # Supondo que 'player' tenha esse método
            player.gain_exp(self.exp_reward)

class Boss(Enemy):
    def __init__(self, x, y, health, damage, bullet_group, shoot_cooldown=200, money_reward=None):
        super().__init__(x, y, health, damage, 1, 50, money_reward)  # Velocidade diferente de 0 para mover
        self.shoot_cooldown = shoot_cooldown
        self.shoot_timer = 0
        self.bullet_group = bullet_group

    def shoot_bullet(self, player):
        """Cria uma bala direcionada ao jogador e adiciona ao grupo de balas."""
        angle = math.atan2(player.rect.centery - self.rect.centery, player.rect.centerx - self.rect.centerx)
        damage = 2
        speed = 4

        bullet = Bullet(self.rect.centerx, self.rect.centery, angle, damage, speed, self)
        self.bullet_group.add(bullet)

    def update(self, player, bullet_group, enemies):
        """Atualiza o estado do Zombie, incluindo disparos e movimento"""
        if self.shoot_timer <= 0:
            self.shoot_bullet(player)
            self.shoot_timer = self.shoot_cooldown
        else:
            self.shoot_timer -= 1

        # Movimento básico em direção ao jogador
        dx = player.rect.x - self.rect.x
        dy = player.rect.y - self.rect.y
        angle = math.atan2(dy, dx)
        self.rect.x += self.speed * math.cos(angle)
        self.rect.y += self.speed * math.sin(angle)

        # Verifica colisões com balas
        # Colisão com balas
        for bullet in bullet_group:
            if bullet.rect.colliderect(self.rect) and bullet.origin != self:
                self.take_damage(bullet.damage,player)
                if self.health <= 0:
                    player.gain_exp(self.exp_reward)
                    player.gain_exp(self.exp_reward)

        # Colisão com o jogador para dano
        if self.damage_timer == 0 and self.rect.colliderect(player.rect):
            self.apply_damage(player)

        if self.damage_timer > 0:
            self.damage_timer -= 1

class Zombie(Enemy):
    def __init__(self, x, y, health, damage, speed, exp_reward, money_reward):
        super().__init__(x, y, health, damage, speed, exp_reward, money_reward)  # A imagem foi adicionada aqui

    def update(self, player, bullet_group, enemies):
        """Faz o inimigo perseguir o jogador e causar dano se colidir com ele"""
        dx = player.rect.x - self.rect.x
        dy = player.rect.y - self.rect.y
        direction = math.atan2(dy, dx)

        # Movimento do inimigo
        self.rect.x += self.speed * math.cos(direction)
        self.rect.y += self.speed * math.sin(direction)

        # Verifica colisão com o jogador para dano
        if self.damage_timer == 0 and self.rect.colliderect(player.rect):
            self.apply_damage(player)

        if self.damage_timer > 0:
            self.damage_timer -= 1

        # Colisão com outros inimigos para evitar sobreposição
        for enemy in enemies:
            if enemy != self and self.rect.colliderect(enemy.rect):
                overlap_dx = self.rect.centerx - enemy.rect.centerx
                overlap_dy = self.rect.centery - enemy.rect.centery
                distance = max(1, int(math.sqrt(overlap_dx ** 2 + overlap_dy ** 2)))
                self.rect.x += overlap_dx / distance
                self.rect.y += overlap_dy / distance

        # Colisão com balas
        for bullet in bullet_group:
            if bullet.rect.colliderect(self.rect) and bullet.origin != self:
                self.take_damage(bullet.damage,player)
                if self.health <= 0:
                    player.gain_exp(self.exp_reward)
                    player.gain_exp(self.exp_reward)



















"""

import pygame
import random
import math
from bullet import Bullet
from utils import Settings

class Enemy(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.original_image = pygame.image.load("images/zombie(1).png").convert_alpha()
        self.image = self.original_image
        self.rect = self.image.get_rect()

        # Inicializa a posição aleatória dentro da tela
        self.rect.x = random.randint(0, Settings.WIDTH - self.rect.width)
        self.rect.y = random.randint(0, Settings.HEIGHT - self.rect.height)

        self.speed = 1
        self.health = 10
        self.damage = 0.5
        self.exp_reward = 20
        self.damage_cooldown = 100
        self.damage_timer = 0
        self.shoot_cooldown = 200
        self.shoot_timer = 0

    def shoot_bullet(self, player, bullet_group):
Cria uma bala direcionada ao jogador e adiciona ao grupo de balas.
        angle = math.atan2(player.rect.centery - self.rect.centery, player.rect.centerx - self.rect.centerx)
        damage = 2
        speed = 4

        bullet = Bullet(self.rect.centerx, self.rect.centery, angle, damage, speed, self)
        bullet_group.add(bullet)

    def update(self, player, bullet_group, enemies):
        Atualiza o estado do inimigo, incluindo movimento, colisões e cooldowns.
        dx = player.rect.x - self.rect.x
        dy = player.rect.y - self.rect.y
        direction = math.atan2(dy, dx)

        # Movimento do inimigo
        self.rect.x += self.speed * math.cos(direction)
        self.rect.y += self.speed * math.sin(direction)

        # Verifica colisão com o jogador para dano
        if self.damage_timer == 0 and self.rect.colliderect(player.rect):
            self.apply_damage(player)

        if self.damage_timer > 0:
            self.damage_timer -= 1

        # Verifica se é hora de disparar uma bala
        if self.shoot_timer <= 0:
            self.shoot_bullet(player, bullet_group)
            self.shoot_timer = self.shoot_cooldown
        else:
            self.shoot_timer -= 1

        # Colisão com outros inimigos para evitar sobreposição
        for enemy in enemies:
            if enemy != self and self.rect.colliderect(enemy.rect):
                overlap_dx = self.rect.centerx - enemy.rect.centerx
                overlap_dy = self.rect.centery - enemy.rect.centery
                distance = max(1, int(math.sqrt(overlap_dx ** 2 + overlap_dy ** 2)))
                self.rect.x += overlap_dx / distance
                self.rect.y += overlap_dy / distance

        # Verifica colisões com balas
        for bullet in bullet_group:
            if bullet.rect.colliderect(self.rect) and bullet.origin != self:
                self.health -= bullet.damage
                bullet.kill()

        if self.health <= 0:
            player.gain_exp(self.exp_reward)
            self.kill()

    def apply_damage(self, player):
        Aplica dano ao jogador e reinicia o cooldown de dano.
        player.health -= 10
        player.health = max(player.health, 0)
        self.damage_timer = self.damage_cooldown

"""






