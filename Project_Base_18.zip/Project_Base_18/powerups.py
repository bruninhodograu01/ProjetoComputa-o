import pygame
from abc import ABC, abstractmethod
import random
from player import Player


class PowerUp(pygame.sprite.Sprite, ABC):
    def __init__(self, x, y, duration):
        super().__init__()
        self.x = x  # Posição x do Power-up
        self.y = y  # Posição y do Power-up
        self.duration = duration  # Duração do efeito
        self.is_active = False  # Se o Power-up está ativo ou não
        self.image = None
        self.rect = None

    @abstractmethod
    def affect_player(self, player):
        """Afeta o jogador de alguma forma (modificar cor, invencibilidade, etc.)"""
        pass

    @abstractmethod
    def affect_game(self, game):
        """Afeta o jogo de alguma forma (e.g., despawn inimigos, etc.)"""
        pass

    @abstractmethod
    def draw(self, screen):
        """Desenha o Power-up na tela."""
        pass

    def update(self):
        """Atualiza o estado do Power-up (e.g., duração do efeito)."""
        if self.is_active:
            self.duration -= 1
            if self.duration <= 0:
                self.is_active = False

        self.rect.topleft = (self.x, self.y)

class InvincibilityPU(PowerUp):
    def __init__(self, x, y, duration):
        super().__init__(x, y, duration)
        self.image = pygame.image.load("images/carne_zombie.png")  # Imagem do Power-up
        self.rect = self.image.get_rect(topleft=(self.x, self.y))  # Define o retângulo para colisões
  # Define o retângulo para colisões

    def affect_player(self, player):
        player.is_invincible = True
        player.aura_color = (255, 255, 0)  # Amarelo
        player.aura_duration = self.duration

    def affect_game(self, game):
        pass  # Não altera nada no jogo, apenas afeta o jogador

    def improve(self, player):
        pass


    def draw(self, screen):
        screen.blit(self.image, self.rect)

class DespawnerPU(PowerUp):
    def __init__(self, x, y, duration):
        super().__init__(x, y, duration)
        self.image = pygame.image.load("images/carne_zombie.png")
        self.rect = self.image.get_rect(topleft=(self.x, self.y))  # Define o retângulo para colisões

    def affect_player(self, player):
        player.aura_color = (255, 255, 0)  # Amarelo
        player.aura_duration = self.duration  # O Power-up de De-spawner não afeta diretamente o jogador, mas afeta o jogo

    def affect_game(self, game):
        # Agora, game é uma instância de Game, então acessamos diretamente as propriedades
        game.spawn_rate = max(0.5, game.spawn_rate * 0.8)

        # Reduz a quantidade de inimigos
        if random.random() < 0.5:  # 50% de chance de remover um inimigo
            if game.enemies:  # Acessamos os inimigos a partir da instância de game
                random_enemy = random.choice(game.enemies.sprites())
                random_enemy.kill()

    def improve(self, player):
        pass


    def draw(self, screen):
        screen.blit(self.image, self.rect)

class RegenBoostPU(PowerUp):
    def __init__(self, x, y, duration):
        super().__init__(x, y, duration)
        self.image = pygame.image.load("images/carne_zombie.png")  # Imagem do Power-up
        self.rect = self.image.get_rect(topleft=(self.x, self.y))  # Define o retângulo para colisões

    def affect_player(self, player):
        """Aumenta a regeneração de vida do jogador"""
        player.health_regen_multiplier = 2  # Aumenta a regeneração de vida por 2x
        player.aura_color = (0, 0, 255) # azul
        player.aura_duration = self.duration

    def affect_game(self, game):
        pass

    def improve(self, player):
        pass


    def draw(self, screen):
        screen.blit(self.image, self.rect)

class HealthRegenPU(PowerUp):
    def __init__(self, x, y, duration):
        super().__init__(x, y, duration)
        self.image = pygame.image.load("images/carne_zombie.png")  # Imagem do Power-up
        self.rect = self.image.get_rect(topleft=(self.x, self.y))  # Define o retângulo para colisões

    def affect_player(self, player):
        """Regenera uma parte da vida do jogador imediatamente"""
        player.health += 20  # Regenera 20 pontos de vida
        if player.health > player.max_health:
            player.health = player.max_health  # Garante que a vida não ultrapasse o máximo
        player.aura_color = (0, 255, 0) # verde
        player.aura_duration = self.duration

    def affect_game(self, game):
        pass  # Este Power-up não afeta o jogo, apenas o jogador

    def improve(self, player):
        pass

    def draw(self, screen):
        screen.blit(self.image, self.rect)

class DamageBoostPU(PowerUp):
    def __init__(self, x, y, duration):
        super().__init__(x, y, duration)
        self.image = pygame.image.load("images/carne_zombie.png")
        self.rect = self.image.get_rect(topleft=(self.x, self.y))

    def affect_player(self, player):
        """Aumenta o dano do jogador."""
        player.damage_multiplier = 2
        print(f"Damage multiplier definido para {player.damage_multiplier}")
        player.aura_color = (255, 0, 0)  # vermelho
        player.aura_duration = self.duration

    def affect_game(self, game):
        pass

    def improve(self, player):
        """Melhora a duração ou intensidade do Power-up"""
        self.duration += 5  # Aumenta a duração do Power-up
        if hasattr(player, "damage_multiplier"):
            player.damage_multiplier *= 1.5  # Aumenta o dano do jogador para 1.5x o valor anterior

    def draw(self, screen):
        screen.blit(self.image, self.rect)



